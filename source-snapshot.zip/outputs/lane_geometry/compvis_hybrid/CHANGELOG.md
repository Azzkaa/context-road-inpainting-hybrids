# CompVis hybrid change log

## 26 November 2026 Setup and initial interfaces
- Selected CompVis inpainting_big as the first backbone; Big LaMa is the fallback after the bounded comparison fails.
- Kept Klein and earlier restoration checkpoints unchanged as comparisons.
- Verified the real CompVis source: seven input channels, three latent/output channels, frozen VQ first stage and U-Net module ledger.
- Added a spatial road adapter with SiLU layers and a zero output projection; initial feature injection is exactly zero in standalone tests.
- Added scene and sign token interfaces with positions, confidence and validity; no text instruction path.
- Added eight-head bottleneck context attention with a zero output projection; standalone initial predictions are unchanged and no-sign cases are finite.
- Standalone shape, gradient and checkpoint reload checks passed; full-model attachment and8GB memory gates remain pending.
- Created the five-page Word plan, visual structure diagram and live progress page.
- Updated the existing scheduled task to every30minutes; no duplicate research task.
- No training or restored output from this new hybrid yet. Next connect the adapters to the real U-Net and generate a matched frozen baseline.

## 26 November Real model attachment
- Connected the spatial adapter after the real U-Net input block and context attention after its bottleneck.
- Added actual snowy-source SegFormer features and native source sign crops; no clean image enters conditioning. Sign proposals are unverified, with fixed availability weight0.5, not calibrated confidence.
- Fixed original inpainting semantics: mask1meansedit, black maskedRGB before signed normalization; seven denoiser channels retained.
- Real512px A1/B/C and missing-sign predictions match exactly at zero initialization; finite forward passes. Peak allocation3.03GiB/reserved3.70GiB. No optimizer updates.
- Recorded64TRAIN and20VALIDATION pilot IDs before training, using source-only TRAIN sign candidates. Existing TEST unchanged.
- Started the50step frozen CompVis baseline on the gate TRAIN example; native road-only compositing checks outside-permit equality. Backward/resume gates and trained hybrid output still pending.

- Frozen50step native baseline completed: outside predicted permit changed pixels0, but output road is flat/streaked and lane paint missing. Visually reviewed; not promoted.
- Recorded a padding issue for the context path: padded sky/hood feature tokens must be excluded before training. Full backward/memory/resume gate still pending.

## 26 November Padding backward and data gates
- Excluded padded scene tokens from attention while retaining the whole real scene. Nonzero-projection tests show padded keys cannot affect output or receive gradients.
- Full512px backward gate passed: finite gradients, frozen weights untouched, about3.95GiBallocated/4.64GiBreserved. Two diagnostic updates replay exactly from model/optimizer/scaler/CPU-CUDA RNG checkpoint.
- Cached all84source-only sign proposal sets consistently:59of64TRAIN and20of20VAL have unverified sign crops; no clean image in detection.
- Cache alignment checks caught differing stored-mask work resolution; applied established NN mapping to native frame before shared letterbox. Prior failure evidence preserved; no training had begun.
- Audited64TRAIN and20VAL caches; validation has no clean target fields. Included the full verified701lane inventory:18pilotTRAIN examples have lane supervision.
- Started matched100-update A1/B/C pilot, serially, from original shared initialization rather than C-only diagnostic weights. Four fixedVALrestored outputs pervariant follow; no longer run authorized yet.

## 26 November First pilot reviewed
- A1/B/C100updatecomparisoncompleted with exactTRAINid/timestep/noise match. Actual fourVALimages fail restoration; B/Cdarkdistortionsworse.
- RoadLPIPS A1/B/C=0.5943/0.6435/0.6437; no qualitygainorusefulsignbenefit established.
- Predictedroadpermit spillsintohood in1055/1068; outsidepermitpixel equality is not semantic mask correctness.
- Measured frozencontextresidual56to85%ofbottleneckRMS andspatial21to26%ofinputRMS. Added optional fixed10%RMSbound, preserving legacydefault and zero-initgradients; gatepassed.
- Rendering frozenB/Cwithbound as diagnostic only; no retraining. Queuedsource-onlyMapillaryEgoVehicle64/CarMount63protectionprobe afterGPUfinishes.

## 26 November — completed diagnostics and protected inputs
- Capped added spatial/attention residuals at 10% of base-feature RMS in a frozen inference diagnostic; no training updates added. Four-case LPIPS improved slightly, but roads and lane paint remain inaccurate; no promotion.
- Added source-only frozen Ego Vehicle/Car Mount protection to exclude hood/dashboard regions from experimental edit permits. Cached all 64 TRAIN and 20 VAL inputs separately; original caches preserved.
- Re-encoded masked source inputs after protection changed; finite inputs, permit-subset checks and 84 nonempty permits passed. Inspected initial five overlays and six largest permit reductions; masks remain predictions, not ground truth.
- Corrected training remains held pending fresh full-model gradient, memory and resume checks. All controls must use the same corrected permit; shrinking the evaluated region is not restoration improvement.

## 26 November — decoded-road objective memory gate
- Added common auxiliary TRAIN-target losses: decoded road L1 (0.1) and road gradient L1 (0.05), alongside weighted noise MSE. Frozen VQ weights pass gradients; decoder activation checkpointing enabled.
- Full 512px decoded-loss backward exceeded the 8GB GPU budget; failure preserved in corrected_backward_resume_gate/failure_full512.json. No pilot training was started.
- Retrying the real gate with a 256px auxiliary decoder loss (pooled predicted latent and target), while denoising/inference remain 512px. This reduces fine-detail supervision and must not be described as full-resolution lane supervision. All matched variants will use the same objective if gates pass.

- Lower-memory corrected G2 passed: peak allocated 3.95GiB/reserved4.36GiB, finite gradients, exact optimizer/weights/CPU-CUDA RNG replay. Auxiliary terms at t54: MSE3.0612/L1.3144/gradient.1124; at t779:.00699/.5994/.1183. Terms vary by timestep; no loss improvement claim.
- Prepared fresh matched100-update A1/B/C correction with shared original initialization, ego-protected v3 inputs, residual cap0.1 and identical 256px auxiliary losses. Two smoke updates are isolated and never resumed as pilot initialization.

## 26 November — corrected CompVis rejected; LaMa fallback started
- Matched corrected100-update A1/B/C completed; reviewed all four outputs. Road surfaces remain warped/glassy with missing paint. B LPIPS improvement over matched A1 is only0.82%; C adds no useful observed sign benefit. This is four-case development evidence, not20-case evaluation or lane accuracy.
- Preserved all corrected checkpoints and outputs. Stopped CompVis under severe-error fallback rule after its one correction; no indefinite training extension.
- Started frozen Big LaMa native-road-only previews and real module/shape ledger using the same audited source-only v3 permits. No LaMa training until fresh gates pass.
- User target: concrete viewable comparisons by end of26November Asia/Riyadh; quality improvement is not guaranteed.

Active job inspect_lama_fallback.py session10523; inspect before launching duplicates. Results lama_fallback/, log inspection.log.

## LaMa actual attachment
- Frozen LaMa previews complete: no CompVis-style severe distortion, but snow remains and lane paint is not recovered. These are baselines, not successful restorations.
- Actual Fourier bottleneck ledger identifies model.23 ConcatTupleLayer as512x64x64. Attached a zero-initialized shared local residual for A1/B/C, spatial road residual and scene/sign cross-attention for B/C at that feature tensor. Fixed10%residual RMS limits preserve the base.
- Frozen50,975,875parameter base preserved. Real no-update zero-init/frozen-equality/no-sign gate launched; numerical/memory/resume gates still required before training.

Attachment gate job session18609; code lama_hybrid.py/gate_lama_attachment.py, results lama_fallback/attachment_gate.json. Next real backward/resume gate and matched reconstruction pilots.

- Actual equality assertion failed; diagnostic rerun records maximum differences. No training allowed and equality requirement unchanged.

## LaMa equality resolved and real backward gate
- Initial maximum output difference1.788e-7 disappeared under deterministic cuDNN/CUBLAS execution. Kept exact equality requirement: frozen baseline/A1/B/C/no-sign now bitwise equal. No weights were changed to hide the difference.
- Actual zero-init conditioning attachments total389,152trainable parameters; base50,975,875parameters stays frozen.
- Launched two-update real TRAIN gradient/memory/exact optimizer-RNG replay gate, with road L1+0.05gradient loss. Clean TRAIN image remains target only. No pilot training yet.

Active G2 session65101 gate_lama_resume.py; log lama_fallback/backward_gate.log, result backward_resume_gate.json. Inspect before duplicates. Matched pilots must load initial_trainable.pt, not smoke_step1.pt.

- G2 stopped before optimizer: CUDA reflection_pad2d_backward has no deterministic implementation under current strict setting. Session65101 exited; no healthy GPU job. Next implement deterministic reflection-padding backward (including Conv2d padding_mode reflect paths), verify forward equality and repeat real gate; do not disable strictness silently or claim resume passed.

## Deterministic reflection-padding compatibility
- Kept native GPU reflection-padding forward exactly; moved only its gradient reduction to CPU, preserving base weights and layer semantics. Covers explicit ReflectionPad2d and reflect-mode Conv2d. CPU forward/gradient equality test passed; real512px attachment equality still exact.
- Full-model backward now runs past the unsupported CUDA operation. Exact replay check was separated from GPU allocator statistics, which are headroom measurements rather than deterministic numerical state. Loss, trainable weights and CPU/CUDA RNG still require exact equality.
- Prepared finite matched LaMa100-update pilot runner with shared original initialization and identical road reconstruction/gradient objective. It refuses to start without the fresh backward gate; no pilot launched yet.

Current G2 rerun session75857, log lama_fallback/backward_padding_replay.log. Previous session88474 exited on replay dictionary including memory stats. Inspect actual loss/weights assertion results before training. Pilot runner train_lama_pilot.py prepared; requires backward_resume_gate.json PASS, serial A1/B/C only.

- LaMa G2 PASSED: exact loss/weights/RNG replay, frozen base gradients absent, peak0.689GiB allocated/0.737reserved. Started run_lama_pilots.py serial A1/B/C100updates from initial_trainable.pt. Inspect pilot100/sequence.log/status before launching anything else. Native4VALcomparisons follow; no quality claim yet.

## LaMa100-update pilot reviewed
- Matched A1/B/C100-update training and four previews completed. B/C roads look darker and more road-like, but lane paint remains largely absent; sign branch shows no clear benefit. Not a successful combined restoration.
- Started serial evaluation of the same saved checkpoints on all20frozenVALimages, with zero additional optimization. Original pilot outputs/checkpoints preserved.
- Added CPU road LPIPS/PSNR/SSIM scoring on identical predicted permits; image scores are not lane accuracy. Next inspect20-case failures and practical extension rule before any250-update run.

Active run_lama_eval100.py session36632. After it completes run score_lama_eval.py on CPU; do not duplicate GPU jobs. eval100copies latest.pt only to isolateddir and starts100, so trainingloopskipsallupdates.

## LaMa20-case evaluation complete
- Mean road LPIPS A1/B/C=.588657/.583988/.583053; context gains only0.79%/0.95%, below5%extension rule. PSNR11.18/14.61/14.67dB andSSIM.365/.411/.414 improve, but lane paint remains missing and surfaces blurred. No unchanged250-update extension.
- Predicted permits cover54.28%ofrecorded syntheticeditarea onaverage, explaining persistent snow. This is edit-mask coverage, not physicalroadGTaccuracy; masks were evaluation references only.
- Next justified LaMa correction to assess: restore verified TRAINlane weighting in reconstruction (currentLaMapilot usedroadonly) and selectively adapt final decoder block for thinpaint, retaining matched controls and fresh actual gradient/memory/resume gates. Do not feed clean labels into deployment or tune finalTEST.

Scoring session50201complete; noGPUjob. Results eval100/comparison_metrics.json, visual_review.json, permit_coverage_audit.json. Review nativeexamples before correction; do not rerununchangedpilot.

## LaMa lane-weighted decoder correction
- Original20case100-update pilot lackedpaint; added verified TRAINlane corridor weight4 in road reconstruction/gradient loss. No new lane labels or deployment reference inputs.
- Unfroze only finalRGBprojection:9,411additionalparameters, decoderLR1e-5 versus adapter1e-4. All other pretrained parameters frozen; A1/B/Cshare identical scope/objective.
- Fresh actual zero-init/frozen/no-sign equality passed. Corrected real gate used annotatedTRAINcase; finalprojection/spatial/contextgrads nonzero, finite; exact loss/weights/CPU-CUDA RNG replay, peak0.689GiB.
- Started isolated correction/pilot100 serial A1/B/Cfrom shared originalinitialization (not smoke-trainedweights), fullres512road reconstruction,20VALrenders. No improved output claim yet. Originalbranches remain unchanged.

Active run_lama_corrected_pilots.py; log lama_fallback/correction/pilot100/sequence.log. Inspect healthyjobs beforeduplicates. Next CPUscore same20VALwith score_lama_eval.py adaptedoutputroot, inspectactualpaintfailures, extensiononlyifjustified.
