"""Explicit image-only marking layout predictor; not pixel rendering or sign reader."""
import torch
from torch import nn
from torch.nn import functional as F
class MarkingLayoutHead(nn.Module):
 def __init__(self):
  super().__init__();self.net=nn.Sequential(nn.Conv2d(323,96,3,padding=1),nn.GroupNorm(8,96),nn.SiLU(),nn.Conv2d(96,64,3,padding=1),nn.GroupNorm(8,64),nn.SiLU(),nn.Conv2d(64,2,1));nn.init.constant_(self.net[-1].bias,-3.)
 def forward(self,scene,geometry):
  assert scene.shape[1:]==(192,64,64) and geometry.shape[1:]==(131,32,32)
  return F.interpolate(self.net(torch.cat([scene,F.interpolate(geometry,size=(64,64),mode='bilinear',align_corners=False)],1)),size=(128,128),mode='bilinear',align_corners=False)
