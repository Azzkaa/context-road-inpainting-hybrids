"""Read public model metadata/configs only; no images uploaded, no weights executed."""
from pathlib import Path
import json,time,requests,concurrent.futures
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'marking_semantics_audit';O.mkdir(exist_ok=True)
try:
 models=requests.get('https://huggingface.co/api/models',params=dict(search='mapillary',limit=60,sort='downloads',direction=-1),timeout=30);models.raise_for_status();models=models.json()
 def inspect(m):
  mid=m['id'];url='https://huggingface.co/'+mid+'/resolve/main/config.json'
  try:
   r=requests.get(url,timeout=20)
   if r.status_code!=200:return dict(model=mid,config_status=r.status_code)
   d=r.json();labels=d.get('id2label',{});terms={k:v for k,v in labels.items() if any(t in str(v).lower() for t in ['arrow','marking','crosswalk','sign'])};return dict(model=mid,config_url=url,model_type=d.get('model_type'),architectures=d.get('architectures'),num_labels=len(labels),relevant_labels=terms,arrow_classes=[v for v in labels.values() if 'arrow' in str(v).lower()])
  except Exception as e:return dict(model=mid,error=repr(e))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  records=[]
  for n,r in enumerate(pool.map(inspect,models)):records.append(r);(O/'status.json').write_text(json.dumps(dict(phase='auditing',completed=n+1,total=len(models),updated_at=time.time())))
 result=dict(phase='complete',source='Public Hugging Face model API and author config.json files; metadata only, not verified checkpoint quality/license.',records=records,arrow_candidates=[r for r in records if r.get('arrow_classes')],updated_at=time.time());(O/'summary.json').write_text(json.dumps(result,indent=2));(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=len(models),total=len(models),updated_at=time.time())));print(json.dumps({'checked':len(models),'arrow_candidates':result['arrow_candidates']},indent=2))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
