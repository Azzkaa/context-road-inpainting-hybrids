from pathlib import Path
import json,time,fcntl,subprocess
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'encoder_layout_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py=R/'work/inpainting_compare/venv/bin/python'
def active(path,title,total,loss=False):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Same decoder/data/objective; frozen versus adapted SegFormer lasttwo stages. Clean teacher pseudo-label supervision only; original Klein unchanged.',total=total,result_path='encoder_layout_review/',show_loss=loss,next_text='No-update memory/gradient gate first, then1,000updates and eight validation layouts.')))
def run(script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 (O/'protocol.json').write_text(json.dumps(dict(train_pairs=1000,updates_per_arm=1000,head_lr=.0003,encoder_lr=.00001,encoder_scope='SegFormer encoder stages2/3 only',frozen_scope='Stages0/1; original Klein and all its checkpoints untouched',same_source_weights=True,validation_images=8,supervision='Unverified cleanTRAIN Mapillary marking/crosswalk masks; no clean deployment input.'),indent=2))
 for arm in ['frozen','adapted']:active('encoder_layout_study/'+arm+'/status.json','Layout encoder: '+arm,1000,True);run('train_adapted_layout.py','--arm',arm)
 a=json.loads((O/'frozen/initialization.json').read_text());b=json.loads((O/'adapted/initialization.json').read_text());assert a['state_sha256']==b['state_sha256'];active('encoder_layout_study/evaluation_status.json','Generating encoder-adaptation comparison',8)
 for arm in ['frozen','adapted']:run('evaluate_adapted_layout.py','--arm',arm)
 G=P/'encoder_layout_review';G.mkdir(exist_ok=True);ids=json.loads((P/'lane_generation_protocol.json').read_text())['validation_ids'];page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white;margin:25px}a{color:#8df}img{width:100%}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}</style><h1>Layout encoder: frozen vs adapted</h1><p>Predicted marking/crosswalk maps only, not restored paint or verified accuracy. Left clean reference / middle frozen encoder / right adapted lasttwo encoder stages.</p><a href="../progress/">Live progress</a> · <a href="changes.html">Changes</a>'
 for sid in ids:page+='<h2>'+sid+'</h2><div class="grid">'+''.join('<img src="'+p+'">' for p in ['frozen/'+sid+'/clean_reference.png','frozen/'+sid+'/layout_overlay.png','adapted/'+sid+'/layout_overlay.png'])+'</div>'
 (G/'index.html').write_text(page);(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=16,total=16,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
