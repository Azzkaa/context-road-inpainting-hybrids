"""One-case full inference integration check with untrained spatial adapter; no updates."""
from pathlib import Path
import os,sys,json,time,hashlib
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';O=R/'outputs/lane_geometry/klein_hybrid/inspection';ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'));sys.path.insert(0,str(W/'klein_training_dependencies'));os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
import torch,numpy as np
from PIL import Image
from diffusers import Flux2Transformer2DModel,Flux2KleinPipeline,AutoencoderKLFlux2,FlowMatchEulerDiscreteScheduler,BitsAndBytesConfig
from peft import LoraConfig,set_peft_model_state_dict
from spatial_adapter import SpatialGeometryAdapter
from klein_bridge import condition_source
from road_only import compose_road
start=time.time();torch.set_num_threads(4);torch.manual_seed(20261122);prep=json.loads((O/'preparation.json').read_text());sid=prep['records'][0]['id'];dst=O/sid;data=torch.load(dst/'conditioning.pt',map_location='cpu',weights_only=False);assert data['split']=='validation';assert hashlib.sha256(Path(data['source']).read_bytes()).hexdigest()==data['source_sha256']
(O/'generation_status.json').write_text(json.dumps({'phase':'loading','id':sid,'optimizer_updates':0}))
try:
 m=Flux2Transformer2DModel.from_pretrained(W/'klein_base/transformer',local_files_only=True,torch_dtype=torch.float16,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'});m.add_adapter(LoraConfig(r=4,lora_alpha=4,target_modules=['to_q','to_k','to_v','to_out.0']));ck=torch.load(R/'outputs/lane_geometry/klein_paired_training/latest.pt',map_location='cpu',weights_only=False);assert ck['step']==6783;set_peft_model_state_dict(m,ck['adapter']);del ck;m.requires_grad_(False);m.eval()
 for mod in m.modules():
  if hasattr(mod,'compute_dtype'):mod.compute_dtype=torch.float16
 adapter=SpatialGeometryAdapter(input_channels=131).cuda().eval();adapter.requires_grad_(False);geometry=data['geometry'].cuda();calls=[]
 def source_hook(module,args,kwargs):
  hidden=kwargs['hidden_states'];assert hidden.shape[1]==2048,'Inspection supports one512 source only'
  with torch.autocast('cuda',dtype=torch.float16):source=condition_source(hidden[:,1024:],geometry,adapter,(32,32))
  kwargs['hidden_states']=torch.cat([hidden[:,:1024],source],dim=1);assert torch.count_nonzero(kwargs['encoder_hidden_states'])==0;calls.append(1);return args,kwargs
 handle=m.register_forward_pre_hook(source_hook,with_kwargs=True)
 vae=AutoencoderKLFlux2.from_pretrained(ROOT/'work/klein_local_20/models/klein_nf4/vae',local_files_only=True,torch_dtype=torch.float32).cuda();vae.enable_tiling();decode=vae.decode;vae.decode=lambda z,*a,**k:decode(z.float(),*a,**k)
 scheduler=FlowMatchEulerDiscreteScheduler.from_pretrained(ROOT/'work/klein_local_20/models/klein_nf4/scheduler',local_files_only=True);pipe=Flux2KleinPipeline(vae=vae,transformer=m,text_encoder=None,tokenizer=None,scheduler=scheduler,is_distilled=False);pipe.set_progress_bar_config(disable=True)
 original=np.array(Image.open(data['source']).convert('RGB'));h,w=original.shape[:2];s=min(512/w,512/h);nw,nh=round(w*s),round(h*s);left,top=(512-nw)//2,(512-nh)//2;a=np.array(Image.fromarray(original).resize((nw,nh),Image.Resampling.LANCZOS));square=Image.fromarray(np.pad(a,((top,512-nh-top),(left,512-nw-left),(0,0)),mode='edge'))
 (O/'generation_status.json').write_text(json.dumps({'phase':'generating','id':sid,'instruction':'none;zero context features','optimizer_updates':0}))
 with torch.inference_mode():raw=pipe(image=square,prompt_embeds=torch.zeros(1,512,7680,device='cuda',dtype=torch.float16),width=512,height=512,num_inference_steps=28,guidance_scale=1.,generator=torch.Generator(device='cuda').manual_seed(20261122)).images[0]
 assert len(calls)==28;raw=np.array(raw.crop((left,top,left+nw,top+nh)));Image.fromarray(raw).save(dst/'raw_null_text.png');mask=np.array(Image.open(dst/'permitted.png'))>0;result,allowed=compose_road(original,raw,mask,np.zeros_like(mask));Image.fromarray(result).save(dst/'road_only_output.png');assert np.array_equal(result,original),'Untrained all-keep head must not edit original'
 record={'phase':'complete','id':sid,'steps':28,'source_adapter_calls':len(calls),'context_nonzero_values':0,'text_encoder':None,'tokenizer':None,'geometry_shape':list(geometry.shape),'adapter_trained':False,'roi_head_trained':False,'final_output':'exact native original because edit-head initialization is all-keep','outside_mask_exact':bool(np.array_equal(result[~allowed],original[~allowed])),'optimizer_updates':0,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,'seconds':time.time()-start,'warning':'Architecture integration preview, not trained hybrid performance. Raw null-context image may be poor; do not promote it. Original instructed baseline preserved.'};(O/'generation_status.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
except Exception as e:(O/'generation_status.json').write_text(json.dumps({'phase':'failed','error':repr(e)}));raise
