"""Connect spatial prototype to packed source tokens; no language instruction."""
import torch

def condition_source(source_tokens,geometry,adapter,grid_size):
    residual=adapter(geometry,grid_size=grid_size)
    assert residual.shape==source_tokens.shape
    return source_tokens+residual.to(source_tokens.dtype)

def forward_text_free(transformer,adapter,target_tokens,source_tokens,geometry,timestep,img_ids,grid_size=(32,32),context_adapter=None):
    source=condition_source(source_tokens,geometry,adapter,grid_size)
    # Preserve interface with zero-valued positions, not an encoded/cached sentence.
    width=transformer.config.joint_attention_dim
    zeros=torch.zeros(target_tokens.shape[0],512,width,device=source.device,dtype=source.dtype) if context_adapter is None else context_adapter(geometry).to(source.dtype)
    assert zeros.shape==(target_tokens.shape[0],512,width)
    txt_ids=torch.zeros(target_tokens.shape[0],512,4,device=source.device,dtype=source.dtype)
    txt_ids[:,:,3]=torch.arange(512,device=source.device,dtype=source.dtype)
    return transformer(hidden_states=torch.cat([target_tokens,source],dim=1),encoder_hidden_states=zeros,timestep=timestep,img_ids=img_ids,txt_ids=txt_ids,guidance=None,return_dict=False)[0][:,:target_tokens.shape[1]]
