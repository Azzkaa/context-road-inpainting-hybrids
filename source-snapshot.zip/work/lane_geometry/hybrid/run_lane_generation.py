from pathlib import Path
import json,time,subprocess,fcntl,hashlib
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'lane_generation_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py='/path/to/user-home/anaconda3/envs/snow-edit/bin/python';protocol=json.loads((P/'lane_generation_protocol.json').read_text())
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
def active(path,title,total,loss):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Lane-generation comparison: same2400 warmstart,250 updates perarm. Weak paint-weighted TRAIN loss; no text or clean deployment guide.',total=total,result_path='lane_generation_review/',show_loss=loss,next_text='Eight validation scenes perarm, generated road paint compared side by side; no detector curves pasted onto outputs.')))
def run(interpreter,script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(interpreter),str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 assert hashlib.sha256((P/'secondpass_study/control/latest.pt').read_bytes()).hexdigest()==protocol['continuation_sha256']
 rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())}
 for sid in protocol['validation_ids']:assert rows[sid]['split']=='validation' and (R/'work/lane_geometry/hybrid_pilot_geometry'/(sid+'.pt')).exists()
 for arm in ['control','paint']:
  active('lane_generation_study/'+arm+'/status.json','Lane generation — '+arm+' training',250,True);status(phase='training',arm=arm,completed=0,total=250);run(py,'train_lane_generation.py','--arm',arm)
 gallery=P/'lane_generation_review'
 for sid in protocol['validation_ids']:
  ref=gallery/'references'/sid;ref.mkdir(parents=True,exist_ok=True)
  for key,name in [('clean','clean_reference.png'),('snowy','snowy.png')]:
   if not (ref/name).exists():(ref/name).symlink_to(rows[sid][key])
 active('lane_generation_study/status.json','Generating lane-focused comparison images',16,False);done=0
 for arm in ['control','paint']:
  for i,sid in enumerate(protocol['validation_ids']):
   if not (gallery/arm/sid/'road_only_output.png').exists():status(phase='generating',arm=arm,id=sid,completed=done,total=16);run(py,'evaluate_lane_generation.py','--arm',arm,'--index',str(i))
   assert (gallery/arm/sid/'raw_null_text.png').exists();done+=1;status(phase='generating',completed=done,total=16)
 status(phase='scoring',completed=16,total=16);run(R/'work/inpainting_compare/venv/bin/python','score_lane_generation.py');status(phase='complete',completed=16,total=16,result='/lane_geometry/klein_hybrid/lane_generation_review/')
except Exception as e:status(phase='failed',error=repr(e));raise
