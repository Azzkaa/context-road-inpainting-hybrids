from pathlib import Path
import json,hashlib,time
import torch,cv2
from condlane_features import CondLaneFeatures,preprocess,CK,SRC,R
torch.set_num_threads(4);start=time.time();device='cuda' if torch.cuda.is_available() else 'cpu';m=CondLaneFeatures().to(device).eval()
rows=sorted([r for r in json.loads((R/'work/road_restoration/manifest.json').read_text()) if r['split']=='validation'],key=lambda r:r['id'])[:3];records=[];O=R/'outputs/lane_geometry/klein_hybrid'
for r in rows:
 im=cv2.imread(r['snowy']);x,meta=preprocess(im)
 with torch.inference_mode():ys=m(x.to(device));blank=m(torch.zeros_like(x).to(device))
 assert all(torch.isfinite(y).all() for y in ys);assert all(y.shape[1]==64 for y in ys);diff=sum(float((y-z).abs().mean()) for y,z in zip(ys,blank));assert diff>0
 records.append({'id':r['id'],'split':r['split'],'feature_shapes':[list(y.shape) for y in ys],'source_vs_blank_mean_change':diff,'preprocess':meta})
result={'phase':'passed','device':device,'backbone_and_neck_checkpoint_load':'strict; no missing/unexpected keys','checkpoint_sha256':hashlib.sha256(CK.read_bytes()).hexdigest(),'reused_components':'official checkpoint ResNet18 backbone + official TransConvFPN neck; head NOT loaded/used','compatibility_edits':'legacy fp16 decorator is identity in FP32 evaluation; fixed position embeddings constructed on CPU then official forward moves them to source device','records':records,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30 if device=='cuda' else None,'seconds':time.time()-start,'limitations':['No complete CondLaneNet detection/postprocessing yet','No verified output parity against legacy runtime; strict weights/equations reuse is not parity proof','No lane confidence/curve maps produced by this feature extractor','Validation source only; no training or GT accuracy claims']}
(O/'condlane_feature_check.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
