from pathlib import Path
import subprocess,json,time,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'directional_instance_pass1';lock=(O/'sequence.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);py=R/'work/inpainting_compare/venv/bin/python';H=R/'work/lane_geometry/hybrid'
try:
 with (O/'sequence.log').open('a') as log:
  subprocess.run([str(py),str(H/'train_instance_pass1.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
  (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path='directional_instance_pass1_evaluation/status.json',title='First object-query pass: full228validation',description='Class-aware one-to-one objectF1 and regionIoU, confidence/mask0.5, overlap0.8. External clear-road regions only.',total=228,result_path='directional_instance_pass1_review/',show_loss=False,next_text='Inspect perclass errors and visual previews before any further training.')))
  subprocess.run([str(py),str(H/'evaluate_instance_pass1.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
except Exception as e:(O/'sequence_status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
