"""Rebuild the frozen six-case architecture inspection; no training or optimizer steps."""
from pathlib import Path
import subprocess,json
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';H=W/'hybrid';O=R/'outputs/lane_geometry/klein_hybrid'
jobs=[(W/'venv/bin/python','audit_aligned_features.py'),(R/'work/inpainting_compare/venv/bin/python','prepare_inspection.py'),(Path('/path/to/user-home/anaconda3/envs/snow-edit/bin/python'),'inspect_generate.py'),(R/'work/inpainting_compare/venv/bin/python','build_inspection_page.py')]
with (O/'rebuild_inspection.log').open('w') as log:
 for interpreter,script in jobs:subprocess.run([str(interpreter),str(H/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Inspection ready: http://127.0.0.1:43079/lane_geometry/klein_hybrid/inspection/')
