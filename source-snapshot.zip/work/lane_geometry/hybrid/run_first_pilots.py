"""Serial finite pilot sequence; stop on failure, never overload GPU."""
from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';W=R/'work/lane_geometry';H=W/'hybrid';O=P/'first_pilots';O.mkdir(exist_ok=True);lock=(O/'runner.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def status(**d):(O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
def run(py,script):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 status(phase='waiting_roi_pilot')
 while True:
  s=json.loads((P/'roi_pilot/status.json').read_text())
  if s['phase']=='failed':raise RuntimeError('ROI pilot failed: '+s.get('error',''))
  if s['phase']=='complete':break
  time.sleep(10)
 snow=Path('/path/to/user-home/anaconda3/envs/snow-edit/bin/python');old=R/'work/inpainting_compare/venv/bin/python';lane=W/'venv/bin/python'
 run(old,'report_roi_pilot.py')
 status(phase='image_context_full_model_gate');run(snow,'check_image_context_full.py')
 status(phase='caching_frozen_expert_features');run(lane,'cache_pilot_features.py')
 status(phase='caching_predicted_geometry');run(old,'cache_pilot_geometry.py')
 status(phase='image_context_training_25_updates');run(snow,'train_image_pilot.py')
 status(phase='first_image_preview');run(snow,'evaluate_image_pilot.py')
 status(phase='complete_pending_visual_review',result='/lane_geometry/klein_hybrid/image_pilot_review/')
except Exception as e:status(phase='failed',error=repr(e));raise
