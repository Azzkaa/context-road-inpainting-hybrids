"""Whole-object silhouette recognition diagnostic. Author shapes are oracle inputs, NOT deployment accuracy."""
from pathlib import Path
import json,time,torch,numpy as np,fcntl
from PIL import Image,ImageDraw
from torch import nn
from ceymo_layout import CLASSES
import argparse
a=argparse.ArgumentParser();a.add_argument('--arm',choices=['clean_control','mixed_predicted'],required=True);args=a.parse_args()
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'marking_shape_domain_study'/args.arm;O.mkdir(exist_ok=True,parents=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);torch.set_num_threads(4);torch.manual_seed(20261125);np.random.seed(20261125)
from marking_shape import ShapeClassifier,normalize
def status(phase,i,total=1000): (O/'status.json').write_text(json.dumps(dict(phase=phase,completed=i,total=total,updated_at=time.time())))
try:
 p=json.loads((P/'ceymo_pretraining/protocol.json').read_text());data={};audit={};status('preparing_author_shapes',0)
 for split in ['external_train','external_validation']:
  xs=[];ys=[];ids=[]
  for row in p[split]:
   a=json.loads(Path(row['polygon_annotation']).read_text());w,h=a['imageWidth'],a['imageHeight']
   for s in a['shapes']:
    mask=Image.new('L',(w,h));ImageDraw.Draw(mask).polygon([tuple(v) for v in s['points']],fill=255);xs.append(normalize(mask));ys.append(CLASSES[1:].index(s['label']));ids.append(row['id'])
  data[split]=(torch.from_numpy(np.stack(xs))[:,None].float()/255,torch.tensor(ys));audit[split]=dict(objects=len(xs),image_ids=ids,class_counts=np.bincount(ys,minlength=11).tolist())
 (O/'target_audit.json').write_text(json.dumps(dict(phase='passed',splits=audit,semantics='Actual author polygon silhouettes, tight nonzero crop + aspect-preserving128letterbox. GT shape is oracle input; not deployed inference. No image filename/class encoded in inputs.'),indent=2))
 assert json.loads((P/'predicted_shape_training_audit/cache_audit.json').read_text())['phase']=='passed'
 px=[];py=[]
 for row in p['external_train']:
  ck=torch.load(R/'work/lane_geometry/predicted_shape_training_cache'/(row['id']+'.pt'),map_location='cpu',weights_only=False);valid=ck['author_labels']>=0;px.append(ck['shapes'][valid]);py.append(ck['author_labels'][valid])
 px=torch.cat(px)[:,None].float()/255;py=torch.cat(py);pc=torch.bincount(py,minlength=11).float();pw=1/pc[py]
 m=ShapeClassifier().cuda();opt=torch.optim.AdamW(m.parameters(),lr=3e-4,weight_decay=.01);x,y=data['external_train'];counts=torch.bincount(y,minlength=11).float();sampleweights=1/counts[y];start=0;records=[]
 if not (O/'latest.pt').exists():
  import shutil
  shutil.copy2(P/'marking_shape_pilot/latest.pt',O/'latest.pt')
 if (O/'latest.pt').exists():
  ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);m.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);start=ck['step'];records=ck['records'];torch.set_rng_state(ck['rng']);torch.cuda.set_rng_state(ck['cuda_rng'])
 def evaluate(step):
  m.eval();vx,vy=data['external_validation'];pred=[]
  with torch.inference_mode():
   for i in range(0,len(vy),64):pred.extend(m(vx[i:i+64].cuda()).argmax(1).cpu().tolist())
  cm=np.bincount(vy.numpy()*11+np.array(pred),minlength=121).reshape(11,11);scores={}
  for c,name in enumerate(CLASSES[1:]):
   tp=int(cm[c,c]);fp=int(cm[:,c].sum()-tp);fn=int(cm[c].sum()-tp);scores[name]=dict(tp=tp,fp=fp,fn=fn,f1=2*tp/max(1,2*tp+fp+fn))
  r=dict(step=step,objects=len(vy),oracle_shape_classification_accuracy=float(np.trace(cm)/cm.sum()),scores=scores,confusion=cm.tolist(),warning='ORACLE author polygon crops supplied. Recognition diagnostic only, not detector accuracy, snow recovery or paint generation.');(O/('validation_%d.json'%step)).write_text(json.dumps(r,indent=2));m.train()
 if start==1000:
  evaluate(1000);ix=torch.multinomial(sampleweights,32,replacement=True);torch.cuda.reset_peak_memory_stats();loss=nn.functional.cross_entropy(m(x[ix].cuda()),y[ix].cuda());loss.backward();assert torch.isfinite(loss) and all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None);peak=torch.cuda.max_memory_allocated()/2**30;assert peak<1;opt.zero_grad(set_to_none=True);torch.save(m.state_dict(),O/'initial.pt');loaded=torch.load(O/'initial.pt',map_location='cpu',weights_only=True);assert all(torch.equal(v.cpu(),loaded[k]) for k,v in m.state_dict().items());(O/'gate.json').write_text(json.dumps(dict(phase='passed',no_optimizer_yet=True,finite_gradients=True,peak_gib=peak,checkpoint_reload_exact=True,parameters=sum(p.numel() for p in m.parameters()))))
 for i in range(start,2000):
  xx,yy,ww=(px,py,pw) if args.arm=='mixed_predicted' and i%2 else (x,y,sampleweights);ix=torch.multinomial(ww,32,replacement=True);opt.zero_grad(set_to_none=True);loss=nn.functional.cross_entropy(m(xx[ix].cuda()),yy[ix].cuda());assert torch.isfinite(loss);loss.backward();assert all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None);opt.step();records.append(dict(step=i+1,loss=float(loss)));status('training_'+args.arm,i+1-1000)
  if i+1 in [1002,1100,1250,1500,1750,2000]:
   torch.save(dict(model=m.state_dict(),optimizer=opt.state_dict(),step=i+1,records=records,rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state()),O/'latest.tmp');(O/'latest.tmp').replace(O/'latest.pt')
  if i+1 in [1250,1500,2000]:evaluate(i+1)
 status('complete',1000)
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
