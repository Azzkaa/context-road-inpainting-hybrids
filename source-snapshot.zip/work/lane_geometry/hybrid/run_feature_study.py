from pathlib import Path
import json,subprocess,time,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'feature_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);py='/path/to/user-home/anaconda3/envs/snow-edit/bin/python';H=R/'work/lane_geometry/hybrid'
def status(**d):(O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
def run(script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([py,str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 assert json.loads((P/'attention_scope_gate.json').read_text())['phase']=='passed'
 for arm in ['control','clr_only']:
  (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path='feature_study/'+arm+'/status.json',title='Geometry conditioning: '+arm,description='Matched both-expert versus CLR-only training; no text, parent frozen.',total=100,result_path='feature_study_review/',show_loss=True,next_text='Four fixed validation cases per arm, then CPU metrics.')));status(phase='training',arm=arm,additional_updates=100);run('train_feature_study.py','--arm',arm)
 for arm in ['control','clr_only']:
  for i in range(4):status(phase='evaluating',arm=arm,completed=i,total=4);run('evaluate_feature_study.py','--arm',arm,'--index',str(i))
 status(phase='scoring')
 with (O/'sequence.log').open('a') as log:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(H/'score_feature_study.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
 status(phase='complete',completed=8,total=8,result='/lane_geometry/klein_hybrid/feature_study_review/')
except Exception as e:status(phase='failed',error=repr(e));raise
