"""TRAIN-only fixed feature-source ablation; no optimizer or output selection on TEST."""
from pathlib import Path
import sys,os,json,time
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';P=R/'outputs/lane_geometry/klein_hybrid';O=P/'feature_source_audit';O.mkdir(exist_ok=True);ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'));sys.path.insert(0,str(W/'klein_training_dependencies'));os.environ['HF_HUB_OFFLINE']='1'
import torch
from diffusers import Flux2Transformer2DModel,Flux2KleinPipeline,BitsAndBytesConfig
from peft import LoraConfig,set_peft_model_state_dict
from spatial_adapter import SpatialGeometryAdapter
from image_context import ImageContextAdapter
from klein_bridge import forward_text_free
protocol=json.loads((P/'attention_study_protocol.json').read_text());ids=protocol['train_ids'][:8];gains=['both','clr_only','cond_only','neither'];torch.set_num_threads(4);torch.manual_seed(20261122);records=[];start=time.time()
def status(**d):(O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
class Gain(torch.nn.Module):
 def __init__(self,model):super().__init__();self.model=model;self.gain=1.
 def forward(self,x):return self.model(x)*self.gain
try:
 status(phase='loading',completed=0,total=32)
 m=Flux2Transformer2DModel.from_pretrained(W/'klein_base/transformer',local_files_only=True,torch_dtype=torch.float16,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'});m.add_adapter(LoraConfig(r=4,lora_alpha=4,target_modules=['to_q','to_k','to_v','to_out.0']));ck=torch.load(P/'attention_study/control/latest.pt',map_location='cpu',weights_only=False);assert ck['step']==300;set_peft_model_state_dict(m,ck['attention_adapter']);m.requires_grad_(False);m.eval()
 for mod in m.modules():
  if hasattr(mod,'compute_dtype'):mod.compute_dtype=torch.float16
 spatial=SpatialGeometryAdapter(input_channels=131).cuda().eval();context=Gain(ImageContextAdapter().cuda().eval());spatial.load_state_dict(ck['spatial']);context.model.load_state_dict(ck['context']);spatial.requires_grad_(False);context.requires_grad_(False);del ck
 for sid in ids:
  d=torch.load(W/'klein_full_cache'/(sid+'_512.pt'),map_location='cuda',weights_only=False);g=torch.load(W/'hybrid_pilot_geometry'/(sid+'.pt'),map_location='cuda',weights_only=False);assert d['split']==g['split']=='train';clean=d['clean'];noise=torch.randn_like(clean);sigma=torch.tensor([.5],device='cuda');x=Flux2KleinPipeline._pack_latents(.5*clean+.5*noise).half();source=Flux2KleinPipeline._pack_latents(d['snowy']).half();target=Flux2KleinPipeline._pack_latents(noise-clean).float();ids4=torch.cat([d['target_ids'],d['source_ids']],dim=1);weights=g['loss_weights'].flatten(2).transpose(1,2)
  for gain in gains:
   geometry=g['geometry'].float().clone()
   if gain in ('cond_only','neither'):geometry[:,3:67]=0
   if gain in ('clr_only','neither'):geometry[:,67:131]=0
   with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):pred=forward_text_free(m,spatial,x,source,geometry,sigma,ids4,context_adapter=context)
   loss=float((((pred.float()-target).square()*weights).sum()/(weights.sum()*pred.shape[-1])).item());assert torch.isfinite(pred).all();records.append({'id':sid,'variant':gain,'weighted_velocity_mse':loss});status(phase='checking',completed=len(records),total=32);print(sid,gain,loss,flush=True)
 means={str(g):sum(r['weighted_velocity_mse'] for r in records if r['variant']==g)/len(ids) for g in gains};s={'phase':'complete','train_cases':8,'feature_variants':gains,'sigma':.5,'checkpoint':'control300','means':means,'records':records,'optimizer_updates':0,'seconds':time.time()-start,'interpretation':'TRAIN-only velocity prediction diagnostic at one noise level, not image quality or lane accuracy. Same noise per case across feature variants. Zeroing feature groups is an out-of-distribution diagnostic, not a separately trained ablation. No text features loaded or copied.'};(O/'summary.json').write_text(json.dumps(s,indent=2));status(**s)
except Exception as e:status(phase='failed',error=repr(e),completed=len(records),total=32);raise
