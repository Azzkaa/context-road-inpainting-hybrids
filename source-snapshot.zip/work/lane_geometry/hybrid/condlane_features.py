"""Isolated CondLaneNet-small backbone/neck reuse. NOT the full lane detector.
Official neck equations retained; adapt constructor-only position placement for CPU.
No mmdet package changes. No legacy binary-op installation. No text conditioning.
"""
from pathlib import Path
import math,hashlib
import torch,numpy as np
from torch import nn
from torch.nn import functional as F
from torchvision.models import resnet18
from mmcv.cnn import ConvModule
from mmengine.model import xavier_init
R=Path(__file__).resolve().parents[3];SRC=R/'work/lane_geometry/CondLaneNet';CK=R/'work/lane_geometry/models/condlanenet_culane_small.pth'
class Registry:
 def register_module(self):return lambda cls:cls
def auto_fp16(*args,**kwargs):return lambda fn:fn
class CondLaneFeatures(nn.Module):
 def __init__(self):
  super().__init__();backbone=resnet18(weights=None);backbone.fc=nn.Identity();self.backbone=backbone
  source=(SRC/'mmdet/models/necks/trans_fpn.py').read_text();source=source.replace('from mmcv.cnn import ConvModule, xavier_init','from mmcv.cnn import ConvModule\nfrom mmengine.model import xavier_init').replace('from mmdet.core import auto_fp16','').replace('from ..builder import NECKS','').replace('build_position_encoding(dim, pos_shape).cuda()','build_position_encoding(dim, pos_shape)')
  scope={'__name__':'isolated_condlane_neck','auto_fp16':auto_fp16,'NECKS':Registry()};exec(compile(source,str(SRC/'mmdet/models/necks/trans_fpn.py'),'exec'),scope)
  self.neck=scope['TransConvFPN'](in_channels=[128,256,64],out_channels=64,num_outs=3,trans_idx=-1,trans_cfg=dict(in_dim=512,attn_in_dims=[512,64],attn_out_dims=[64,64],strides=[1,1],ratios=[4,4],pos_shape=(1,10,25)))
  ck=torch.load(CK,map_location='cpu',weights_only=False)['state_dict'];self.backbone.load_state_dict({k[len('backbone.'):]:v for k,v in ck.items() if k.startswith('backbone.')},strict=True);self.neck.load_state_dict({k[len('neck.'):]:v for k,v in ck.items() if k.startswith('neck.')},strict=True)
  self.requires_grad_(False);self.eval()
 def forward(self,x):
  b=self.backbone;x=b.maxpool(b.relu(b.bn1(b.conv1(x))));features=[]
  for layer in [b.layer1,b.layer2,b.layer3,b.layer4]:x=layer(x);features.append(x)
  return self.neck(features)[0]
def preprocess(bgr):
 import cv2
 h,w=bgr.shape[:2];cut=round(h*270/590);a=cv2.resize(bgr[cut:],(800,320),interpolation=cv2.INTER_LINEAR).astype(np.float32)
 a=(a-np.array([75.3,76.6,77.6],np.float32))/np.array([50.5,53.8,54.3],np.float32)
 return torch.from_numpy(a.copy()).permute(2,0,1)[None],{'crop_top':cut,'full_size':[w,h],'input_size':[800,320],'convention':'crop feature maps must be mapped into original lower region; they are not full-image maps'}
