from pathlib import Path
import json
import numpy as np,torch
from PIL import Image
import lpips
from skimage.metrics import structural_similarity
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'expanded_study_review';ids=json.loads((P/'expanded_study_protocol.json').read_text())['validation_ids'];manifest={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};torch.set_num_threads(4);metric=lpips.LPIPS(net='alex',verbose=False).cpu().eval();records=[]
for sid in ids:
 size=Image.open(O/'control'/sid/'raw_null_text.png').size;target=np.array(Image.open(manifest[sid]['clean']).convert('RGB').resize(size,Image.Resampling.LANCZOS));mask=np.array(Image.open(manifest[sid]['mask']).convert('L').resize(size,Image.Resampling.NEAREST))>127
 for arm in ['control','expanded']:
  for kind,file in [('raw','raw_null_text.png'),('composite','road_only_output.png')]:
   a=np.array(Image.open(O/arm/sid/file).convert('RGB').resize(size,Image.Resampling.LANCZOS));x=torch.from_numpy(a.copy()).permute(2,0,1)[None].float()/127.5-1;y=torch.from_numpy(target.copy()).permute(2,0,1)[None].float()/127.5-1
   with torch.inference_mode():percept=float(metric(x,y).item())
   aa=a.astype(float)/255;bb=target.astype(float)/255;err=((aa-bb)**2)[mask].mean();_,ss=structural_similarity(aa,bb,data_range=1,channel_axis=2,full=True,gaussian_weights=True,sigma=1.5,use_sample_covariance=False);records.append({'id':sid,'arm':arm,'kind':kind,'lpips':percept,'edit_psnr_db':float(-10*np.log10(max(err,1e-12))),'edit_ssim':float(ss.mean(2)[mask].mean())})
means={arm:{kind:{k:float(np.mean([r[k] for r in records if r['arm']==arm and r['kind']==kind])) for k in ['lpips','edit_psnr_db','edit_ssim']} for kind in ['raw','composite']} for arm in ['control','expanded']};summary={'phase':'complete','validation_pairs':4,'arms':'One bounded pass over1000 distinct TRAIN pairs, warmstart dual400, context/spatial only. Frozen instructed parent; no text; no TEST tuning. Compare to step400 on existing four development cases.','mean':means,'warning':'Small development comparison; no verified lane accuracy; original instructed TEST unchanged; masks identical across study arms and still imperfect.'};(O/'metrics.json').write_text(json.dumps({'summary':summary,'records':records},indent=2))
page='<meta charset="utf-8"><style>body{background:#122033;color:white;font:17px system-ui;margin:25px}a{color:#8df}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}img{width:100%}figure{margin:0}td,th{padding:12px}</style><h1>Expanded 1k adaptation controlled comparison</h1><p><a href="../progress/">Live progress</a></p><p>Control is the preserved400-update dual-feature model. Expanded branch adds1000updates covering1000 TRAIN pairs; paired inference seeds and masks remain identical. No language conditioning in either. Not lane accuracy.</p><table><tr><th>Arm/raw output</th><th>LPIPS ↓</th><th>Edit PSNR ↑</th><th>Edit SSIM ↑</th></tr>'
for arm,v in means.items():m=v['raw'];page+=f'<tr><td>{arm}</td><td>{m["lpips"]:.4f}</td><td>{m["edit_psnr_db"]:.2f}</td><td>{m["edit_ssim"]:.4f}</td></tr>'
page+='</table>'
for sid in ids:
 page+='<h2>'+sid+'</h2><div class="grid">'
 for path,label in [(f'../../image_pilot200_review/{sid}/clean_reference.png','Clean reference only'),(f'control/{sid}/raw_null_text.png','Control raw'),(f'expanded/{sid}/raw_null_text.png','Expanded 1k raw'),(f'../../image_pilot200_review/{sid}/snowy.png','Snow input'),(f'control/{sid}/road_only_output.png','Control composite'),(f'expanded/{sid}/road_only_output.png','Expanded 1k composite')]:page+=f'<figure><img src="{path}"><figcaption>{label}</figcaption></figure>'
 page+='</div>'
# References are sibling directories relative to this gallery.
page=page.replace('../../image_pilot200_review/','../image_pilot200_review/');(O/'index.html').write_text(page);print(json.dumps(summary,indent=2))
