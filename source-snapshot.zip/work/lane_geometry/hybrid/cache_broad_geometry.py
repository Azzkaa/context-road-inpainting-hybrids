from pathlib import Path
import sys,json,hashlib
import numpy as np,torch
from PIL import Image
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
from broad_selection import selection,R
from edit_roi_head import EditROIHead
from feature_alignment import align_crop_features,normalize_expert,combined_inputs
P=R/'outputs/lane_geometry/klein_hybrid';O=P/'broad_geometry_cache';O.mkdir(exist_ok=True);C=R/'work/lane_geometry/hybrid_pilot_geometry';C.mkdir(exist_ok=True);rows,train,val=selection();MP=R/'work/snow_replacements820/cityscapes_model';torch.set_num_threads(4);model=SegformerForSemanticSegmentation.from_pretrained(MP,local_files_only=True).cuda().eval();model.requires_grad_(False);proc=SegformerImageProcessor.from_pretrained(MP,local_files_only=True);head=EditROIHead().cuda().eval();ck=torch.load(P/'roi_pilot/best.pt',map_location='cpu',weights_only=False);assert ck['trained'];head.load_state_dict(ck['head']);roi_sha=hashlib.sha256((P/'roi_pilot/best.pt').read_bytes()).hexdigest()
for i,sid in enumerate(train+val):
 r=rows[sid];existing=C/(sid+'.pt')
 if existing.exists():
  previous=torch.load(existing,map_location='cpu',weights_only=False);assert previous['source_sha256']==r['snowy_sha256'] and previous['roi_sha256']==roi_sha and previous['split']==r['split'];assert previous['geometry'].shape==(1,131,32,32);continue
 im=Image.open(r['snowy']).convert('RGB');w,h=im.size
 with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):
  f=model.segformer(**proc(images=im,return_tensors='pt').to('cuda'),output_hidden_states=True).hidden_states;sem=model.decode_head(f).float()
 with torch.inference_mode():
  prob=head([x.float() for x in f],(h,w)).sigmoid();sem=torch.nn.functional.interpolate(sem,size=(h,w),mode='bilinear',align_corners=False);labels=sem.argmax(1,keepdim=True);protected=(labels==1)|(labels>=11);side=sem.softmax(1)[:,1:2];permit=(prob>=.5)&~protected
 road=align_crop_features(permit.float(),w,h,0).cpu();protect=align_crop_features(protected.float(),w,h,0).cpu();context=align_crop_features(side,w,h,0).cpu();data=torch.load(R/'work/lane_geometry/hybrid_pilot_features'/(sid+'.pt'),map_location='cpu',weights_only=False);assert data['source_sha256']==r['snowy_sha256'];geometry=combined_inputs(road,protect,context,normalize_expert(data['clr'].float()),normalize_expert(data['cond'].float()))
 mask=Image.open(r['mask']).convert('L').resize((w,h),Image.Resampling.NEAREST);a=torch.from_numpy((np.array(mask)>127).copy())[None,None].float();target_roi=align_crop_features(a,w,h,0);valid=align_crop_features(torch.ones_like(a),w,h,0);weights=.25*valid+1.75*target_roi
 record={'id':sid,'split':r['split'],'source_sha256':r['snowy_sha256'],'geometry':geometry.half(),'loss_weights':weights.float(),'permitted_native':permit[0,0].cpu().byte(),'roi_sha256':roi_sha,'roi_step':ck['step'],'warning':'loss_weights are historical TRAIN supervision only; geometry uses predicted input-only masks'};torch.save(record,C/(sid+'.pt'));(O/'status.json').write_text(json.dumps({'phase':'caching','completed':i+1,'total':len(train)+len(val)}));print(i+1,sid,flush=True)
(O/'summary.json').write_text(json.dumps({'phase':'complete','train':len(train),'validation':len(val),'roi_checkpoint_sha256':roi_sha,'conditioning':'predicted masks + normalized frozen lane expert features','loss_weight_semantics':'verified historical edit region2.0,context.25,padding0; not lane labels'},indent=2))
