from pathlib import Path
import json,random
R=Path(__file__).resolve().parents[3]
def selection():
 rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};train=sorted(i for i,r in rows.items() if r['split']=='train');random.Random(20261122).shuffle(train);val=json.loads((R/'work/lane_geometry/evaluation_panels.json').read_text())['validation_annotation'][:4]
 return rows,train[:128],val
if __name__=='__main__':
 rows,train,val=selection();p=R/'outputs/lane_geometry/klein_hybrid/image_pilot_protocol.json';protocol={'train_ids':train,'validation_ids':val,'updates':25,'seed':20261122,'inference_steps':28,'parent_updates':6783,'trainable':'new image-context adapter +131channel spatial adapter only','frozen':'Klein base and completed parent LoRA','flow_loss_weight':'verified TRAIN edit2.0/context0.25; padding0.0','lr':.001,'input':'snowRGB, predicted edit/protection/sidewalk features, frozen experts; no text/clean guide','warning':'Small development smoke/pilot, not full training or lane accuracy'}
 if p.exists():assert json.loads(p.read_text())==protocol
 else:p.write_text(json.dumps(protocol,indent=2))
 print('Frozen128TRAIN/4VALIDATION/25updates protocol')
