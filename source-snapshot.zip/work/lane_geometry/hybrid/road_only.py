"""Native RGB compositing. Mask correctness is a separate semantic responsibility."""
import numpy as np
from PIL import Image

def compose_road(original,generated,road_mask,protected_mask,alpha=None):
    original=np.asarray(original);generated=np.asarray(generated)
    assert original.dtype==np.uint8 and original.ndim==3 and original.shape[2]==3
    assert generated.dtype==np.uint8 and generated.ndim==3 and generated.shape[2]==3
    h,w=original.shape[:2]
    road=np.asarray(road_mask);protected=np.asarray(protected_mask)
    assert road.dtype==bool and protected.dtype==bool and road.shape==protected.shape==(h,w)
    permitted=road & ~protected
    if generated.shape!=original.shape:
        generated=np.array(Image.fromarray(generated).resize((w,h),Image.Resampling.LANCZOS))
    if alpha is None:weight=permitted.astype(np.float32)
    else:
        weight=np.asarray(alpha,dtype=np.float32)
        assert weight.shape==(h,w) and np.isfinite(weight).all() and weight.min()>=0 and weight.max()<=1
        weight=weight*permitted
    # Copy original first; never re-encode/resize original before the pixel assertion.
    result=original.copy();inside=weight>0
    mixed=np.rint(original[inside].astype(np.float64)*(1-weight[inside,None])+generated[inside].astype(np.float64)*weight[inside,None])
    result[inside]=np.clip(mixed,0,255).astype(np.uint8)
    assert np.array_equal(result[~permitted],original[~permitted])
    return result,permitted
