from pathlib import Path
import subprocess,json,time,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'directional_instance_class_study';lock=(O/'sequence.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);py=R/'work/inpainting_compare/venv/bin/python';H=R/'work/lane_geometry/hybrid'
def active(arm,evaluation=False):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=('directional_instance_class_evaluation/' if evaluation else 'directional_instance_class_study/')+arm+'/status.json',title='Object class weighting: '+arm+(' validation' if evaluation else ' second pass'),description='Matched control/weighted classCE, identical source checkpoint/optimizer/RNG/data order. TRAIN count weights only; no-object/matching/mask losses unchanged.',total=228 if evaluation else 1871,result_path='directional_instance_class_review/',show_loss=not evaluation,next_text='Compare full228class-specific F1 and inspect same13previews; no automatic promotion.')))
try:
 with (O/'sequence.log').open('a') as log:
  for arm in ['control','weighted']:
   active(arm);subprocess.run([str(py),str(H/'train_instance_class_study.py'),'--arm',arm],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True);active(arm,True);subprocess.run([str(py),str(H/'evaluate_instance_class_study.py'),'--arm',arm],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
 (O/'status.json').write_text(json.dumps(dict(phase='complete',completed=2,total=2,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
