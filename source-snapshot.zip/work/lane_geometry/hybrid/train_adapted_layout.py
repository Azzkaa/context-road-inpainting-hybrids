from pathlib import Path
import argparse,json,time,torch,hashlib
from adapted_layout import AdaptedLayout
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';a=argparse.ArgumentParser();a.add_argument('--arm',choices=['frozen','adapted'],required=True);args=a.parse_args();O=P/'encoder_layout_study'/args.arm;O.mkdir(parents=True,exist_ok=True);audit=json.loads((P/'expanded_layout_cache/audit.json').read_text());assert audit['phase']=='passed';ids=json.loads((P/'expanded_layout_protocol.json').read_text())['train_ids'];torch.set_num_threads(4);m=AdaptedLayout(R/'work/snow_replacements820/cityscapes_model',adapt=args.arm=='adapted').cuda();encoder=[p for p in m.backbone.parameters() if p.requires_grad];head=[p for n,p in m.named_parameters() if not n.startswith('backbone.')];assert (len(encoder)>0)==(args.arm=='adapted');groups=[dict(params=head,lr=.0003)]
if encoder:groups.append(dict(params=encoder,lr=.00001))
opt=torch.optim.AdamW(groups,weight_decay=.01);config=json.loads((R/'work/snow_replacements820/cityscapes_model/preprocessor_config.json').read_text());mean=torch.tensor(config['image_mean'],device='cuda')[None,:,None,None];std=torch.tensor(config['image_std'],device='cuda')[None,:,None,None];records=[];done=0
# Hash initialization values, independent of requires_grad flags.
h=hashlib.sha256()
for name,value in sorted(m.state_dict().items()):h.update(name.encode());h.update(value.detach().cpu().numpy().tobytes())
(O/'initialization.json').write_text(json.dumps(dict(state_sha256=h.hexdigest(),encoder_trainable=sum(p.numel() for p in encoder),head_trainable=sum(p.numel() for p in head),scope='Only SegFormer stages2/3 adapted; stages0/1frozen. No Klein updates.')))
if (O/'latest.pt').exists():
 ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert ck['train_ids']==ids;m.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);done=ck['step'];records=ck['records']
try:
 for i in range(done,1000):
  sid=ids[i];rgb=torch.load(R/'work/lane_geometry/rgb_cache'/(sid+'.pt'),map_location='cuda',weights_only=False);g=torch.load(R/'work/lane_geometry/hybrid_pilot_geometry'/(sid+'.pt'),map_location='cuda',weights_only=False);t=torch.load(R/'work/lane_geometry/marking_teacher_targets'/(sid+'.pt'),map_location='cuda',weights_only=False);assert g['split']==t['split']=='train' and rgb['clean_sha256']==t['clean_sha256'] and rgb['snowy_sha256']==g['source_sha256'];pixels=(rgb['snow'][None].float()/255-mean)/std;target=t['target'].float()[None];valid=torch.nn.functional.avg_pool2d(rgb['valid'][None].float(),4,4);weight=.25*valid+.75*t['weight'].float()[None];opt.zero_grad(set_to_none=True);logits=m(pixels,g['geometry'].float());pred=logits.sigmoid();loss=(torch.nn.functional.binary_cross_entropy_with_logits(logits,target,reduction='none',pos_weight=torch.tensor([8.,8.],device='cuda')[None,:,None,None])*weight).sum()/(weight.sum()*2).clamp_min(1)+1-(2*(pred*target*weight).sum()+1)/((pred*weight).sum()+(target*weight).sum()+1);assert torch.isfinite(loss);loss.backward();params=head+encoder;assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params);assert all(p.grad is None for p in m.backbone.parameters() if not p.requires_grad);torch.nn.utils.clip_grad_norm_(params,1.)
  if i==0:
   assert torch.cuda.max_memory_allocated()/2**30<6.8
   if encoder:assert any(p.grad is not None and p.grad.abs().sum()>0 for p in encoder)
   (O/'gate.json').write_text(json.dumps(dict(passed=True,optimizer_updates=0,finite_gradients=True,frozen_scope_intact=True,peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30)))
  opt.step();records.append(dict(step=i+1,id=sid,loss=float(loss.detach())));(O/'status.json').write_text(json.dumps(dict(phase='training',completed=i+1,total=1000,records=records,updated_at=time.time())))
  if i+1==2 or (i+1)%100==0:
   ck=dict(model={k:v.cpu() for k,v in m.state_dict().items()},optimizer=opt.state_dict(),step=i+1,records=records,train_ids=ids,arm=args.arm);tmp=O/'latest.tmp';torch.save(ck,tmp);tmp.replace(O/'latest.pt');reload=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert all(torch.equal(v.cpu(),reload['model'][k]) for k,v in m.state_dict().items())
 (O/'status.json').write_text(json.dumps(dict(phase='complete',completed=1000,total=1000,updated_at=time.time(),warning='Teacher pseudo-label supervision, not verified accuracy.')))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
