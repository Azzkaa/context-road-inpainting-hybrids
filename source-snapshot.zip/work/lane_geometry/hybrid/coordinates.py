"""Explicit edge-coordinate transforms; normalized curves refer to full original image.
Never confuse detector crop-normalized coordinates with full-image coordinates.
"""
import numpy as np

def letterbox(width,height,canvas=512):
    assert width>0 and height>0
    scale=min(canvas/width,canvas/height);nw,nh=round(width*scale),round(height*scale)
    return {'width':width,'height':height,'nw':nw,'nh':nh,'left':(canvas-nw)//2,'top':(canvas-nh)//2,'canvas':canvas}
def crop_to_full(points,cut_fraction):
    p=np.asarray(points,dtype=float).copy();assert p.shape[-1]==2 and 0<=cut_fraction<1
    p[...,1]=cut_fraction+p[...,1]*(1-cut_fraction);return p
def full_to_canvas(points,meta):
    p=np.asarray(points,dtype=float).copy();assert p.shape[-1]==2
    return p*np.array([meta['nw'],meta['nh']])+np.array([meta['left'],meta['top']])
def canvas_to_full(points,meta):
    return (np.asarray(points,dtype=float)-np.array([meta['left'],meta['top']]))/np.array([meta['nw'],meta['nh']])
def canvas_to_grid(points,grid_size=(32,32),canvas=512):
    return np.asarray(points,dtype=float)*np.array([grid_size[1]/canvas,grid_size[0]/canvas])
