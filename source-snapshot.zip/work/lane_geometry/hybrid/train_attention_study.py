"""25-update exploratory image-context + spatial adapter pilot; immutable parent."""
from pathlib import Path
import sys,os,json,time,random
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';P=R/'outputs/lane_geometry/klein_hybrid';
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--arm',choices=['control','attention'],required=True);args=parser.parse_args();O=P/'attention_study'/args.arm;O.mkdir(parents=True,exist_ok=True);ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'));sys.path.insert(0,str(W/'klein_training_dependencies'));os.environ['HF_HUB_OFFLINE']='1'
import torch
from diffusers import Flux2Transformer2DModel,Flux2KleinPipeline,BitsAndBytesConfig
from peft import LoraConfig,set_peft_model_state_dict,get_peft_model_state_dict
from spatial_adapter import SpatialGeometryAdapter
from image_context import ImageContextAdapter
from klein_bridge import forward_text_free
protocol=json.loads((P/'attention_study_protocol.json').read_text());assert json.loads((P/'attention_scope_gate.json').read_text())['phase']=='passed';torch.set_num_threads(4);torch.manual_seed(protocol['seed']);start=time.time()
def status(**d):(O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
try:
 status(phase='loading',arm=args.arm,step=0,total=100)
 m=Flux2Transformer2DModel.from_pretrained(W/'klein_base/transformer',local_files_only=True,torch_dtype=torch.float16,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'});m.add_adapter(LoraConfig(r=4,lora_alpha=4,target_modules=['to_q','to_k','to_v','to_out.0']));parent=torch.load(R/'outputs/lane_geometry/klein_paired_training/latest.pt',map_location='cpu',weights_only=False);assert parent['step']==6783;set_peft_model_state_dict(m,parent['adapter']);del parent;m.requires_grad_(False)
 if args.arm=='attention':
  for name,p in m.named_parameters():
   if 'lora_' in name:p.requires_grad_(True);p.data=p.data.float()
 m.enable_gradient_checkpointing();m.train()
 for mod in m.modules():
  if hasattr(mod,'compute_dtype'):mod.compute_dtype=torch.float16
 spatial=SpatialGeometryAdapter(input_channels=131).cuda();context=ImageContextAdapter().cuda();core=list(spatial.parameters())+list(context.parameters());attention=[p for p in m.parameters() if p.requires_grad];params=core+attention;groups=[{'params':core,'lr':protocol['context_lr']}]
 if attention:groups.append({'params':attention,'lr':protocol['attention_lr']})
 opt=torch.optim.AdamW(groups,weight_decay=.01);scaler=torch.amp.GradScaler('cuda',init_scale=256);records=[];done=0
 continuing=not (O/'latest.pt').exists()
 checkpoint=R/'outputs/lane_geometry/klein_hybrid/image_pilot200/latest.pt' if continuing else O/'latest.pt'
 if checkpoint.exists():
  ck=torch.load(checkpoint,map_location='cpu',weights_only=False);assert (ck['step']==200 and __import__('hashlib').sha256(checkpoint.read_bytes()).hexdigest()==protocol['continuation_sha256']) if continuing else ck['protocol']==protocol;spatial.load_state_dict(ck['spatial']);context.load_state_dict(ck['context']);
  if not continuing:opt.load_state_dict(ck['optimizer']);set_peft_model_state_dict(m,ck['attention_adapter'])
  scaler.load_state_dict(ck['scaler']);done=ck['step'];records=[] if continuing else ck['records'];torch.set_rng_state(ck['rng']);torch.cuda.set_rng_state_all(ck['cuda_rng'])
  opt.param_groups[0]['lr']=protocol['context_lr']
  if attention:opt.param_groups[1]['lr']=protocol['attention_lr']
 def save(step):
  ck={'attention_adapter':{k:v.detach().cpu() for k,v in get_peft_model_state_dict(m).items()},'arm':args.arm,'spatial':{k:v.detach().cpu() for k,v in spatial.state_dict().items()},'context':{k:v.detach().cpu() for k,v in context.state_dict().items()},'optimizer':opt.state_dict(),'scaler':scaler.state_dict(),'step':step,'records':records,'protocol':protocol,'rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all()};tmp=O/'latest.tmp';torch.save(ck,tmp);tmp.replace(O/'latest.pt')
 for i in range(done,300):
  sid=protocol['train_ids'][i%len(protocol['train_ids'])];d=torch.load(W/'klein_full_cache'/(sid+'_512.pt'),map_location='cuda',weights_only=False);g=torch.load(W/'hybrid_pilot_geometry'/(sid+'.pt'),map_location='cuda',weights_only=False);assert d['split']==g['split']=='train';source=Flux2KleinPipeline._pack_latents(d['snowy']).half();clean=d['clean'];noise=torch.randn_like(clean);sigma=torch.rand(1,device='cuda').clamp(.001,.999);target=Flux2KleinPipeline._pack_latents(noise-clean).float();x=Flux2KleinPipeline._pack_latents((1-sigma[:,None,None,None])*clean+sigma[:,None,None,None]*noise).half().requires_grad_(True);ids=torch.cat([d['target_ids'],d['source_ids']],dim=1);geometry=g['geometry'].float();weight=g['loss_weights'].flatten(2).transpose(1,2)
  for attempt in range(6):
   opt.zero_grad(set_to_none=True);x.grad=None
   with torch.autocast('cuda',dtype=torch.float16):pred=forward_text_free(m,spatial,x,source,geometry,sigma,ids,context_adapter=context)
   loss=((pred.float()-target).square()*weight).sum()/(weight.sum()*pred.shape[-1]).clamp_min(1);assert torch.isfinite(loss);scaler.scale(loss).backward();scaler.unscale_(opt)
   if all(p.grad is None or torch.isfinite(p.grad).all() for p in params):torch.nn.utils.clip_grad_norm_(params,1.);scaler.step(opt);scaler.update();break
   before=[p.detach().clone() for p in params];old=scaler.get_scale();scaler.step(opt);scaler.update();assert all(torch.equal(a,b) for a,b in zip(before,params));assert scaler.get_scale()<old
  else:raise RuntimeError('Persistent nonfinite gradients; no hidden skip')
  assert all(p.grad is None for p in m.parameters() if not p.requires_grad);records.append({'step':i+1-200,'global_updates':i+1,'id':sid,'loss':float(loss.detach()),'seconds':time.time()-start});status(phase='training',arm=args.arm,step=i+1-200,total=100,global_updates=i+1,records=records);print(records[-1],flush=True)
  if i+1 in [202,225,250,275,300]:
   save(i+1)
   if i+1==202:
    ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert all(torch.isfinite(v).all() for v in list(ck['spatial'].values())+list(ck['context'].values()));assert torch.cuda.max_memory_allocated()/2**30<6.8;(O/'smoke_check.json').write_text(json.dumps({'passed':True,'step':202,'finite_weights':True,'parent_frozen':True,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30}))
 status(phase='complete',arm=args.arm,step=100,total=100,global_updates=300,records=records,seconds=time.time()-start,warning='Short development pilot, not final convergence or lane accuracy')
except Exception as e:status(phase='failed',error=repr(e));raise
