"""Frozen SAM2 automatic spatial-query experiment; no language/user-drawn guide/GT input."""
from pathlib import Path
import sys,json,hashlib,time,subprocess
import numpy as np,torch,cv2
from PIL import Image
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';sys.path.insert(0,str(W/'SAM2'));sys.path.insert(0,str(W/'sam2_dependencies'))
from sam2.build_sam import build_sam2
from sam2.sam2_image_predictor import SAM2ImagePredictor
from road_only import compose_road
O=R/'outputs/lane_geometry/klein_hybrid/sam2_ego_review';O.mkdir(exist_ok=True);old=R/'outputs/lane_geometry/klein_hybrid/mask_review';p=W/'models/sam2.1_hiera_tiny.pt.partial';ck=W/'models/sam2.1_hiera_tiny.pt'
if p.exists():
 data=torch.load(p,map_location='cpu',weights_only=True);assert all(torch.isfinite(x).all() for x in data['model'].values() if torch.is_tensor(x) and x.is_floating_point());del data;p.replace(ck)
torch.set_num_threads(4);start=time.time();m=build_sam2('configs/sam2.1/sam2.1_hiera_t.yaml',str(ck),device='cuda',apply_postprocessing=False);m.requires_grad_(False);predictor=SAM2ImagePredictor(m)
rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};ids=json.loads((W/'evaluation_panels.json').read_text())['validation_annotation'][:6];records=[]
for sid in ids:
 assert rows[sid]['split']=='validation';a=np.array(Image.open(rows[sid]['snowy']).convert('RGB'));h,w=a.shape[:2];road=np.array(Image.open(old/sid/'road_candidate.png'))>0;protected=np.array(Image.open(old/sid/'protected.png'))>0;ego=np.zeros((h,w),bool);candidates=[]
 # Automatic bottom seeds test candidate ego-vehicle objects. They are not semantic GT.
 negative=np.array([[.25*w,.5*h],[.5*w,.5*h],[.75*w,.5*h],[.5*w,.65*h]],np.float32)
 with torch.inference_mode():
  predictor.set_image(a)
  for sx in [.25,.5,.75]:
   for sy in [.94,.985]:
    pos=np.array([[sx*w,sy*h]],np.float32);points=np.concatenate([pos,negative]);labels=np.array([1,0,0,0,0],np.int32)
    masks,scores,_=predictor.predict(point_coords=points,point_labels=labels,multimask_output=True)
    for mask,score in zip(masks,scores):
     ys,xs=np.where(mask);area=float(mask.mean());touch=bool(mask[-max(2,round(h*.015)):].any());top=float(ys.min()/h) if len(ys) else 0
     accepted=bool(float(score)>=.75 and .005<=area<=.30 and touch and top>=.60)
     candidates.append({'seed':[sx,sy],'predicted_iou_score':float(score),'area':area,'top':top,'touch_bottom':touch,'accepted':accepted})
     if accepted:ego|=mask.astype(bool)
 revised=protected|ego;fixture,allowed=compose_road(a,np.full_like(a,[210,50,180]),road,revised);assert np.array_equal(fixture[~allowed],a[~allowed]);dst=O/sid;dst.mkdir(exist_ok=True)
 for name,mask in [('ego_candidate',ego),('permitted',allowed)]:Image.fromarray(mask.astype(np.uint8)*255).save(dst/(name+'.png'))
 overlay=a.copy();overlay[allowed]=(.6*a[allowed]+.4*np.array([30,240,50])).astype(np.uint8);overlay[ego]=(.45*a[ego]+.55*np.array([255,80,20])).astype(np.uint8);Image.fromarray(overlay).save(dst/'overlay.png');Image.fromarray(fixture).save(dst/'edit_footprint_fixture.png');Image.fromarray(a).save(dst/'snowy.png')
 records.append({'id':sid,'ego_candidate_fraction':float(ego.mean()),'old_edit_fraction':float((road&~protected).mean()),'revised_edit_fraction':float(allowed.mean()),'outside_mask_exact':True,'candidates':candidates});print(sid,float(ego.mean()),flush=True)
summary={'phase':'complete','validation_pairs':6,'records':records,'model':'official SAM2.1 Hiera tiny frozen','checkpoint_sha256':hashlib.sha256(ck.read_bytes()).hexdigest(),'source_commit':subprocess.check_output(['git','-C',str(W/'SAM2'),'rev-parse','HEAD'],text=True).strip(),'input':'original snowy RGB + automatic bottom-point and negative-point queries; no language, clean target or historical mask guides','policy':'accept predicted-IoU>=.75,area.5%-30%,touchbottom,top>=60%; geometry filter is heuristic, not ego-vehicle classification','peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,'seconds':time.time()-start,'limitations':'SAM2 is class-agnostic. Query/filter can miss hood or protect actual road. Scores are uncalibrated on this domain. Visual review required; no claim semantic accuracy or approval.'};(O/'summary.json').write_text(json.dumps(summary,indent=2))
page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white}img{width:32%}</style><h1>SAM2 ego-protection candidate review</h1><p>Left: source. Middle: green permitted edit / orange candidate ego protection. Right: synthetic magenta edit footprint, NOT restored output. SAM is class-agnostic; automatic point queries are internal spatial inputs, no text instruction.</p>'
for sid in ids:page+='<h2>'+sid+'</h2>'+''.join(f'<img src="{sid}/{n}.png">' for n in ['snowy','overlay','edit_footprint_fixture'])
(O/'index.html').write_text(page)
