from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'expanded_layout_cache';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);py=R/'work/inpainting_compare/venv/bin/python';H=R/'work/lane_geometry/hybrid'
try:
 for script,path,title,total in [('cache_expanded_layout_features.py','expanded_layout_features/status.json','Expanding snowy-input layout features to1,000 TRAIN cases',1008),('cache_expanded_layout_targets.py','expanded_layout_targets/cache_status.json','Expanding clean-side marking supervision to1,000 TRAIN cases',1000)]:
  (O/'status.json').write_text(json.dumps(dict(phase='preparing',stage=title,updated_at=time.time())));(P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Frozen source encoders/teacher; cache-only, no new training. Clean TRAIN teacher targets are pseudo-labels, never deployment inputs.',total=total,result_path='layout_capacity_diagnostic/',show_loss=False,next_text='Audit crosswalk diversity and cache provenance before balanced-layout training.')))
  with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
 (O/'status.json').write_text(json.dumps(dict(phase='complete',train=1000,validation_inputs=8,optimization_updates=0,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
