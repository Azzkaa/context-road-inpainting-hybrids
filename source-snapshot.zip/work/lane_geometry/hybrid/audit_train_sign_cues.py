"""TRAIN-only candidate sign-arrow audit. No generated paint, labels or optimization."""
from pathlib import Path
import json,time,torch,numpy as np,cv2,hashlib
from PIL import Image
from transformers import AutoImageProcessor,Mask2FormerForUniversalSegmentation
from sign_icon_geometry import arrow_candidates
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'train_sign_cue_audit';O.mkdir(exist_ok=True);M=R/'work/lane_geometry/models/mask2former_mapillary';ids=json.loads((P/'expanded_layout_protocol.json').read_text())['train_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};torch.set_num_threads(4)
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 status(phase='loading',completed=0,total=1000);proc=AutoImageProcessor.from_pretrained(M,local_files_only=True);model=Mask2FormerForUniversalSegmentation.from_pretrained(M,local_files_only=True,torch_dtype=torch.float16).cuda().eval();model.requires_grad_(False);records=[]
 for n,sid in enumerate(ids):
  r=rows[sid];assert r['split']=='train';dst=O/sid;dst.mkdir(exist_ok=True);record_file=dst/'record.json'
  if record_file.exists():
   record=json.loads(record_file.read_text());assert record['source_sha256']==r['snowy_sha256'];records.append(record);continue
  assert hashlib.sha256(Path(r['snowy']).read_bytes()).hexdigest()==r['snowy_sha256'];im=Image.open(r['snowy']).convert('RGB');W,H=im.size;scale=min(1.,1024/max(W,H));sw,sh=round(W*scale),round(H*scale);inputs=proc(images=im,return_tensors='pt',size=dict(shortest_edge=768,longest_edge=1024)).to('cuda');inputs['pixel_values']=inputs['pixel_values'].half()
  with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):output=model(**inputs);labels=proc.post_process_semantic_segmentation(output,target_sizes=[(sh,sw)])[0].cpu().numpy()
  _,_,stats,_=cv2.connectedComponentsWithStats((labels==50).astype(np.uint8),8);source=np.array(im);candidates=[]
  for x,y,w,h,area in stats[1:]:
   if area<8 or w<4 or h<4:continue
   l,t,rr,b=max(0,int(x/scale)),max(0,int(y/scale)),min(W,int((x+w)/scale)+1),min(H,int((y+h)/scale)+1);crop=source[t:b,l:rr]
   if min(crop.shape[:2])<12:continue
   for u in arrow_candidates(crop):
    k=len(candidates);pn='panel_%02d.png'%k;mn='icon_%02d.png'%k;Image.fromarray(u.pop('panel')).save(dst/pn);Image.fromarray(u.pop('icon')).save(dst/mn);candidates.append(dict(**u,sign_native_bbox=[l,t,rr,b],panel_file=pn,icon_file=mn))
  record=dict(id=sid,split='train',source_sha256=r['snowy_sha256'],candidates=candidates,verified=False);record_file.write_text(json.dumps(record,indent=2));records.append(record);status(phase='auditing',completed=n+1,total=1000,candidate_frames=sum(bool(x['candidates']) for x in records))
 summary=dict(phase='complete',train_images=1000,candidate_frames=sum(bool(x['candidates']) for x in records),records=records,warning='Unverified geometric sign-icon proposals. No road-arrow positions or verified lane labels. No generator changes, training or clean inputs.');(O/'summary.json').write_text(json.dumps(summary,indent=2));page='<meta charset="utf-8"><style>body{font:18px system-ui;background:#122033;color:white;margin:30px}a{color:#8df}img{max-width:250px;max-height:200px;margin:10px}</style><h1>TRAIN-only sign cue proposals</h1><p>Unverified candidates, not training ground truth or restored paint. Source snowy images only.</p><a href="../progress/">Live progress</a>'
 for r in records:
  if not r['candidates']:continue
  page+='<h2>'+r['id']+'</h2>'
  for c in r['candidates']:page+='<p>Candidate '+c['direction']+'</p><img src="'+r['id']+'/'+c['panel_file']+'"><img src="'+r['id']+'/'+c['icon_file']+'">'
 (O/'index.html').write_text(page);status(phase='complete',completed=1000,total=1000,candidate_frames=summary['candidate_frames'])
except Exception as e:status(phase='failed',error=repr(e));raise
