"""Frozen lane-extraction diagnostics; no generated curves become ground truth."""
from pathlib import Path
import sys,json,time,hashlib
import numpy as np,torch,cv2
from PIL import Image
from scipy.optimize import linear_sum_assignment
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';sys.path.insert(0,str(W));from benchmark import model_load,predict,overlay
P=R/'outputs/lane_geometry/klein_hybrid';S=P/'image_pilot200_review';O=P/'lane_check';O.mkdir(exist_ok=True);protocol=json.loads((P/'image_pilot200_protocol.json').read_text());rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};arms={'snowy':'snowy.png','clean_reference':'clean_reference.png','instructed_parent':'instructed_parent.png','text_free_raw':'raw_null_text.png','text_free_composite':'road_only_output.png'};start=time.time();records=[]
def status(**d):(O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
def raster(lane):
 m=np.zeros((600,800),np.uint8);pts=np.asarray(lane,float);pts=pts[np.isfinite(pts).all(1)&(pts[:,0]>=0)&(pts[:,0]<=1)&(pts[:,1]>=0)&(pts[:,1]<=1)]
 if len(pts)>1:cv2.polylines(m,[np.rint(pts*np.array([800,600])).astype(np.int32)],False,1,8)
 return m.astype(bool)
def agreement(reference,prediction):
 gt=[raster(l) for l in reference['lanes_normalized']];pr=[raster(l) for l in prediction['lanes_normalized']]
 mat=np.array([[float((a&b).sum()/(a|b).sum()) if (a|b).any() else 0 for b in pr] for a in gt]).reshape(len(gt),len(pr));matches=[]
 if len(gt) and len(pr):
  rr,cc=linear_sum_assignment(1-mat);matches=[{'clean_prediction_index':int(i),'restored_prediction_index':int(j),'iou':float(mat[i,j])} for i,j in zip(rr,cc) if mat[i,j]>=.5]
 n=len(matches);return {'matched_clean_detector_curves':n,'clean_detector_curve_count':len(gt),'candidate_curve_count':len(pr),'clean_detector_agreement_f1':2*n/(len(gt)+len(pr)) if len(gt)+len(pr)>0 else None,'matches':matches}
try:
 status(phase='loading',completed=0,total=20);torch.set_num_threads(4);model,cfg,ck=model_load()
 for sid in protocol['validation_ids']:
  assert rows[sid]['split']=='validation';size=Image.open(S/sid/'raw_null_text.png').size;dst=O/sid;dst.mkdir(exist_ok=True)
  for arm,name in arms.items():
   path=S/sid/name;image=Image.open(path).convert('RGB').resize(size,Image.Resampling.LANCZOS);bgr=np.array(image)[:,:,::-1].copy();p=predict(model,bgr);rec={'id':sid,'arm':arm,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'comparison_size':list(size),**p};records.append(rec);Image.fromarray(overlay(bgr,p)[:,:,::-1]).save(dst/(arm+'_overlay.png'));image.save(dst/(arm+'_image.png'));status(phase='checking',completed=len(records),total=20,current_id=sid,current_arm=arm);print(sid,arm,len(p['scores']),flush=True)
 diagnostic=[]
 for sid in protocol['validation_ids']:
  rr={r['arm']:r for r in records if r['id']==sid};ref=rr['clean_reference']
  for arm in ['snowy','instructed_parent','text_free_raw','text_free_composite']:diagnostic.append({'id':sid,'arm':arm,**agreement(ref,rr[arm])})
 summary={'phase':'complete','validation_pairs':4,'images':20,'detector':'official frozen CLRerNet CULane DLA34 EMA','confidence_threshold':float(model.bbox_head.test_cfg.conf_threshold),'checkpoint_sha256':hashlib.sha256(ck.read_bytes()).hexdigest(),'prediction_counts':{arm:[len(r['scores']) for r in records if r['arm']==arm] for arm in arms},'curve_match':'diagnostic Hungarian assignment, IoU>=.5, raster800x600,width8pixels','mean_clean_detector_agreement_f1':{arm:float(np.mean([r['clean_detector_agreement_f1'] for r in diagnostic if r['arm']==arm and r['clean_detector_agreement_f1']is not None])) if any(r['arm']==arm and r['clean_detector_agreement_f1']is not None for r in diagnostic) else None for arm in ['snowy','instructed_parent','text_free_raw','text_free_composite']},'seconds':time.time()-start,'warning':'NOT verified lane accuracy. Clean-image curves are detector predictions, not human GT. The hybrid already uses CLRerNet image features, so this checker is not an independent judge. Missing detections can reflect detector failure; high confidence/agreement can still correspond to wrong paint.'};(O/'predictions.json').write_text(json.dumps(records,indent=2));(O/'diagnostic_curve_agreement.json').write_text(json.dumps(diagnostic,indent=2));(O/'summary.json').write_text(json.dumps(summary,indent=2))
 page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white;margin:25px}a{color:#8df}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}img{width:100%}figure{margin:0}td,th{padding:12px}details{margin:20px 0}</style><h1>Lane-line testing: four validation images</h1><p><a href="../progress/">Live progress</a></p><p><b>Colored curves are CLRerNet predictions, not restored paint or verified ground truth.</b> Compare the unmarked images as well. The detector is also a feature source for this hybrid, so this is not independent accuracy testing.</p><table><tr><th>Image</th><th>Clean-reference detections</th><th>Instructed-parent detections</th><th>Text-free raw detections</th><th>Text-free composite detections</th></tr>'
 for i,sid in enumerate(protocol['validation_ids']):page+=f'<tr><td>{sid[:20]}</td>'+''.join(f'<td>{summary["prediction_counts"][a][i]}</td>' for a in ['clean_reference','instructed_parent','text_free_raw','text_free_composite'])+'</tr>'
 page+='</table><p>No human-labelled validation lane F1 is claimed. <a href="diagnostic_curve_agreement.json">Clean-detector agreement diagnostics</a> are not GT accuracy.</p>'
 for sid in protocol['validation_ids']:
  page+='<h2>'+sid+'</h2><div class="grid">'
  for arm,label in [('snowy','Snow input'),('clean_reference','Clean reference: prediction control'),('instructed_parent','Original instructed parent'),('text_free_raw','Text-free200 raw'),('text_free_composite','Text-free200 composite')]:page+=f'<figure><img src="{sid}/{arm}_overlay.png"><figcaption>{label}</figcaption></figure>'
  page+='</div><details><summary>View original images WITHOUT detector overlays</summary><div class="grid">'+''.join(f'<figure><img src="{sid}/{arm}_image.png"><figcaption>{arm}</figcaption></figure>' for arm in arms)+'</div></details>'
 (O/'index.html').write_text(page);status(**summary)
except Exception as e:status(phase='failed',error=repr(e),completed=len(records),total=20);raise
