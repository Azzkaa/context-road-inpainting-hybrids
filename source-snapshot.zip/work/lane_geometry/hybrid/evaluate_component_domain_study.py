"""Fixed full228 external VAL object/region metrics, serial initial versus pilot."""
from directional_instances import *
import argparse
a=argparse.ArgumentParser();a.add_argument('--arm',choices=['clean_control','mixed_predicted'],required=True);args=a.parse_args()
from marking_shape import ShapeClassifier,normalize_main_component as normalize
shape=ShapeClassifier().cuda().eval();shape.load_state_dict(torch.load(P/'marking_shape_component_domain_study'/args.arm/'latest.pt',map_location='cpu',weights_only=False)['model'])
preview_ids=json.loads((P/'directional_instance_pilot/protocol.json').read_text())['preview_ids']
G=P/'marking_shape_component_domain_review'/args.arm;G.mkdir(exist_ok=True,parents=True)
from scipy.optimize import linear_sum_assignment
import time,fcntl
O=P/'marking_shape_component_domain_evaluation'/args.arm;O.mkdir(exist_ok=True,parents=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);torch.set_num_threads(4);data=Data();rows=json.loads((P/'ceymo_pretraining/protocol.json').read_text())['external_validation']
def matched(iou):
 if not iou.size:return 0
 valid=iou>=.5;r,c=linear_sum_assignment(-(valid.astype(float)*(min(iou.shape)+1)+iou*valid));return int(valid[r,c].sum())
assert matched(np.array([[.6,.8],[.51,.1]]))==2
assert matched(np.array([[.49]]))==0
assert matched(np.empty((0,2)))==0
try:
 for arm in ['pass1']:
  m=model().cuda().eval()
  if arm=='pass1':m.load_state_dict(torch.load(P/'directional_instance_class_study/control/latest.pt',map_location='cpu',weights_only=False)['trainable'],strict=False)
  dst=O/arm;dst.mkdir(exist_ok=True);conf=np.zeros((12,12),np.int64);obj=np.zeros((11,3),np.int64)
  for n,row in enumerate(rows):
   cache=dst/(row['id']+'.json')
   if cache.exists():d=json.loads(cache.read_text());conf+=np.array(d['confusion']);obj+=np.array(d['object_counts'])
   else:
    batch,masks,labels,im=data.get(row);H,W=im.size[1],im.size[0]
    with torch.inference_mode():out=m(**batch);result=data.proc.post_process_instance_segmentation(out,threshold=.5,mask_threshold=.5,overlap_mask_area_threshold=.8,target_sizes=[(H,W)])[0]
    seg=result['segmentation'];seg=seg.cpu().numpy() if seg is not None else np.full((H,W),-1);info=result['segments_info'];original=[dict(item) for item in info]
    # Refine only detected arrow classes. Shape CNN sees predicted masks only.
    for item in info:
     if item['label_id'] not in [4,6,7,9,10] or not (seg==item['id']).any():continue
     mask=Image.fromarray(((seg==item['id'])*255).astype(np.uint8));xx=torch.from_numpy(normalize(mask).copy())[None,None].cuda().float()/255
     with torch.inference_mode():prob=shape(xx).softmax(-1)[0];confidence,label=prob.max(0)
     if float(confidence)>=.5 and int(label) in [4,6,7,9,10]:item['label_id']=int(label)
    if row['id'] in preview_ids:
     for kind,items in [('original',original),('refined',info)]:
      pic=np.array(im).copy();colors=np.array(COLORS,np.uint8)
      for item in items:
       z=seg==item['id'];pic[z]=(.3*pic[z]+.7*colors[item['label_id']+1]).astype(np.uint8)
      Image.fromarray(pic).save(G/(row['id']+'_'+kind+'.png'))
    gt=masks.cpu().numpy().astype(bool);gl=labels.cpu().numpy();truth=np.zeros((H,W),np.uint8);pred=truth.copy();counts=np.zeros((11,3),np.int64)
    for mask,c in zip(gt,gl):truth[mask]=c+1
    for item in info:pred[seg==item['id']]=item['label_id']+1
    for c in range(11):
     gm=gt[gl==c];pm=[seg==item['id'] for item in info if item['label_id']==c];iou=np.zeros((len(gm),len(pm)))
     for i,g in enumerate(gm):
      for j,a in enumerate(pm):iou[i,j]=(g&a).sum()/max(1,(g|a).sum())
     tp=matched(iou);counts[c]=[tp,len(pm)-tp,len(gm)-tp]
    cm=np.bincount((truth.astype(np.int64)*12+pred).ravel(),minlength=144).reshape(12,12);d=dict(id=row['id'],confusion=cm.tolist(),object_counts=counts.tolist());cache.write_text(json.dumps(d));conf+=cm;obj+=counts
   (O/'status.json').write_text(json.dumps(dict(phase='evaluating_'+arm,completed=n+1,total=228,updated_at=time.time())))
  scores={}
  for c,name in enumerate(CLASSES[1:]):
   tp,fp,fn=map(int,obj[c]);ix=c+1;inter=int(conf[ix,ix]);union=int(conf[ix].sum()+conf[:,ix].sum()-inter);scores[name]=dict(tp=tp,fp=fp,fn=fn,object_f1=2*tp/max(1,2*tp+fp+fn),pixel_iou=inter/max(1,union),gt_pixels=int(conf[ix].sum()))
  tp,fp,fn=obj.sum(0);report=dict(phase='complete',images=228,scores=scores,micro_object_f1=float(2*tp/max(1,2*tp+fp+fn)),foreground_pixel_miou=float(np.mean([v['pixel_iou'] for v in scores.values() if v['gt_pixels']>0])),thresholds=dict(class_confidence=.5,mask=.5,overlap_area=.8,match_iou=.5),warning='External clear-road author object regions. Class-aware maximum-cardinality one-to-one matching, then IoU tie-break. Not paper-equivalent by assumption; not original snowy recovery accuracy. CL absentGT.');(O/(arm+'.json')).write_text(json.dumps(report,indent=2));del m;torch.cuda.empty_cache()
 page='<meta charset="utf-8"><style>body{background:#142033;color:white;font:18px system-ui;margin:30px}a{color:#8df}td,th{padding:12px}</style><h1>Predicted-mask shape refinement: full228externalVAL</h1><p>Class-aware object matching IoU≥0.5; confidence0.5,mask0.5,overlap0.8. Clear-road region accuracy, NOT snowy restoration accuracy.</p><table><tr><th>Model</th><th>Object microF1</th><th>Foreground region mIoU</th></tr>'
 for arm in ['pass1']:
  d=json.loads((O/(arm+'.json')).read_text());page+='<tr><td>'+arm+'</td><td>'+str(d['micro_object_f1'])+'</td><td>'+str(d['foreground_pixel_miou'])+'</td></tr>'
 page+='</table><a href="../../marking_shape_component_domain_review/">Visual previews</a> · <a href="../../progress/">Progress</a>';(O/'index.html').write_text(page);(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=228,total=228,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
