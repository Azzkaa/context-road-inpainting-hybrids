from pathlib import Path
import json,time,subprocess
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/predicted_shape_component_training_audit';deadline=time.time()+7200
while time.time()<deadline:
 s=O/'status.json'
 if s.exists():
  d=json.loads(s.read_text())
  if d['phase']=='failed':raise RuntimeError('Cache failed: '+str(d))
  if d['phase']=='complete':
   with (O/'audit.log').open('a') as log:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(R/'work/lane_geometry/hybrid/audit_component_training_shapes.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
   break
 time.sleep(5)
else:raise TimeoutError('Cache did not finish within2hours; no training started')
