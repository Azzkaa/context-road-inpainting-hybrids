"""Serial, resumable input-only feature preparation. No optimization."""
from pathlib import Path
import json,time,subprocess,fcntl,hashlib
from expanded_selection import selection,R
P=R/'outputs/lane_geometry/klein_hybrid';O=P/'expanded_cache';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);rows,train,val=selection();H=R/'work/lane_geometry/hybrid'
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 assert len(train)==1000 and not set(train)&set(val)
 for sid in train:assert rows[sid]['split']=='train' and (R/'work/lane_geometry/klein_full_cache'/(sid+'_512.pt')).exists()
 protocol=dict(train_ids=train,validation_ids=val,seed=20261122,optimization_updates=0,conditioning='snowy inputs only; frozen experts and predicted ROI; clean masks used solely for TRAIN loss weights',manifest_sha256=hashlib.sha256((R/'work/road_restoration/manifest.json').read_bytes()).hexdigest())
 f=O/'protocol.json'
 if f.exists():assert json.loads(f.read_text())==protocol
 else:f.write_text(json.dumps(protocol,indent=2))
 for stage,py,script,path in [('expert features',R/'work/lane_geometry/venv/bin/python','cache_expanded_features.py','expanded_feature_cache/status.json'),('predicted spatial conditioning',R/'work/inpainting_compare/venv/bin/python','cache_expanded_geometry.py','expanded_geometry_cache/status.json')]:
  status(phase='preparing',stage=stage,completed=0,total=1004)
  (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title='1,000 TRAIN inputs: '+stage,description='Resumable cache expansion; frozen models, no training, original split preserved.',total=1004,result_path='feature_study_review/',show_loss=False,next_text='Audit caches before a bounded larger-data training run.')))
  with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
 status(phase='complete',completed=1004,total=1004,optimization_updates=0,next_action='Audit completed caches then prepare larger-data finite training protocol; no automatic unbounded optimization.')
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path='expanded_cache/status.json',title='1,000 TRAIN inputs prepared',total=1004,result_path='feature_study_review/',show_loss=False,next_text='Cache provenance and shape audit before training.')))
except Exception as e:status(phase='failed',error=repr(e));raise
