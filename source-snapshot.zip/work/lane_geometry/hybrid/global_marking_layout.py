"""Global spatial attention residual for explicit layout; no language."""
import torch
from torch import nn
from torch.nn import functional as F
from marking_layout import MarkingLayoutHead
class GlobalMarkingLayoutHead(MarkingLayoutHead):
 def __init__(self):
  super().__init__();self.position=nn.Parameter(torch.zeros(1,256,96));nn.init.normal_(self.position,std=.01);block=nn.TransformerEncoderLayer(96,4,192,dropout=0.,batch_first=True,norm_first=True);self.global_blocks=nn.TransformerEncoder(block,2);self.global_output=nn.Linear(96,96);nn.init.zeros_(self.global_output.weight);nn.init.zeros_(self.global_output.bias)
 def forward(self,scene,geometry):
  x=torch.cat([scene,F.interpolate(geometry,size=(64,64),mode='bilinear',align_corners=False)],1);z=self.net[:3](x);tokens=F.adaptive_avg_pool2d(z,(16,16)).flatten(2).transpose(1,2);global_z=self.global_output(self.global_blocks(tokens+self.position)).transpose(1,2).reshape(z.shape[0],96,16,16);z=z+F.interpolate(global_z,size=(64,64),mode='bilinear',align_corners=False);return F.interpolate(self.net[3:](z),size=(128,128),mode='bilinear',align_corners=False)
