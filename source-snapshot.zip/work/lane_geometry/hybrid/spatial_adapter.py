"""Experimental source-token geometry residual; no tokenizer or language conditioning.
Not yet connected to the full Klein trainer. Inputs are aligned to padded image canvas.
Channels: road,protected,curb_context,CLR_curve,CLR_conf,Cond_curve,Cond_conf.
Expert curves/confidences are predictions, not verified paint labels or calibrated agreement.
"""
import torch
from torch import nn
from torch.nn import functional as F

class SpatialGeometryAdapter(nn.Module):
    def __init__(self,hidden=64,packed_channels=128,input_channels=7):
        super().__init__()
        self.input_channels=input_channels
        self.encoder=nn.Sequential(nn.Conv2d(input_channels,hidden,3,padding=1),nn.SiLU(),nn.Conv2d(hidden,hidden,3,padding=1),nn.SiLU())
        self.output=nn.Conv2d(hidden,packed_channels,1)
        nn.init.zeros_(self.output.weight);nn.init.zeros_(self.output.bias)
    def forward(self,geometry,grid_size=(32,32)):
        assert geometry.ndim==4 and geometry.shape[1]==self.input_channels and torch.isfinite(geometry).all()
        assert geometry[:,:2].min()>=0 and geometry[:,:2].max()<=1
        # Additional learned image features may be signed/unbounded; only gate channels are probabilities.
        features=F.interpolate(geometry,size=grid_size,mode='bilinear',align_corners=False)
        # Conservative gate for prototype; semantic road/foreground inference remains separate.
        gate=F.interpolate(geometry[:,0:1]*(1-geometry[:,1:2]),size=grid_size,mode='area')
        residual=self.output(self.encoder(features))*gate
        return residual.flatten(2).transpose(1,2)
