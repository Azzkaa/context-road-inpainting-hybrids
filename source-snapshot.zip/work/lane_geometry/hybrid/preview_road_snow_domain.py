"""TRAIN-only procedural road-occlusion preview; no optimization and no new GT."""
from directional_instances import *
from transformers import SegformerForSemanticSegmentation
import hashlib,time
O=P/'road_snow_domain_preview';O.mkdir(exist_ok=True);torch.set_num_threads(4);path=R/'work/snow_replacements820/cityscapes_model';m=SegformerForSemanticSegmentation.from_pretrained(path,local_files_only=True).cuda().eval();cfg=json.loads((path/'preprocessor_config.json').read_text());mean=torch.tensor(cfg['image_mean'],device='cuda')[None,:,None,None];std=torch.tensor(cfg['image_std'],device='cuda')[None,:,None,None];allrows=json.loads((P/'ceymo_pretraining/protocol.json').read_text())['external_train'];chosen=[]
for cls in ['LA','RA','SLA','SRA','SA','PC']:
 for row in allrows:
  if row['id'] not in [r['id'] for r in chosen] and any(s['label']==cls for s in json.loads(Path(row['polygon_annotation']).read_text())['shapes']):chosen.append(row);break
records=[]
try:
 for n,row in enumerate(chosen):
  sid=row['id'];im=Image.open(row['image']).convert('RGB');im.thumbnail((1024,1024));a=np.array(im);H,W=a.shape[:2];x=torch.from_numpy(a.copy()).permute(2,0,1)[None].cuda().float()/255
  with torch.inference_mode():logits=m((x-mean)/std).logits;prob=torch.nn.functional.interpolate(logits,(H,W),mode='bilinear',align_corners=False).softmax(1);permit=((prob.argmax(1)==0)&(prob[:,0]>=.6))[0].cpu().numpy()
  seed=int(hashlib.sha256(sid.encode()).hexdigest()[:8],16);rng=np.random.default_rng(seed);field=np.zeros((H,W),np.float32)
  for scale in [8,32,128]:field+=np.array(Image.fromarray((rng.random((max(2,H//scale),max(2,W//scale)))*255).astype(np.uint8)).resize((W,H),Image.Resampling.BILINEAR))/255/3
  texture=np.stack([225+25*field,230+20*field,235+15*field],-1);Image.fromarray(a).save(O/(sid+'_clean.png'));Image.fromarray((permit*255).astype(np.uint8)).save(O/(sid+'_predicted_roi.png'))
  for severity,name in [(.55,'partial'),(.95,'dense')]:
   alpha=(severity*(.7+.3*field)*permit)[...,None];out=np.clip(a*(1-alpha)+texture*alpha,0,255).astype(np.uint8);assert np.array_equal(out[~permit],a[~permit]);Image.fromarray(out).save(O/(sid+'_'+name+'.png'))
  records.append(dict(id=sid,split='external_train',source_image_sha256=hashlib.sha256(Path(row['image']).read_bytes()).hexdigest(),annotation_sha256=hashlib.sha256(Path(row['polygon_annotation']).read_bytes()).hexdigest(),predicted_roi_fraction=float(permit.mean()),outside_predicted_roi_exact=True,seed=seed));(O/'status.json').write_text(json.dumps(dict(phase='previewing',completed=n+1,total=len(chosen),updated_at=time.time())))
 page='<meta charset="utf-8"><style>body{background:#142033;color:white;font:18px system-ui;margin:30px}img{width:32%}a{color:#8df}</style><h1>TRAIN road-only synthetic occlusion preview — NOT trained results</h1><p>Clear / partial / dense. Frozen Cityscapes road class0 confidence≥0.6 is an UNVERIFIED edit ROI. Procedural multiscale whitish occlusion is a domain stress-test, not validated realistic snow. Original author marking annotations remain underlying supervision; no invented paint. No annotation mask determines snow placement. All pixels outside predicted ROI preserved exactly in working preview. No optimization.</p><a href="../progress/">Progress</a>'
 for r in records:page+='<h2>'+r['id']+'</h2>'+''.join('<img src="'+r['id']+'_'+name+'.png">' for name in ['clean','partial','dense'])
 (O/'index.html').write_text(page);(O/'summary.json').write_text(json.dumps(dict(records=records,warning='TRAIN-only procedural occlusion preview. Predicted road masks unverified; no claims of natural snow realism, verified road coverage or improved restoration. Need visual ROI/appearance/annotation-visibility review before training.'),indent=2));(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=len(chosen),total=len(chosen),updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
