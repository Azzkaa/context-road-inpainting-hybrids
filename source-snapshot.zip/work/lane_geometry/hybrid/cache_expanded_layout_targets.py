"""Clean TRAIN-only marking pseudo-labels. Never deployment conditioning or verified GT."""
from pathlib import Path
import torch,json,time
from PIL import Image
from transformers import AutoImageProcessor,Mask2FormerForUniversalSegmentation
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'expanded_layout_targets';O.mkdir(exist_ok=True);C=R/'work/lane_geometry/marking_teacher_targets';C.mkdir(exist_ok=True);M=R/'work/lane_geometry/models/mask2former_mapillary';p=json.loads((P/'lane_generation_protocol.json').read_text());ids=[p['train_ids'][i] for i in range(1000)];torch.set_num_threads(4);proc=AutoImageProcessor.from_pretrained(M,local_files_only=True);m=Mask2FormerForUniversalSegmentation.from_pretrained(M,local_files_only=True,torch_dtype=torch.float16).cuda().eval();m.requires_grad_(False)
rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())}
for n,sid in enumerate(ids):
 d=torch.load(R/'work/lane_geometry/rgb_cache'/(sid+'.pt'),map_location='cpu',weights_only=False);assert rows[sid]['split']=='train' and d['clean_sha256']==rows[sid]['clean_sha256'];file=C/(sid+'.pt')
 if file.exists():
  old=torch.load(file,map_location='cpu',weights_only=False);assert old['clean_sha256']==d['clean_sha256'];continue
 im=Image.fromarray(d['clean'].permute(1,2,0).numpy());inputs=proc(images=im,return_tensors='pt',size=dict(shortest_edge=512,longest_edge=768)).to('cuda');inputs['pixel_values']=inputs['pixel_values'].half()
 with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):out=m(**inputs);labels=proc.post_process_semantic_segmentation(out,target_sizes=[(512,512)])[0].cpu()
 target=torch.stack([(labels==24),(labels==23)]).float()[None];target=torch.nn.functional.avg_pool2d(target,4,4)[0];weight=torch.nn.functional.avg_pool2d((d['mask'].float()*d['valid'].float())[None],4,4)[0];assert target.shape==(2,128,128) and weight.shape==(1,128,128);torch.save(dict(id=sid,split='train',target=target.half(),weight=weight.half(),clean_sha256=d['clean_sha256'],provenance='Frozen Mapillary teacher hard segmentation pooled4px. Pseudo-labels only, no verified arrow semantics.'),file);(O/'cache_status.json').write_text(json.dumps(dict(phase='caching',completed=n+1,total=1000,updated_at=time.time())))
(O/'cache_status.json').write_text(json.dumps(dict(phase='complete',completed=1000,total=1000,updated_at=time.time())))
