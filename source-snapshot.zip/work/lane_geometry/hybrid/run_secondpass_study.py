from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'secondpass_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py='/path/to/user-home/anaconda3/envs/snow-edit/bin/python'
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
def active(path,title,total,loss):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Text-free dual-feature conditioning, original Klein frozen;1,000 distinct TRAIN pairs, no TEST tuning.',total=total,result_path='secondpass_study_review/',show_loss=loss,next_text='Four fixed development previews and CPU comparison against step1400; lane accuracy remains unverified.')))
def run(script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([py,str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 assert json.loads((P/'expanded_cache/audit.json').read_text())['phase']=='passed'
 active('secondpass_study/control/status.json','Second 1,000-pair pass — lower learning rate',1000,True);status(phase='training',completed=0,total=1000);run('train_secondpass_study.py','--arm','control')
 assert json.loads((O/'control/smoke_check.json').read_text())['passed']
 active('secondpass_study/status.json','Generating larger-data previews',4,False)
 for i in range(4):status(phase='evaluating',completed=i,total=4);run('evaluate_secondpass_study.py','--arm','control','--index',str(i))
 gallery=P/'secondpass_study_review';(gallery/'control').symlink_to('../expanded_study_review/expanded',target_is_directory=True) if not (gallery/'control').exists() else None
 status(phase='scoring',completed=4,total=4)
 with (O/'sequence.log').open('a') as log:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(H/'score_secondpass_study.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
 status(phase='complete',completed=4,total=4,result='/lane_geometry/klein_hybrid/secondpass_study_review/')
except Exception as e:status(phase='failed',error=repr(e));raise
