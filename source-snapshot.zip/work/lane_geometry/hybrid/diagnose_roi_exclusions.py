from pathlib import Path
import json,time,numpy as np,torch
from PIL import Image
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
from edit_roi_head import EditROIHead
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'roi_exclusion_diagnostic';O.mkdir(exist_ok=True);ids=json.loads((P/'broad_validation_protocol.json').read_text())['validation_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};MP=R/'work/snow_replacements820/cityscapes_model';torch.set_num_threads(4)
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 status(phase='loading',completed=0,total=20);m=SegformerForSemanticSegmentation.from_pretrained(MP,local_files_only=True).cuda().eval();m.requires_grad_(False);proc=SegformerImageProcessor.from_pretrained(MP,local_files_only=True);head=EditROIHead().cuda().eval();head.load_state_dict(torch.load(P/'roi_pilot/best.pt',map_location='cpu',weights_only=False)['head']);records=[]
 for n,sid in enumerate(ids):
  r=rows[sid];assert r['split']=='validation';im=Image.open(r['snowy']).convert('RGB');w,h=im.size
  with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):f=m.segformer(**proc(images=im,return_tensors='pt').to('cuda'),output_hidden_states=True).hidden_states;sem=m.decode_head(f).float()
  with torch.inference_mode():
   raw=head([x.float() for x in f],(h,w)).sigmoid()>=.5;labels=torch.nn.functional.interpolate(sem,size=(h,w),mode='bilinear',align_corners=False).argmax(1,keepdim=True);protected=(labels==1)|(labels>=11);permit=raw&~protected
  raw=raw[0,0].cpu().numpy();protected=protected[0,0].cpu().numpy();permit=permit[0,0].cpu().numpy();target=np.array(Image.open(r['mask']).convert('L').resize((w,h),Image.Resampling.NEAREST))>127;den=max(1,int(target.sum()));a=int((target&~raw).sum())/den;b=int((target&raw&protected).sum())/den;c=int((target&permit).sum())/den;assert abs(a+b+c-1)<1e-6
  cached=torch.load(R/'work/lane_geometry/hybrid_pilot_geometry'/(sid+'.pt'),map_location='cpu',weights_only=False)['permitted_native'].numpy().astype(bool);assert np.array_equal(cached,permit)
  records.append(dict(id=sid,head_missed_fraction=a,protection_excluded_fraction=b,covered_fraction=c));dst=O/sid;dst.mkdir(exist_ok=True)
  for name,mask in [('head',raw),('protected',protected),('permitted',permit)]:Image.fromarray(mask.astype(np.uint8)*255).save(dst/(name+'.png'))
  status(phase='checking',completed=n+1,total=20)
 report=dict(phase='complete',validation_images=20,mean={k:float(np.mean([x[k] for x in records])) for k in ['head_missed_fraction','protection_excluded_fraction','covered_fraction']},records=records,warning='Against historical edit regions only; protected cars/sidewalks can be intentionally excluded and some labels include hood. Do not disable protection based on coverage alone. No updates or threshold search.');(O/'summary.json').write_text(json.dumps(report,indent=2));status(phase='complete',completed=20,total=20);print(json.dumps(report))
except Exception as e:status(phase='failed',error=repr(e));raise
