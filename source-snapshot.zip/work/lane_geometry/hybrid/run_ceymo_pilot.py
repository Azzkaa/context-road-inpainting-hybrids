from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'ceymo_pretraining';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py=R/'work/inpainting_compare/venv/bin/python'
def active(path,title,total,loss=False):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='External CeyMo author directional-arrow polygons;1871TRAIN/228vehicle-heldoutVAL.100update readiness pilot; original paired splits and Klein unchanged.',total=total,result_path='ceymo_pretraining_review/',show_loss=loss,next_text='Review shape/class predictions and memory/checkpoint gates before longer pretraining. External clear-road scores are not snowy accuracy.')))
def run(script):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 assert json.loads((P/'ceymo_train_audit/summary.json').read_text())['phase']=='passed';active('ceymo_pretraining/status.json','Directional-marking pretraining:100-update pilot',100,True);run('train_ceymo_pilot.py');assert json.loads((O/'gate.json').read_text())['passed'];active('ceymo_pretraining/evaluation_status.json','Evaluating external directional-marking pilot',8);run('evaluate_ceymo_pilot.py');(O/'pipeline_status.json').write_text(json.dumps(dict(phase='complete',training_updates=100,external_validation_previews=8,updated_at=time.time())))
except Exception as e:(O/'pipeline_status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
