from expanded_selection import selection,R
import torch,json,hashlib,time
P=R/'outputs/lane_geometry/klein_hybrid';rows,train,val=selection();start=time.time();roi=hashlib.sha256((P/'roi_pilot/best.pt').read_bytes()).hexdigest();assert len(train)==1000 and len(set(train))==1000 and not set(train)&set(val);torch.set_num_threads(4)
for n,sid in enumerate(train+val):
 r=rows[sid];g=torch.load(R/'work/lane_geometry/hybrid_pilot_geometry'/(sid+'.pt'),map_location='cpu',weights_only=False);f=torch.load(R/'work/lane_geometry/hybrid_pilot_features'/(sid+'.pt'),map_location='cpu',weights_only=False);d=torch.load(R/'work/lane_geometry/klein_full_cache'/(sid+'_512.pt'),map_location='cpu',weights_only=False) if sid in train else None
 assert g['split']==f['split']==r['split']==('train' if sid in train else 'validation');assert g['source_sha256']==f['source_sha256']==r['snowy_sha256'];assert g['roi_sha256']==roi
 assert g['geometry'].shape==(1,131,32,32) and torch.isfinite(g['geometry']).all();assert g['loss_weights'].shape==(1,1,32,32) and torch.isfinite(g['loss_weights']).all() and g['loss_weights'].min()>=0
 for key in ['clr','cond']:assert f[key].shape==(1,64,32,32) and torch.isfinite(f[key]).all()
 if d is not None:
  assert d['split']=='train'
  for key in ['clean','snowy']:assert torch.isfinite(d[key]).all()
 assert hashlib.sha256(__import__('pathlib').Path(r['snowy']).read_bytes()).hexdigest()==r['snowy_sha256']
 (P/'expanded_cache/audit_status.json').write_text(json.dumps(dict(phase='auditing',completed=n+1,total=1004,updated_at=time.time())))
report=dict(phase='passed',train=1000,validation=4,source_hashes_verified=1004,finite=True,original_splits_preserved=True,roi_sha256=roi,seconds=time.time()-start,limitation='Structural/provenance audit, not semantic correctness or lane accuracy.')
(P/'expanded_cache/audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
