"""Fixed paired originalVAL transfer, no directional GT and no accuracy claim."""
from directional_instances import *
from marking_shape import ShapeClassifier,normalize_main_component
import time,fcntl
O=P/'instance_domain_transfer';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);torch.set_num_threads(4);data=Data();m=model().cuda().eval();m.load_state_dict(torch.load(P/'directional_instance_class_study/control/latest.pt',map_location='cpu',weights_only=False)['trainable'],strict=False);heads={}
for arm in ['clean_control','mixed_predicted']:
 heads[arm]=ShapeClassifier().cuda().eval();heads[arm].load_state_dict(torch.load(P/'marking_shape_component_domain_study'/arm/'latest.pt',map_location='cpu',weights_only=False)['model'])
ids=json.loads((P/'lane_generation_protocol.json').read_text())['validation_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};records=[];colors=np.array(COLORS,np.uint8)
try:
 for n,sid in enumerate(ids):
  row=rows[sid];assert row['split']=='validation';dst=O/sid;dst.mkdir(exist_ok=True)
  for kind in ['clean','snowy']:
   im=Image.open(row[kind]).convert('RGB');batch=data.proc(images=im,return_tensors='pt',size={'shortest_edge':768,'longest_edge':1024});H,W=batch['pixel_values'].shape[-2:];image=np.array(im.resize((W,H)));batch={k:v.cuda() for k,v in batch.items()}
   with torch.inference_mode():out=m(**batch);r=data.proc.post_process_instance_segmentation(out,threshold=.5,mask_threshold=.5,overlap_mask_area_threshold=.8,target_sizes=[(H,W)])[0]
   seg=r['segmentation'];seg=seg.cpu().numpy() if seg is not None else np.full((H,W),-1)
   for arm in ['detector','clean_control','mixed_predicted']:
    info=[dict(v) for v in r['segments_info']]
    if arm!='detector':
     for item in info:
      a=seg==item['id']
      if item['label_id'] not in [4,6,7,9,10] or not a.any():continue
      x=torch.from_numpy(normalize_main_component(Image.fromarray((a*255).astype(np.uint8))).copy())[None,None].cuda().float()/255
      with torch.inference_mode():confidence,label=heads[arm](x).softmax(-1)[0].max(0)
      if float(confidence)>=.5 and int(label) in [4,6,7,9,10]:item['label_id']=int(label)
    overlay=image.copy()
    for v in info:
     a=seg==v['id'];overlay[a]=(.3*overlay[a]+.7*colors[v['label_id']+1]).astype(np.uint8)
    Image.fromarray(overlay).save(dst/(kind+'_'+arm+'.png'));records.append(dict(id=sid,input=kind,arm=arm,predicted_segments=info))
  (O/'status.json').write_text(json.dumps(dict(phase='probing',completed=n+1,total=len(ids),updated_at=time.time())))
 page='<meta charset="utf-8"><style>body{background:#142033;color:white;font:18px system-ui;margin:30px}a{color:#8df}img{width:32%}</style><h1>Clear / snow transfer: fixed8originalVAL</h1><p>Separate clean and snowy inference. Clean never supplied to snow. Left detector / middle annotation-only classifier / right mixed-shape classifier. Class regions are NOT restored paint. No verified directional labels here; no numerical accuracy claim.</p><a href="../progress/">Live progress</a>'
 for sid in ids:
  for kind in ['clean','snowy']:page+='<h2>'+sid+' '+kind+'</h2>'+''.join('<img src="'+sid+'/'+kind+'_'+a+'.png">' for a in ['detector','clean_control','mixed_predicted'])
 (O/'index.html').write_text(page);(O/'summary.json').write_text(json.dumps(dict(records=records,warning='Qualitative pairedVAL transfer only, NOT verified lane accuracy. No GT/clean inputs at snowy inference.'),indent=2));(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=8,total=8,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
