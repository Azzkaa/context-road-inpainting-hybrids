from pathlib import Path
import json,random
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'ceymo_pretraining';O.mkdir(exist_ok=True);d=json.loads((P/'ceymo_train_audit/summary.json').read_text());assert d['phase']=='passed';train=[r for r in d['records'] if (r['vehicle'],r['camera'])!=(3,1)];val=[r for r in d['records'] if (r['vehicle'],r['camera'])==(3,1)];random.Random(20261124).shuffle(train);random.Random(20261124).shuffle(val);assert len(train)==1871 and len(val)==228 and not {r['image_sha256'] for r in train}&{r['image_sha256'] for r in val};counts={}
for r in train:
 for k,n in r['class_instances'].items():counts[k]=counts.get(k,0)+n
protocol=dict(external_train=train,external_validation=val,validation_group=dict(vehicle=3,camera=1),train_class_instances=counts,seed=20261124,input_canvas=1024,initial_pilot_updates=100,head_lr=.0003,encoder_lr=.00001,official_archive_sha256=d['archive_sha256'],scope='External clear-road semantic pretraining only; original pairedTRAIN/VAL/TESTunchanged. Official externalTESTsample excluded from all training. Vehicle/camera holdout is not verified geography independence.')
file=O/'protocol.json'
if file.exists():assert json.loads(file.read_text())==protocol
else:file.write_text(json.dumps(protocol,indent=2))
print('Frozen external split:1871TRAIN/228VAL; no officialTEST or original paired data mixed.')
