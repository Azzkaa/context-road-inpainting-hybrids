"""Local pretrained object-query candidate and author-polygon target conversion."""
from pathlib import Path
import json,torch,numpy as np
from PIL import Image,ImageDraw
from torch import nn
from transformers import Mask2FormerForUniversalSegmentation,AutoImageProcessor
from transformers.models.mask2former.modeling_mask2former import Mask2FormerLoss
from ceymo_layout import CLASSES,COLORS
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';MODEL=R/'work/lane_geometry/models/mask2former_mapillary'
def model():
 m=Mask2FormerForUniversalSegmentation.from_pretrained(MODEL,local_files_only=True);old=m.class_predictor;new=nn.Linear(old.in_features,12)
 with torch.no_grad():
  for i,c in enumerate(CLASSES[1:]):new.weight[i].copy_(old.weight[23 if c=='PC' else 24]);new.bias[i].copy_(old.bias[23 if c=='PC' else 24])
  new.weight[11].copy_(old.weight[-1]);new.bias[11].copy_(old.bias[-1])
 m.class_predictor=new;m.config.num_labels=11;m.config.id2label=dict(enumerate(CLASSES[1:]));m.config.label2id={v:k for k,v in m.config.id2label.items()};m.criterion=Mask2FormerLoss(config=m.config,weight_dict=m.weight_dict);m.model.pixel_level_module.requires_grad_(False)
 init=torch.load(P/'directional_instance_gate/initial_trainable.pt',map_location='cpu',weights_only=False)['trainable'];missing,unexpected=m.load_state_dict(init,strict=False);assert not unexpected;assert all(n in init for n,p in m.named_parameters() if p.requires_grad)
 return m
class Data:
 def __init__(self):self.proc=AutoImageProcessor.from_pretrained(MODEL,local_files_only=True,use_fast=False)
 def get(self,row,device='cuda'):
  im=Image.open(row['image']).convert('RGB');w,h=im.size;batch=self.proc(images=im,return_tensors='pt',size={'shortest_edge':768,'longest_edge':1024});H,W=batch['pixel_values'].shape[-2:];masks=[];labels=[]
  for s in json.loads(Path(row['polygon_annotation']).read_text())['shapes']:
   mask=Image.new('L',(W,H));ImageDraw.Draw(mask).polygon([(x*W/w,y*H/h) for x,y in s['points']],fill=1);a=np.array(mask);assert a.sum()>0; masks.append(torch.from_numpy(a.copy()).float());labels.append(CLASSES[1:].index(s['label']))
  assert masks
  return {k:v.to(device) for k,v in batch.items()},torch.stack(masks).to(device),torch.tensor(labels,device=device),im.resize((W,H))
