from pathlib import Path
import torch,json,time,random
from marking_layout import MarkingLayoutHead
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'marking_layout';O.mkdir(exist_ok=True);protocol=json.loads((P/'lane_generation_protocol.json').read_text());ids=[protocol['train_ids'][i%len(protocol['train_ids'])] for i in range(2400,2650)];torch.set_num_threads(4);torch.manual_seed(20261124);m=MarkingLayoutHead().cuda();opt=torch.optim.AdamW(m.parameters(),lr=.0003,weight_decay=.01);records=[];start=time.time();done=0
if (O/'latest.pt').exists():
 ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);m.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);done=ck['step'];records=ck['records']
try:
 for i in range(done,1000):
  sid=ids[i%len(ids)];scene=torch.load(R/'work/lane_geometry/scene_context_cache'/(sid+'.pt'),map_location='cuda',weights_only=False);geo=torch.load(R/'work/lane_geometry/hybrid_pilot_geometry'/(sid+'.pt'),map_location='cuda',weights_only=False);label=torch.load(R/'work/lane_geometry/marking_teacher_targets'/(sid+'.pt'),map_location='cuda',weights_only=False);assert scene['split']==geo['split']==label['split']=='train' and scene['source_sha256']==geo['source_sha256'];x=scene['features'].float();g=geo['geometry'].float();target=label['target'].float()[None];weight=label['weight'].float()[None];opt.zero_grad(set_to_none=True);logits=m(x,g);pred=logits.sigmoid();bce=torch.nn.functional.binary_cross_entropy_with_logits(logits,target,reduction='none',pos_weight=torch.tensor([8.,8.],device='cuda')[None,:,None,None]);bce=(bce*weight).sum()/(weight.sum()*2).clamp_min(1);dice=1-(2*(pred*target*weight).sum()+1)/((pred*weight).sum()+(target*weight).sum()+1);loss=bce+dice;assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters());torch.nn.utils.clip_grad_norm_(m.parameters(),1.)
  # No optimizer before first full numerical/memory check.
  if i==0:
   assert torch.cuda.max_memory_allocated()/2**30<6.8;(O/'gate.json').write_text(json.dumps(dict(passed=True,optimizer_updates=0,shape=list(logits.shape),finite_grad=True,peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30)))
  opt.step();records.append(dict(step=i+1,id=sid,loss=float(loss.detach()),bce=float(bce.detach()),dice_loss=float(dice.detach())));(O/'status.json').write_text(json.dumps(dict(phase='training',completed=i+1,total=1000,records=records,updated_at=time.time())))
  if i+1 in [2,50] or (i+1)%100==0:
   ck=dict(model={k:v.cpu() for k,v in m.state_dict().items()},optimizer=opt.state_dict(),step=i+1,records=records,train_ids=ids);tmp=O/'latest.tmp';torch.save(ck,tmp);tmp.replace(O/'latest.pt');reload=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert all(torch.equal(v.cpu(),reload['model'][k]) for k,v in m.state_dict().items())
 (O/'status.json').write_text(json.dumps(dict(phase='complete',completed=1000,total=1000,seconds=time.time()-start,warning='TRAIN pseudo-label losses, not true accuracy.',updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
