"""One-case full inference integration check with untrained spatial adapter; no updates."""
from pathlib import Path
import os,sys,json,time,hashlib
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';O=R/'outputs/lane_geometry/klein_hybrid/image_pilot200_review';ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'));sys.path.insert(0,str(W/'klein_training_dependencies'));os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
import torch,numpy as np
from PIL import Image
from diffusers import Flux2Transformer2DModel,Flux2KleinPipeline,AutoencoderKLFlux2,FlowMatchEulerDiscreteScheduler,BitsAndBytesConfig
from peft import LoraConfig,set_peft_model_state_dict
from spatial_adapter import SpatialGeometryAdapter
from image_context import ImageContextAdapter
from klein_bridge import condition_source
from road_only import compose_road
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--index',type=int,default=0);parser.add_argument('--compare-parent',action='store_true');args=parser.parse_args()
start=time.time();O.mkdir(exist_ok=True);torch.set_num_threads(4);torch.manual_seed(20261122);protocol=json.loads((R/'outputs/lane_geometry/klein_hybrid/image_pilot200_protocol.json').read_text());sid=protocol['validation_ids'][args.index];dst=O/sid;dst.mkdir(exist_ok=True);data=torch.load(W/'hybrid_pilot_geometry'/(sid+'.pt'),map_location='cpu',weights_only=False);assert data['split']=='validation';rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};data['source']=rows[sid]['snowy'];assert __import__('hashlib').sha256(Path(data['source']).read_bytes()).hexdigest()==data['source_sha256']
(O/'generation_status.json').write_text(json.dumps({'phase':'loading','id':sid,'optimizer_updates':0}))
try:
 m=Flux2Transformer2DModel.from_pretrained(W/'klein_base/transformer',local_files_only=True,torch_dtype=torch.float16,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'});m.add_adapter(LoraConfig(r=4,lora_alpha=4,target_modules=['to_q','to_k','to_v','to_out.0']));ck=torch.load(R/'outputs/lane_geometry/klein_paired_training/latest.pt',map_location='cpu',weights_only=False);assert ck['step']==6783;set_peft_model_state_dict(m,ck['adapter']);del ck;m.requires_grad_(False);m.eval()
 for mod in m.modules():
  if hasattr(mod,'compute_dtype'):mod.compute_dtype=torch.float16
 adapter=SpatialGeometryAdapter(input_channels=131).cuda().eval();context=ImageContextAdapter().cuda().eval();trained=torch.load(R/'outputs/lane_geometry/klein_hybrid/image_pilot200/latest.pt',map_location='cpu',weights_only=False);assert trained['step']==200;adapter.load_state_dict(trained['spatial']);context.load_state_dict(trained['context']);adapter.requires_grad_(False);context.requires_grad_(False);geometry=data['geometry'].cuda().float();calls=[]
 def source_hook(module,args,kwargs):
  hidden=kwargs['hidden_states'];assert hidden.shape[1]==2048,'Inspection supports one512 source only'
  with torch.autocast('cuda',dtype=torch.float16):source=condition_source(hidden[:,1024:],geometry,adapter,(32,32))
  kwargs['hidden_states']=torch.cat([hidden[:,:1024],source],dim=1)
  with torch.autocast('cuda',dtype=torch.float16):kwargs['encoder_hidden_states']=context(geometry).half()
  calls.append(1);return args,kwargs
 handle=m.register_forward_pre_hook(source_hook,with_kwargs=True)
 vae=AutoencoderKLFlux2.from_pretrained(ROOT/'work/klein_local_20/models/klein_nf4/vae',local_files_only=True,torch_dtype=torch.float32).cuda();vae.enable_tiling();decode=vae.decode;vae.decode=lambda z,*a,**k:decode(z.float(),*a,**k)
 scheduler=FlowMatchEulerDiscreteScheduler.from_pretrained(ROOT/'work/klein_local_20/models/klein_nf4/scheduler',local_files_only=True);pipe=Flux2KleinPipeline(vae=vae,transformer=m,text_encoder=None,tokenizer=None,scheduler=scheduler,is_distilled=False);pipe.set_progress_bar_config(disable=True)
 original=np.array(Image.open(data['source']).convert('RGB'));h,w=original.shape[:2];s=min(512/w,512/h);nw,nh=round(w*s),round(h*s);left,top=(512-nw)//2,(512-nh)//2;a=np.array(Image.fromarray(original).resize((nw,nh),Image.Resampling.LANCZOS));square=Image.fromarray(np.pad(a,((top,512-nh-top),(left,512-nw-left),(0,0)),mode='edge'))
 (O/'generation_status.json').write_text(json.dumps({'phase':'generating','id':sid,'instruction':'none;image-derived context features','optimizer_updates':0}))
 def progress_callback(pipeline,step,timestep,callback_kwargs):
  (O/'generation_status.json').write_text(json.dumps({'phase':'generating','id':sid,'completed_steps':step+1,'total_steps':28,'updated_at':time.time()}));return callback_kwargs
 with torch.inference_mode():raw=pipe(image=square,callback_on_step_end=progress_callback,prompt_embeds=torch.zeros(1,512,7680,device='cuda',dtype=torch.float16),width=512,height=512,num_inference_steps=28,guidance_scale=1.,generator=torch.Generator(device='cuda').manual_seed(20261122)).images[0]
 assert len(calls)==28
 if args.compare_parent:
  handle.remove()
  parent_emb=torch.load(R/'outputs/lane_geometry/klein_comparator/prompt_embeds.pt',map_location='cuda',weights_only=True).half()
  with torch.inference_mode():parent_image=pipe(image=square,prompt_embeds=parent_emb,width=512,height=512,num_inference_steps=28,guidance_scale=1.,generator=torch.Generator(device='cuda').manual_seed(20261122)).images[0]
  parent_image.crop((left,top,left+nw,top+nh)).save(dst/'instructed_parent.png')
 raw=np.array(raw.crop((left,top,left+nw,top+nh)));Image.fromarray(raw).save(dst/'raw_null_text.png');mask=data['permitted_native'].numpy().astype(bool);Image.fromarray(mask.astype(np.uint8)*255).save(dst/'permitted.png');Image.fromarray(original).save(dst/'snowy.png');result,allowed=compose_road(original,raw,mask,np.zeros_like(mask));Image.fromarray(result).save(dst/'road_only_output.png');assert np.array_equal(result[~allowed],original[~allowed])
 record={'updated_at':time.time(),'phase':'complete','id':sid,'steps':28,'source_adapter_calls':len(calls),'context':'learned image-derived features, not language','text_encoder':None,'tokenizer':None,'geometry_shape':list(geometry.shape),'adapter_trained_updates':200,'roi_head_selected_checkpoint_updates':data['roi_step'],'final_output':'candidate native composite through predicted mask; semantic spill still possible','outside_mask_exact':bool(np.array_equal(result[~allowed],original[~allowed])),'optimizer_updates':0,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,'seconds':time.time()-start,'warning':'Early200update development pilot, not converged model or lane accuracy. Source-only predicted mask may spill; inspect before promotion. Original instructed baseline preserved.'};(O/'generation_status.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));(O/'index.html').write_text('<meta charset=\"utf-8\"><style>body{font:18px system-ui;background:#122033;color:white}img{width:32%}</style><h1>Text-free hybrid:200-update continuation</h1><p>200updates; early development run. Left snowy input / middle raw generated image / right candidate road-only composite. Not final training; inspect geometry/mask failures. No language instruction.</p>'+''.join('<img src=\"'+sid+'/'+name+'.png\">' for name in ['snowy','raw_null_text','road_only_output']))
except Exception as e:(O/'generation_status.json').write_text(json.dumps({'phase':'failed','error':repr(e)}));raise
