from pathlib import Path
import json,time
import numpy as np,torch
from PIL import Image
from skimage.metrics import structural_similarity
import lpips
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/image_pilot200_review';protocol=json.loads((O.parent/'image_pilot200_protocol.json').read_text());rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};torch.set_num_threads(4);metric=lpips.LPIPS(net='alex',version='0.1',verbose=False).cpu().eval();records=[]
for sid in protocol['validation_ids']:
 r=rows[sid];assert r['split']=='validation';dst=O/sid;size=Image.open(dst/'raw_null_text.png').size;target=np.array(Image.open(r['clean']).convert('RGB').resize(size,Image.Resampling.LANCZOS));gt=np.array(Image.open(r['mask']).convert('L').resize(size,Image.Resampling.NEAREST))>127;Image.fromarray(target).save(dst/'clean_reference.png')
 for arm,name in [('snowy','snowy.png'),('text_free200_raw','raw_null_text.png'),('text_free200_composite','road_only_output.png'),('instructed_parent6783','instructed_parent.png')]:
  a=np.array(Image.open(dst/name).convert('RGB').resize(size,Image.Resampling.LANCZOS));x=torch.from_numpy(a.copy()).permute(2,0,1)[None].float()/127.5-1;y=torch.from_numpy(target.copy()).permute(2,0,1)[None].float()/127.5-1
  with torch.inference_mode():percept=float(metric(x,y).item())
  aa=a.astype(float)/255;bb=target.astype(float)/255;err=((aa-bb)**2)[gt].mean();ssim,ssmap=structural_similarity(aa,bb,data_range=1,channel_axis=2,full=True,gaussian_weights=True,sigma=1.5,use_sample_covariance=False);records.append({'id':sid,'arm':arm,'lpips':percept,'edit_psnr_db':float(-10*np.log10(max(err,1e-12))),'edit_ssim':float(ssmap.mean(2)[gt].mean())})
summary={'phase':'complete','validation_pairs':4,'fixed_seed':20261122,'steps':28,'comparison':'Same sources/seed/processing, original instructed final6783 parent vs exploratory text-free200 adapters. Parent trained2261pairs; new200pilot reused128TRAINcache, not equal training budget.','mean':{arm:{k:float(np.mean([r[k] for r in records if r['arm']==arm])) for k in ['lpips','edit_psnr_db','edit_ssim']} for arm in sorted(set(r['arm'] for r in records))},'warning':'Four development validation cases only, not test-set result or lane accuracy. No best-of-N. Clean references opened after generation. Composite exact outside predicted native mask, not proof of correct mask semantics.'};(O/'panel_metrics.json').write_text(json.dumps({'summary':summary,'records':records},indent=2))
page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white}a{color:#8df}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}img{width:100%}td,th{padding:12px}figure{margin:0}</style><h1>Text-free200: four validation comparisons</h1><p><a href="../progress/">LIVE PROGRESS</a></p><p>Early development model; snow/geometry/color/mask errors remain possible. Instructed parent is a reference, not part of the text-free inference path. Clean target is display/scoring only.</p><table><tr><th>Arm</th><th>LPIPS ↓</th><th>Edit PSNR ↑</th><th>Edit SSIM ↑</th></tr>'
for arm,v in summary['mean'].items():page+=f'<tr><td>{arm}</td><td>{v["lpips"]:.4f}</td><td>{v["edit_psnr_db"]:.2f}</td><td>{v["edit_ssim"]:.4f}</td></tr>'
page+='</table><p>'+summary['warning']+'</p>'
for sid in protocol['validation_ids']:
 page+='<h2>'+sid+'</h2><div class="grid">'
 for name,label in [('snowy','Snow input'),('clean_reference','Clean reference: never inference guide'),('instructed_parent','Original instructed final parent'),('raw_null_text','Text-free200 raw'),('road_only_output','Text-free200 native composite'),('permitted','Predicted permitted mask')]:page+=f'<figure><img loading="lazy" src="{sid}/{name}.png"><figcaption>{label}</figcaption></figure>'
 page+='</div>'
(O/'index.html').write_text(page);print(json.dumps(summary,indent=2))
