from directional_instances import *
import time,collections,hashlib
O=P/'directional_instance_gate';p=json.loads((P/'ceymo_pretraining/protocol.json').read_text());counts=collections.Counter();overlaps=0;clipped=0;total=0
for split in ['external_train','external_validation']:
 for r in p[split]:
  ann=json.loads(Path(r['polygon_annotation']).read_text());w,h=ann['imageWidth'],ann['imageHeight'];W=1024;H=round(h*W/w);occupied=np.zeros((H,W),bool)
  for s in ann['shapes']:
   assert s['label'] in CLASSES[1:];assert len(s['points'])>=3;assert np.isfinite(s['points']).all();mask=Image.new('L',(W,H));ImageDraw.Draw(mask).polygon([(x*W/w,y*H/h) for x,y in s['points']],fill=1);a=np.array(mask).astype(bool);assert a.any();overlaps+=int((a&occupied).sum());occupied|=a;counts[split+':'+s['label']]+=1;total+=1;clipped+=sum(x<0 or x>=w or y<0 or y>=h for x,y in s['points'])
assert not ({r['id'] for r in p['external_train']}&{r['id'] for r in p['external_validation']})
r=dict(phase='passed',updated_at=time.time(),images=2099,instances=total,counts=dict(counts),overlap_pixels=overlaps,outside_vertices=clipped,semantics='Independent object masks retain overlaps; PIL clipping of recorded outside vertex. All masks nonempty at1024. No generated labels. Author crossing is region including stripe gaps.',protocol_sha256=hashlib.sha256((P/'ceymo_pretraining/protocol.json').read_bytes()).hexdigest());(O/'target_audit.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
