"""Short verified-edit-mask pilot. Frozen encoder, new head only; no clean inputs."""
from pathlib import Path
import json,time,hashlib,io,random,html
import torch,numpy as np
from PIL import Image
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
from edit_roi_head import EditROIHead
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'roi_pilot';O.mkdir(exist_ok=True);MP=R/'work/snow_replacements820/cityscapes_model';rows=json.loads((R/'work/road_restoration/manifest.json').read_text());lookup={r['id']:r for r in rows};train=sorted([r for r in rows if r['split']=='train'],key=lambda r:r['id']);val_ids=json.loads((R/'work/lane_geometry/evaluation_panels.json').read_text())['validation_annotation'];assert len(train)==2261 and len(val_ids)==40 and all(lookup[s]['split']=='validation' for s in val_ids)
config={'stage':'verified edit ROI head pilot','updates':200,'batch_size':4,'train_pool':2261,'validation_pairs':40,'lr':.003,'seed':20261122,'threshold':.5,'loss':'BCEWithLogits (keep pixels weight2/edit pixels weight1) + softDice weight1','trained':'EditROIHead53505params only','frozen':'Cityscapes SegFormer encoder; no clean image input','validation_at':[0,50,200],'label_semantics':'user-verified historical permitted-edit masks, not complete semantic road/hood labels','training_weight_scope':'ROI pixel classification only; NOT Klein road-weighted flow loss','mask_mapping':'nearest resize historical generation mask to native RGB, same as original snow compositor'}
if (O/'config.json').exists():assert json.loads((O/'config.json').read_text())==config
(O/'config.json').write_text(json.dumps(config,indent=2));torch.set_num_threads(4);torch.manual_seed(config['seed']);rng=random.Random(config['seed']);order=list(range(len(train)));rng.shuffle(order);order=(order*2)[:config['updates']*config['batch_size']];start=time.time();records=[];validation=[]
def status(**d):(O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
def load(r):
 ims=[]
 for key in ['snowy','mask']:
  b=Path(r[key]).read_bytes();assert hashlib.sha256(b).hexdigest()==r[key+'_sha256'];ims.append(Image.open(io.BytesIO(b)).convert('RGB' if key=='snowy' else 'L'))
 if ims[0].size!=ims[1].size:ims[1]=ims[1].resize(ims[0].size,Image.Resampling.NEAREST)
 return ims
status(phase='loading',step=0,total=200)
try:
 processor=SegformerImageProcessor.from_pretrained(MP,local_files_only=True);encoder=SegformerForSemanticSegmentation.from_pretrained(MP,local_files_only=True).cuda().eval();encoder.requires_grad_(False);head=EditROIHead(channels=tuple(encoder.config.hidden_sizes)).cuda();init=torch.load(P/'inspection/roi_head_initialization.pt',map_location='cpu',weights_only=False);assert init['trained']is False;head.load_state_dict(init['state_dict']);opt=torch.optim.AdamW(head.parameters(),lr=config['lr'],weight_decay=.01);done=0;best=-1
 def features(images):
  with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16):f=encoder.segformer(**processor(images=images,return_tensors='pt').to('cuda'),output_hidden_states=True).hidden_states
  return [x.float() for x in f]
 def save(step,name='latest.pt'):
  ck={'head':{k:v.detach().cpu() for k,v in head.state_dict().items()},'optimizer':opt.state_dict(),'step':step,'config':config,'records':records,'validation':validation,'best':best,'trained':True};tmp=O/(name+'.tmp');torch.save(ck,tmp);tmp.replace(O/name)
 def evaluate(step):
  head.eval();scores=[];page='<meta charset="utf-8"><meta http-equiv="refresh" content="60"><style>body{font:17px system-ui;background:#122033;color:white}a{color:#8df}img{width:32%}</style><h1>Verified edit-mask training pilot</h1><p>TRAIN images optimize new mask head; these40images are VALIDATION only. Left input / middle predicted permitted-edit mask overlay / right verified historical edit target. This is mask learning, not new Klein lane restoration.</p>'
  for sid in val_ids:
   im,target=load(lookup[sid]);w,h=im.size
   with torch.inference_mode():logits=head(features([im]),(256,256));pred=(logits.sigmoid()[0,0].cpu().numpy()>=.5)
   gt=np.array(target.resize((256,256),Image.Resampling.NEAREST))>127;intersection=int((pred&gt).sum());den=int(pred.sum()+gt.sum());union=int((pred|gt).sum());scores.append({'id':sid,'dice':2*intersection/den if den else 1.,'iou':intersection/union if union else 1.,'false_edit_pixels':int((pred&~gt).sum()),'missed_edit_pixels':int((gt&~pred).sum())})
   dst=O/sid;dst.mkdir(exist_ok=True);a=np.array(im);native=np.array(Image.fromarray(pred.astype(np.uint8)*255).resize((w,h),Image.Resampling.NEAREST))>0;overlay=a.copy();overlay[native]=(.55*a[native]+.45*np.array([40,230,70])).astype(np.uint8)
   for name,img in [('snowy',im),('predicted',Image.fromarray(overlay)),('verified_target',target.convert('RGB'))]:img.thumbnail((768,576));img.save(dst/(name+'.png'))
   Image.fromarray(pred.astype(np.uint8)*255).save(dst/'predicted_mask256.png');page+='<h2>'+sid+'</h2>'+''.join(f'<img src="{sid}/{n}.png">' for n in ['snowy','predicted','verified_target'])
  summary={'step':step,'pairs':40,'mean_dice':float(np.mean([r['dice'] for r in scores])),'mean_iou':float(np.mean([r['iou'] for r in scores])),'warning':'Overlap with verified historical edit masks, not whole-road semantic or lane accuracy. Hood/sidewalk spill still requires visual review.'};(O/f'validation_{step}.json').write_text(json.dumps({'summary':summary,'records':scores},indent=2));validation.append(summary);(O/'index.html').write_text(page);head.train();return summary
 if (O/'latest.pt').exists():
  ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert ck['config']==config;head.load_state_dict(ck['head']);opt.load_state_dict(ck['optimizer']);done=ck['step'];records=ck['records'];validation=ck['validation'];best=ck['best']
 else:evaluate(0)
 for step in range(done,config['updates']):
  batch=[load(train[i]) for i in order[step*4:(step+1)*4]];x=[a for a,b in batch];target=torch.from_numpy(np.stack([np.array(b.resize((256,256),Image.Resampling.NEAREST))>127 for a,b in batch]))[:,None].cuda().float();opt.zero_grad(set_to_none=True);logits=head(features(x),(256,256));prob=logits.sigmoid();weight=2-target;bce=(torch.nn.functional.binary_cross_entropy_with_logits(logits,target,reduction='none')*weight).mean();dice=1-(2*(prob*target).sum((1,2,3))+1)/(prob.sum((1,2,3))+target.sum((1,2,3))+1);loss=bce+dice.mean();assert torch.isfinite(loss);loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in head.parameters());assert all(p.grad is None for p in encoder.parameters());torch.nn.utils.clip_grad_norm_(head.parameters(),1.);opt.step()
  if step+1 in [1,2] or (step+1)%10==0:records.append({'step':step+1,'loss':float(loss.detach()),'bce':float(bce.detach()),'dice_loss':float(dice.mean().detach()),'seconds':time.time()-start});status(phase='training',step=step+1,total=200,records=records[-10:]);print(records[-1],flush=True)
  if step+1 in [2,50,100,150,200]:
   save(step+1)
   if step+1==2:
    ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert all(torch.equal(v.cpu(),ck['head'][k]) for k,v in head.state_dict().items());peak=torch.cuda.max_memory_allocated()/2**30;assert peak<6.8;(O/'smoke_check.json').write_text(json.dumps({'passed':True,'step':2,'finite_gradients':True,'encoder_frozen':True,'checkpoint_reload_equal':True,'peak_allocated_gib':peak}))
  if step+1 in config['validation_at']:
   v=evaluate(step+1)
   if v['mean_dice']>best:best=v['mean_dice'];save(step+1,'best.pt')
   save(step+1)
 status(phase='complete',step=200,total=200,validation=validation,records=records,peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,seconds=time.time()-start,warning='Mask pilot only; learned mask not approved without visual review.')
except Exception as e:status(phase='failed',error=repr(e));raise
