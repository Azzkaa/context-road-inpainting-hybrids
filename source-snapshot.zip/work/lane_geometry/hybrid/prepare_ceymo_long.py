from pathlib import Path
import json,math,numpy as np,hashlib
from PIL import Image
from ceymo_layout import CLASSES,COLORS
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';p=json.loads((P/'ceymo_pretraining/protocol.json').read_text());O=P/'ceymo_directional_training';O.mkdir(exist_ok=True);lookup=np.full(2**24,255,np.uint8)
for i,(r,g,b) in enumerate(COLORS):lookup[(r<<16)|(g<<8)|b]=i
counts=np.zeros(12,np.int64)
for r in p['external_train']:
 a=np.array(Image.open(r['provided_mask']).convert('RGB').resize((256,144),Image.Resampling.NEAREST)).astype(np.int32);labels=lookup[(a[:,:,0]<<16)|(a[:,:,1]<<8)|a[:,:,2]];assert (labels!=255).all();counts+=np.bincount(labels.ravel(),minlength=12)
assert (counts>0).all();weights=[.25]+[min(10.,math.sqrt(int(counts[1:].max())/int(c))) for c in counts[1:]];p.update(parent_checkpoint_sha256=hashlib.sha256((P/'ceymo_pretraining/latest.pt').read_bytes()).hexdigest(),additional_passes=3,additional_updates=3*len(p['external_train']),class_weights=weights,train_pixel_count_estimate=dict(zip(CLASSES,map(int,counts))),pixel_count_resolution=[256,144],objective='Pixel-frequency-weighted CE +0.5foregroundDice. Freshoptimizer, source100pilot preserved. Author masks are marking regions, not everypaintpixel; no augmentation/flipping.',external_scope='All scores external clear-road holdout only, not user snowy recovery.')
f=O/'protocol.json'
if f.exists():assert json.loads(f.read_text())==p
else:f.write_text(json.dumps(p,indent=2))
print('Prepared3finitepasses:',p['additional_updates'],'updates;pixelweights',dict(zip(CLASSES,weights)))
