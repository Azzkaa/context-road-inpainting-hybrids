"""Frozen TRAIN proposals + author one-to-one labels. No optimization or invented negatives."""
from directional_instances import *
from marking_shape import normalize
from scipy.optimize import linear_sum_assignment
import time,hashlib,fcntl,collections
O=P/'predicted_shape_training_audit';O.mkdir(exist_ok=True);C=R/'work/lane_geometry/predicted_shape_training_cache';C.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);torch.set_num_threads(4);source=P/'directional_instance_class_study/control/latest.pt';sha=hashlib.sha256(source.read_bytes()).hexdigest();m=model().cuda().eval();m.load_state_dict(torch.load(source,map_location='cpu',weights_only=False)['trainable'],strict=False);data=Data();rows=json.loads((P/'ceymo_pretraining/protocol.json').read_text())['external_train'];counts=collections.Counter();total=0;unmatched=0;gallery=[]
try:
 for n,row in enumerate(rows):
  assert row['external_split']=='official_train';dst=C/(row['id']+'.pt')
  if dst.exists():
   ck=torch.load(dst,map_location='cpu',weights_only=False);assert ck['source_checkpoint_sha256']==sha and ck['split']=='train';assert ck['source_image_sha256']==hashlib.sha256(Path(row['image']).read_bytes()).hexdigest()
  else:
   batch,gt,labels,im=data.get(row);H,W=im.size[1],im.size[0]
   with torch.inference_mode():out=m(**batch);result=data.proc.post_process_instance_segmentation(out,threshold=.5,mask_threshold=.5,overlap_mask_area_threshold=.8,target_sizes=[(H,W)])[0]
   seg=result['segmentation'];seg=seg.cpu().numpy() if seg is not None else np.full((H,W),-1);items=[v for v in result['segments_info'] if v['label_id'] in [4,6,7,9,10] and (seg==v['id']).any()];pm=[seg==v['id'] for v in items];gm=gt.cpu().numpy().astype(bool);gl=labels.cpu().tolist();iou=np.zeros((len(gm),len(pm)))
   for i,g in enumerate(gm):
    for j,a in enumerate(pm):iou[i,j]=(g&a).sum()/max(1,(g|a).sum())
   matches={}
   if iou.size:
    valid=iou>=.5;ii,jj=linear_sum_assignment(-(valid.astype(float)*(min(iou.shape)+1)+iou*valid));matches={int(j):(int(i),float(iou[i,j])) for i,j in zip(ii,jj) if valid[i,j]}
   xs=[];ys=[];meta=[]
   for j,a in enumerate(pm):
    xs.append(normalize(Image.fromarray((a*255).astype(np.uint8))));matched=matches.get(j);ys.append(gl[matched[0]] if matched else -1);meta.append(dict(original_label=items[j]['label_id'],author_label=ys[-1],matched_iou=matched[1] if matched else None,max_author_iou=float(iou[:,j].max()) if len(gm) else 0,score=items[j]['score']))
   ck=dict(id=row['id'],split='train',source_checkpoint_sha256=sha,source_image_sha256=hashlib.sha256(Path(row['image']).read_bytes()).hexdigest(),source_annotation_sha256=hashlib.sha256(Path(row['polygon_annotation']).read_bytes()).hexdigest(),shapes=torch.from_numpy(np.stack(xs)) if xs else torch.empty((0,128,128),dtype=torch.uint8),author_labels=torch.tensor(ys,dtype=torch.long),metadata=meta,warning='Only IoU>=.5one-to-one author matches have labels. Unmatched=-1UNKNOWN, not fabricated background/negative. TRAIN ONLY.');torch.save(ck,dst)
  for label in ck['author_labels'].tolist():
   if label>=0:counts[CLASSES[label+1]]+=1
   else:unmatched+=1
  total+=len(ck['author_labels'])
  if len(gallery)<36:
   for i,label in enumerate(ck['author_labels'].tolist()):
    if label>=0 and len(gallery)<36:
     name=row['id']+'_'+str(i)+'.png';Image.fromarray(ck['shapes'][i].numpy()).save(O/name);gallery.append(dict(file=name,id=row['id'],label=CLASSES[label+1],iou=ck['metadata'][i]['matched_iou']))
  (O/'status.json').write_text(json.dumps(dict(phase='caching_train_proposals',completed=n+1,total=1871,updated_at=time.time(),matched_class_counts=dict(counts),unmatched_unknown=unmatched)))
 report=dict(phase='complete',images=1871,proposals=total,matched_class_counts=dict(counts),unmatched_unknown=unmatched,source_checkpoint_sha256=sha,warning='Author matched TRAIN proposals, not model pseudo-labels. Unmatched ignored, never negative. No classifier training yet; audit visual quality before use.');(O/'summary.json').write_text(json.dumps(report,indent=2));page='<meta charset="utf-8"><style>body{background:#142033;color:white;font:18px system-ui}img{width:128px}a{color:#8df}</style><h1>TRAIN predicted-shape / author-label audit</h1><p>Frozen detector shapes; one-to-one author maskIoU≥0.5. Unmatched remains unknown. No optimization or VAL training.</p><a href="../progress/">Progress</a>'
 for g in gallery:page+='<p>'+g['id']+' '+g['label']+' IoU'+str(round(g['iou'],3))+'</p><img src="'+g['file']+'">'
 (O/'index.html').write_text(page);(O/'status.json').write_text(json.dumps(dict(report,completed=1871,total=1871,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
