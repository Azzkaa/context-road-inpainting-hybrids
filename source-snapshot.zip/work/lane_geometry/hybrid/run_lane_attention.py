from pathlib import Path
import json,time,subprocess,fcntl,hashlib
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'lane_attention_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py='/path/to/user-home/anaconda3/envs/snow-edit/bin/python';protocol=json.loads((P/'lane_attention_protocol.json').read_text())
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
def active(path,title,total,loss):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Lane-focused attention adaptation: base frozen;491,520 attention LoRA parameters + image/spatial adapters train. Same250TRAIN examples/noise as preserved control.',total=total,result_path='lane_attention_review/',show_loss=loss,next_text='Eight generated comparisons; road-only compositing unchanged.')))
def run(interpreter,script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(interpreter),str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 assert json.loads((P/'attention_scope_gate.json').read_text())['phase']=='passed'
 assert hashlib.sha256((P/'secondpass_study/control/latest.pt').read_bytes()).hexdigest()==protocol['continuation_sha256']
 active('lane_attention_study/attention/status.json','Lane generation: adapting attention',250,True);status(phase='training',completed=0,total=250);run(py,'train_lane_attention.py','--arm','attention')
 assert json.loads((O/'attention/smoke_check.json').read_text())['attention_lora_trainable']==491520
 active('lane_attention_study/status.json','Generating attention-adapted lane comparisons',8,False)
 for i,sid in enumerate(protocol['validation_ids']):
  status(phase='generating',completed=i,total=8,id=sid)
  if not (P/'lane_attention_review/attention'/sid/'road_only_output.png').exists():run(py,'evaluate_lane_attention.py','--arm','attention','--index',str(i))
  assert (P/'lane_attention_review/attention'/sid/'raw_null_text.png').exists()
 status(phase='scoring',completed=8,total=8);run(R/'work/inpainting_compare/venv/bin/python','score_lane_attention.py');status(phase='complete',completed=8,total=8,result='/lane_geometry/klein_hybrid/lane_attention_review/')
except Exception as e:status(phase='failed',error=repr(e));raise
