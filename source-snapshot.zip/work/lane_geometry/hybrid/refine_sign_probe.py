from pathlib import Path
import json,time
from PIL import Image
import numpy as np
from sign_icon_geometry import arrow_candidates
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';S=P/'sign_arrow_probe';O=P/'sign_arrow_probe_v2';O.mkdir(exist_ok=True);summary=json.loads((S/'summary.json').read_text());records=[];page='<meta charset="utf-8"><style>body{font:18px system-ui;background:#122033;color:white;margin:30px}a{color:#8df}img{max-width:300px;max-height:230px;margin:10px}.card{display:inline-block;padding:10px;border:1px solid #789}</style><h1>Visible sign-arrow evidence probe</h1><p>Automatic source-only sign crops plus black-panel/white-icon geometric candidates. No prompts, OCR, clean inputs or generated road paint. Candidates remain unverified; sign-to-lane association and painted-arrow placement are unresolved.</p><a href="../progress/">Live progress</a>'
for rec in summary['records']:
 sid=rec['id'];dst=O/sid;dst.mkdir(exist_ok=True);page+='<h2>'+sid+'</h2>';new=[]
 for n,sign in enumerate(rec['detected_signs']):
  source=S/sid/sign['crop'];crop=np.array(Image.open(source).convert('RGB'));image='sign_%02d.png'%n;Image.fromarray(crop).save(dst/image);units=[]
  for j,u in enumerate(arrow_candidates(crop)):
   pn='panel_%02d_%02d.png'%(n,j);mn='arrow_%02d_%02d.png'%(n,j);Image.fromarray(u.pop('panel')).save(dst/pn);Image.fromarray(u.pop('icon')).save(dst/mn);units.append(dict(**u,panel_file=pn,icon_file=mn))
  new.append(dict(native_bbox=sign['native_bbox'],crop=image,candidates=units));page+='<div class="card"><p>Detected sign</p><img src="'+sid+'/'+image+'">'+''.join('<p>Icon candidate: '+u['direction']+'</p><img src="'+sid+'/'+u['panel_file']+'"><img src="'+sid+'/'+u['icon_file']+'">' for u in units)+'</div>'
 records.append(dict(id=sid,signs=new))
(O/'summary.json').write_text(json.dumps(dict(phase='complete',records=records,warning='Unverified geometric cue candidates only, not restored paint or independently verified accuracy.'),indent=2));(O/'index.html').write_text(page);print([(r['id'],[u['direction'] for s in r['signs'] for u in s['candidates']]) for r in records])
