from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'decoded_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);py='/path/to/user-home/anaconda3/envs/snow-edit/bin/python';H=R/'work/lane_geometry/hybrid'
def status(**d):
 (O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2));train=d.get('phase')=='training';arm=d.get('arm','');cfg={'enabled':True,'status_path':f'decoded_study/{arm}/status.json' if train else 'decoded_study/status.json','title':'Decoded-road objective — '+(arm if train else d.get('phase','pending')),'description':'Matched50-update branches from control300. Flow-only control vs flow +0.1roadRGBL1 +0.05edge loss on sigma<=.5. All base/parentLoRA/VAE frozen. Clean TRAIN image is supervision only.','total':50 if train else 8,'result_path':'decoded_study_review/','show_loss':train,'next_text':'After finite training, generate four validation cases per arm and compare raw images separately from masks. No lane-accuracy claim.'};(P/'progress/active_stage.json').write_text(json.dumps(cfg,indent=2))
def run(script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([py,str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 assert json.loads((P/'decoded_loss_gate.json').read_text())['phase']=='passed'
 for arm in ['control','decoded']:status(phase='training',arm=arm);run('train_decoded_study.py','--arm',arm)
 for arm in ['control','decoded']:
  for i in range(4):status(phase='evaluating',arm=arm,completed=i+(4 if arm=='decoded' else 0),total=8);run('evaluate_decoded_study.py','--arm',arm,'--index',str(i))
 status(phase='scoring',completed=8,total=8)
 with (O/'sequence.log').open('a') as log:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(H/'score_decoded_study.py')],stdout=log,stderr=subprocess.STDOUT,cwd=R,check=True)
 status(phase='complete',completed=8,total=8)
except Exception as e:status(phase='failed',error=repr(e));raise
