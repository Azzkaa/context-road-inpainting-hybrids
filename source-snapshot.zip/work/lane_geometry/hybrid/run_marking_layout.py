from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'marking_layout';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py=R/'work/inpainting_compare/venv/bin/python'
def stage(path,title,total,loss=False):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Explicit snowy-input marking/crosswalk layout head; clean TRAIN teacher masks are pseudo-label supervision only. Not restored paint or verified accuracy.',total=total,result_path='marking_layout_review/',show_loss=loss,next_text='Inspect eight predicted validation layouts before any generator integration.')))
def run(script):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 stage('marking_layout/cache_status.json','Preparing marking-layout TRAIN supervision',250);run('cache_marking_targets.py');stage('marking_layout/status.json','Training explicit marking layout head',1000,True);run('train_marking_layout.py');stage('marking_layout/evaluation_status.json','Predicting marking layouts on eight validation scenes',8);run('evaluate_marking_layout.py')
except Exception as e:(O/'evaluation_status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
