"""Finish encoder/head + conditioning integration for inspection; NO optimization."""
from pathlib import Path
import sys,json,hashlib
import numpy as np,torch
from PIL import Image
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
from edit_roi_head import EditROIHead
from feature_alignment import combined_inputs,normalize_expert,align_crop_features
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/inspection';O.mkdir(exist_ok=True);W=R/'work/lane_geometry';MP=R/'work/snow_replacements820/cityscapes_model'
torch.set_num_threads(4);torch.manual_seed(20261122);m=SegformerForSemanticSegmentation.from_pretrained(MP,local_files_only=True).cuda().eval();m.requires_grad_(False);proc=SegformerImageProcessor.from_pretrained(MP,local_files_only=True);head=EditROIHead(channels=tuple(m.config.hidden_sizes)).cuda()
rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};ids=json.loads((W/'evaluation_panels.json').read_text())['validation_annotation'][:6];records=[]
for sid in ids:
 r=rows[sid];assert r['split']=='validation';im=Image.open(r['snowy']).convert('RGB');w,h=im.size;inp=proc(images=im,return_tensors='pt').to('cuda')
 with torch.no_grad():
  features=m.segformer(**inp,output_hidden_states=True).hidden_states
  semantic_logits=m.decode_head(features);semantic_prob=torch.nn.functional.interpolate(semantic_logits,size=(h,w),mode='bilinear',align_corners=False).softmax(1)
  semantic_labels=semantic_prob.argmax(1,keepdim=True);protection=(semantic_labels!=0)&(semantic_labels!=9);sidewalk=semantic_prob[:,1:2]
 logits=head(features,(128,128));assert tuple(logits.shape)==(1,1,128,128) and torch.isfinite(logits).all();loss=logits.square().mean();head.zero_grad();loss.backward();assert torch.isfinite(head.output.weight.grad).all();assert all(p.grad is None for p in m.parameters())
 # No optimizer: persist initialization only; explicit not a trained segmentation checkpoint.
 with torch.no_grad():prob=torch.nn.functional.interpolate(logits,size=(h,w),mode='bilinear',align_corners=False)[0,0].sigmoid().cpu().numpy()
 mask=(prob>=.5)&~protection[0,0].cpu().numpy();assert not mask.any();dst=O/sid;dst.mkdir(exist_ok=True);im.save(dst/'snowy.png');Image.fromarray(mask.astype(np.uint8)*255).save(dst/'permitted.png');Image.fromarray((prob*255).round().astype(np.uint8)).save(dst/'edit_probability.png')
 Image.fromarray(protection[0,0].cpu().numpy().astype(np.uint8)*255).save(dst/'predicted_protection.png');Image.fromarray((sidewalk[0,0].cpu().numpy()*255).astype(np.uint8)).save(dst/'sidewalk_context.png')
 data=torch.load(W/'hybrid_validation_features'/(sid+'.pt'),map_location='cpu',weights_only=False);assert data['source_sha256']==r['snowy_sha256'];zero=torch.zeros(1,1,32,32);protect_grid=align_crop_features(protection.float(),w,h,0).cpu();sidewalk_grid=align_crop_features(sidewalk,w,h,0).cpu();conditioning=combined_inputs(zero,protect_grid,sidewalk_grid,normalize_expert(data['clr'].float()),normalize_expert(data['cond'].float()));assert conditioning.shape==(1,131,32,32)
 torch.save({'geometry':conditioning,'id':sid,'split':'validation','source':r['snowy'],'source_sha256':r['snowy_sha256'],'mask_status':'untrained edit head: conservative all-keep; no override of rejected semantic masks','experts':'frozen aligned normalized pretrained features','source_size':[w,h]},dst/'conditioning.pt')
 records.append({'id':sid,'feature_shapes':[list(x.shape) for x in features],'roi_logits_shape':list(logits.shape),'edit_fraction':float(mask.mean()),'gradient_finite':True,'frozen_encoder_gradients_absent':True})
# Initialization is reproducible, not a learned weight update.
torch.save({'state_dict':{k:v.cpu() for k,v in head.state_dict().items()},'trained':False,'seed':20261122,'channels':list(m.config.hidden_sizes),'optimizer_updates':0},O/'roi_head_initialization.pt')
summary={'phase':'prepared','images':len(records),'records':records,'optimizer_updates':0,'head_parameters':sum(p.numel() for p in head.parameters()),'encoder':'frozen local Cityscapes SegFormer','actual_encoder_head_forward_backward':'passed6validation sources,no optimization','meaning':'Architecture integration only; conservative all-keep is expected, not an improved learned mask. No rejection bypass.'};(O/'preparation.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
