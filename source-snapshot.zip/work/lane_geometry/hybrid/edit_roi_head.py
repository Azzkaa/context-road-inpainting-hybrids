"""Untrained candidate binary edit/keep head for a frozen pretrained image encoder.
Supervise with verified TRAIN edit masks only; this predicts permitted edits, not all semantic road.
No optimizer/training loop is provided here. Initial output strongly favors keep.
"""
import torch
from torch import nn
from torch.nn import functional as F
class EditROIHead(nn.Module):
 def __init__(self,channels=(32,64,160,256),width=32):
  super().__init__();self.projections=nn.ModuleList(nn.Conv2d(c,width,1) for c in channels)
  self.fuse=nn.Sequential(nn.Conv2d(width*len(channels),width,3,padding=1),nn.GroupNorm(8,width),nn.SiLU())
  self.output=nn.Conv2d(width,1,1);nn.init.zeros_(self.output.weight);nn.init.constant_(self.output.bias,-3.)
 def forward(self,features,size):
  assert len(features)==len(self.projections)
  mapped=[F.interpolate(p(f),size=features[0].shape[-2:],mode='bilinear',align_corners=False) for p,f in zip(self.projections,features)]
  logits=self.output(self.fuse(torch.cat(mapped,dim=1)));return F.interpolate(logits,size=size,mode='bilinear',align_corners=False)
