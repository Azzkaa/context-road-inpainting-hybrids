"""Official CeyMo metadata and bounded public sample download; no training."""
from pathlib import Path
import requests,json,time,hashlib,zipfile
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/ceymo_sample_audit';O.mkdir(exist_ok=True);D=R/'work/lane_geometry/external_data/ceymo';D.mkdir(parents=True,exist_ok=True)
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 status(phase='metadata',completed=0,total=1);records=[]
 for name in ['README.md','LICENSE']:
  url='https://raw.githubusercontent.com/oshadajay/CeyMo/main/'+name;r=requests.get(url,timeout=30);r.raise_for_status();(O/name).write_text(r.text);records.append(dict(url=url,sha256=hashlib.sha256(r.content).hexdigest()))
 url='https://drive.google.com/uc?export=download&id=1XSHT6v3PNA8Z38F542OGWTTosfQtEcFr';response=requests.get(url,stream=True,timeout=60);response.raise_for_status();file=D/'official_sample.zip';tmp=D/'official_sample.part';size=0;h=hashlib.sha256()
 with tmp.open('wb') as out:
  for block in response.iter_content(262144):
   if not block:continue
   size+=len(block);assert size<12*1024*1024,'Sample exceeded expected bounded download size';out.write(block);h.update(block);status(phase='downloading',completed=size,total=int(response.headers.get('Content-Length',0)) or size)
 if not zipfile.is_zipfile(tmp):raise RuntimeError('Public sample endpoint did not return a ZIP; no login/confirmation bypass attempted.')
 tmp.rename(file);z=zipfile.ZipFile(file);members=z.namelist();metadata=dict(phase='complete',metadata=records,sample_url=url,final_url=response.url,bytes=size,sha256=h.hexdigest(),archive_members=members,scope='Official ten-image sample only; inspect annotation classes/license/splits before any training. No user images uploaded.');(O/'summary.json').write_text(json.dumps(metadata,indent=2))
 # Validate paths before extracting local research sample.
 for info in z.infolist():
  target=(D/'sample'/info.filename).resolve();assert target.is_relative_to((D/'sample').resolve());assert not ((info.external_attr>>16)&0o170000)==0o120000
 z.extractall(D/'sample');status(phase='complete',completed=1,total=1);print('Official sample downloaded and path-checked:',size,'bytes,',len(members),'members')
except Exception as e:status(phase='failed',error=repr(e));raise
