"""TRAIN-only memorization/target-diversity diagnostic; not accuracy or deployment model."""
from pathlib import Path
import json,time,torch,numpy as np
from PIL import Image
from global_marking_layout import GlobalMarkingLayoutHead
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'layout_capacity_diagnostic';O.mkdir(exist_ok=True);torch.set_num_threads(4);torch.manual_seed(20261124);p=json.loads((P/'lane_generation_protocol.json').read_text());ids=[p['train_ids'][i%len(p['train_ids'])] for i in range(2400,2650)];inventory=[]
for sid in ids:
 d=torch.load(R/'work/lane_geometry/marking_teacher_targets'/(sid+'.pt'),map_location='cpu',weights_only=False);assert d['split']=='train';inventory.append(dict(id=sid,general_mass=float(d['target'][0].sum()),crosswalk_mass=float(d['target'][1].sum())))
chosen=[r['id'] for r in sorted(inventory,key=lambda r:r['crosswalk_mass'],reverse=True)[:2]]
for r in sorted(inventory,key=lambda r:r['general_mass'],reverse=True):
 if r['id'] not in chosen:chosen.append(r['id'])
 if len(chosen)==4:break
summary=dict(train_cases=250,nonempty_crosswalk_cases=sum(r['crosswalk_mass']>1 for r in inventory),nonempty_general_cases=sum(r['general_mass']>1 for r in inventory),chosen_train_only=chosen,inventory=inventory,warning='Teacher pseudo-label diversity, not annotation completeness.');(O/'target_inventory.json').write_text(json.dumps(summary,indent=2));m=GlobalMarkingLayoutHead().cuda();ck=torch.load(P/'global_layout_study/global/latest.pt',map_location='cpu',weights_only=False);m.load_state_dict(ck['model']);opt=torch.optim.AdamW(m.parameters(),lr=.0003,weight_decay=0.);data={}
for sid in chosen:
 a=torch.load(R/'work/lane_geometry/scene_context_cache'/(sid+'.pt'),map_location='cuda',weights_only=False);g=torch.load(R/'work/lane_geometry/hybrid_pilot_geometry'/(sid+'.pt'),map_location='cuda',weights_only=False);t=torch.load(R/'work/lane_geometry/marking_teacher_targets'/(sid+'.pt'),map_location='cuda',weights_only=False);rgb=torch.load(R/'work/lane_geometry/rgb_cache'/(sid+'.pt'),map_location='cuda',weights_only=False);assert a['split']==g['split']==t['split']=='train';data[sid]=(a['features'].float(),g['geometry'].float(),t['target'].float()[None],torch.nn.functional.avg_pool2d(rgb['valid'][None].float(),4,4))
records=[];done=0
if (O/'latest.pt').exists():
 saved=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert saved['step']==1000;m.load_state_dict(saved['model']);done=1000
for i in range(done,1000):
 sid=chosen[i%4];scene,g,target,w=data[sid];opt.zero_grad(set_to_none=True);logits=m(scene,g);pred=logits.sigmoid();loss=(torch.nn.functional.binary_cross_entropy_with_logits(logits,target,reduction='none')*w).sum()/(w.sum()*2).clamp_min(1)+1-(2*(pred*target*w).sum()+1)/((pred*w).sum()+(target*w).sum()+1);assert torch.isfinite(loss);loss.backward();assert all(x.grad is None or torch.isfinite(x.grad).all() for x in m.parameters());torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();records.append(dict(step=i+1,id=sid,loss=float(loss.detach())));(O/'status.json').write_text(json.dumps(dict(phase='memorization_diagnostic',completed=i+1,total=1000,records=records,updated_at=time.time())))
 if (i+1)%250==0:torch.save(dict(model=m.state_dict(),step=i+1,train_ids=chosen),O/'latest.pt')
m.eval();results=[];page='<meta charset="utf-8"><style>body{font:18px system-ui;background:#122033;color:white;margin:30px}img{width:32%}a{color:#8df}</style><h1>TRAIN-only layout memorization diagnostic</h1><p>Not validation accuracy or restoration. Left snowy image / middle clean-teacher marking target / right student prediction. Four deliberately memorized TRAIN examples.</p><a href="../progress/">Live progress</a>'
for sid,(scene,g,target,w) in data.items():
 with torch.inference_mode():prob=m(scene,g).sigmoid();mse=float((((prob-target)**2)*w).sum()/(w.sum()*2).clamp_min(1));threshold=.25;tp=float(((prob>threshold)&(target>threshold)&(w>0)).sum());fp=float(((prob>threshold)&(target<=threshold)&(w>0)).sum());fn=float(((prob<=threshold)&(target>threshold)&(w>0)).sum());results.append(dict(id=sid,target_probability_mse=mse,pseudo_label_train_dice=2*tp/max(1,2*tp+fp+fn),threshold=threshold))
 dst=O/sid;dst.mkdir(exist_ok=True)
 for name,tensor in [('target',target[0]),('prediction',prob[0])]:Image.fromarray((tensor.max(0).values.cpu().numpy()*255).astype(np.uint8)).resize((512,512)).save(dst/(name+'.png'))
 rgb=torch.load(R/'work/lane_geometry/rgb_cache'/(sid+'.pt'),map_location='cpu',weights_only=False);Image.fromarray(rgb['snow'].permute(1,2,0).numpy()).save(dst/'snowy.png');page+='<h2>'+sid+'</h2>'+''.join('<img src="'+sid+'/'+n+'.png">' for n in ['snowy','target','prediction'])
(O/'index.html').write_text(page);(O/'summary.json').write_text(json.dumps(dict(phase='complete',results=results,train_cases=4,updates=1000,warning='Memorization and teacher pseudo-label agreement only; not generalization or true accuracy.'),indent=2));(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=1000,total=1000,updated_at=time.time())))
