"""Image-only layout model with explicit, auditable encoder adaptation scope."""
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
from transformers import SegformerForSemanticSegmentation
class AdaptedLayout(nn.Module):
 def __init__(self,model_path,adapt=False):
  super().__init__();base=SegformerForSemanticSegmentation.from_pretrained(model_path,local_files_only=True);self.backbone=base.segformer;self.backbone.requires_grad_(False)
  if adapt:
   for name,p in self.backbone.named_parameters():
    if name.startswith(('encoder.block.2.','encoder.block.3.','encoder.patch_embeddings.2.','encoder.patch_embeddings.3.','encoder.layer_norm.2.','encoder.layer_norm.3.')):p.requires_grad_(True)
  torch.manual_seed(20261124);self.projections=nn.ModuleList([nn.Conv2d(c,32,1) for c in [32,64,160,256]]);self.head=nn.Sequential(nn.Conv2d(259,64,3,padding=1),nn.GroupNorm(8,64),nn.SiLU(),nn.Conv2d(64,2,1));nn.init.constant_(self.head[-1].bias,-3.)
 def forward(self,pixels,geometry):
  features=self.backbone(pixel_values=pixels,output_hidden_states=True).hidden_states;f=[F.interpolate(p(x),size=(128,128),mode='bilinear',align_corners=False) for p,x in zip(self.projections,features)];return self.head(torch.cat(f+[F.interpolate(geometry,size=(128,128),mode='bilinear',align_corners=False)],1))
