from pathlib import Path
import json,time,math,hashlib,torch,numpy as np
import argparse,random
parser=argparse.ArgumentParser();parser.add_argument('--arm',choices=['uniform','balanced'],required=True);args=parser.parse_args()
from PIL import Image
from ceymo_layout import DirectionalMarkingModel,CLASSES,COLORS
from ceymo_data import CeymoInput,metrics
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'ceymo_arrow_balancing'/args.arm;O.mkdir(parents=True,exist_ok=True);G=P/'ceymo_arrow_balance_review'/args.arm;G.mkdir(parents=True,exist_ok=True);p=json.loads((P/'ceymo_arrow_balancing/protocol.json').read_text());torch.set_num_threads(4);torch.manual_seed(p['seed']);model_path=R/'work/snow_replacements820/cityscapes_model';m=DirectionalMarkingModel(model_path).cuda();parent=P/'ceymo_directional_training/latest.pt';assert hashlib.sha256(parent.read_bytes()).hexdigest()==p['parent_checkpoint_sha256'];ck=torch.load(parent,map_location='cpu',weights_only=False);assert ck['step']==p['parent_step'];m.load_state_dict(ck['model']);source_state=ck;encoder=[a for a in m.backbone.parameters() if a.requires_grad];head=[a for n,a in m.named_parameters() if not n.startswith('backbone.')];opt=torch.optim.AdamW([dict(params=head,lr=p['head_lr']),dict(params=encoder,lr=p['encoder_lr'])],weight_decay=.01);opt.load_state_dict(source_state['optimizer']);opt.param_groups[0]['lr']=p['head_lr'];opt.param_groups[1]['lr']=p['encoder_lr'];torch.set_rng_state(source_state['rng']);torch.cuda.set_rng_state_all(source_state['cuda_rng']);del source_state;loader=CeymoInput(model_path);weights=torch.tensor(p['class_weights'],device='cuda');done=0;records=[];validation=[];best=-1.;N=len(p['external_train']);total=p['additional_updates']
turn_rows={c:[r for r in p['external_train'] if r['class_instances'].get(c,0)>0] for c in p['turn_classes']}
for c in turn_rows:random.Random(20261124).shuffle(turn_rows[c])
(O/'initialization.json').write_text(json.dumps(dict(source_checkpoint_sha256=p['parent_checkpoint_sha256'],same_model_optimizer_and_rng=True,arm=args.arm)))
if (O/'latest.pt').exists():
 ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert ck['protocol']==p;m.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);done=ck['step'];records=ck['records'];validation=ck['validation'];best=ck['best'];torch.set_rng_state(ck['rng']);torch.cuda.set_rng_state_all(ck['cuda_rng'])
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
def save(step,name='latest.pt'):
 ck=dict(model={k:v.cpu() for k,v in m.state_dict().items()},optimizer=opt.state_dict(),step=step,arm=args.arm,records=records,validation=validation,best=best,protocol=p,rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all());tmp=O/'checkpoint.tmp';torch.save(ck,tmp);tmp.replace(O/name);reload=torch.load(O/name,map_location='cpu',weights_only=False);assert all(torch.equal(v.cpu(),reload['model'][k]) for k,v in m.state_dict().items())
def evaluate(step):
 m.eval();matrix=np.zeros((12,12),np.int64);preview_matrix=np.zeros((12,12),np.int64);epoch=step//N;dst=G/('pass_%d'%epoch);dst.mkdir(exist_ok=True);colors=np.array(COLORS,np.uint8)
 for n,row in enumerate(p['external_validation']):
  x,y,image,box=loader.load(row)
  with torch.inference_mode():prediction=m(x).argmax(1);v=y!=255;cm=torch.bincount((y[v]*12+prediction[v]).flatten(),minlength=144).reshape(12,12).cpu().numpy()
  matrix+=cm
  if n<8:preview_matrix+=cm
  if row['id'] in p['preview_ids']:
   l,t,r,b=box;pred=prediction[0,t:b,l:r].cpu().numpy().astype(np.uint8);truth=y[0,t:b,l:r].cpu().numpy().astype(np.uint8);overlay=image.copy();gt=image.copy();overlay[pred>0]=(.3*image[pred>0]+.7*colors[pred][pred>0]).astype(np.uint8);gt[truth>0]=(.3*image[truth>0]+.7*colors[truth][truth>0]).astype(np.uint8)
   for name,a in [('input',image),('author_mask',gt),('prediction',overlay)]:Image.fromarray(a).save(dst/(row['id']+'_'+name+'.png'))
  status(phase='evaluating',completed=n+1,total=len(p['external_validation']),training_step=step,training_total=total)
 report=dict(step=step,external_validation_images=228,full_validation=metrics(matrix),fixed_eight_preview=metrics(preview_matrix));report['turn_arrow_miou']=float(np.mean([report['full_validation']['scores'][c]['pixel_iou'] for c in p['turn_classes']]));(O/('validation_%d.json'%step)).write_text(json.dumps(report,indent=2));page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white;margin:25px}a{color:#8df}img{width:100%}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}</style><h1>Directional-marking pretraining — pass'+str(epoch)+'</h1><p>External clear-road semantic region predictions, NOT restored snowy road images. Left input / middle author mask / right predicted class overlay. Vehicle/camera heldout228images.</p><a href="../../progress/">Live progress</a> · <a href="../changes.html">Changes</a><p>Foreground mIoU on supported holdout classes: '+str(report['full_validation']['foreground_miou_present_gt'])+'. This is not paper instanceF1 or snowy accuracy.</p>'
 for row in [r for r in p['external_validation'] if r['id'] in p['preview_ids']]:page+='<h2>'+row['id']+'</h2><div class="grid">'+''.join('<img src="pass_'+str(epoch)+'/'+row['id']+'_'+name+'.png">' for name in ['input','author_mask','prediction'])+'</div>'
 (G/'index.html').write_text(page);return report
try:
 for i in range(done,total):
  m.train()
  for stage in range(2):m.backbone.encoder.block[stage].eval()
  epoch=i//N;j=i%N
  if args.arm=='uniform':row=p['external_train'][(i+100+p['parent_step'])%N]
  elif j%2==0:row=p['external_train'][(epoch*((N+1)//2)+j//2+100)%N]
  else:
   cls=p['turn_classes'][(j//2)%4];pool=turn_rows[cls];row=pool[(epoch*((N+7)//8)+j//8)%len(pool)]
  x,y,_,_=loader.load(row);opt.zero_grad(set_to_none=True);logits=m(x);valid=y!=255;safe=y.masked_fill(~valid,0);prob=logits.softmax(1);truth=torch.nn.functional.one_hot(safe,12).permute(0,3,1,2).float();v=valid[:,None];present=truth[:,1:].sum((0,2,3))>0;ds=(2*(prob*truth*v).sum((0,2,3))+1)/((prob*v).sum((0,2,3))+(truth*v).sum((0,2,3))+1);dice=1-ds[1:][present].mean() if present.any() else logits.sum()*0;ce=torch.nn.functional.cross_entropy(logits,y,weight=weights,ignore_index=255);loss=ce+.5*dice;assert torch.isfinite(loss);loss.backward();params=head+encoder;assert all(a.grad is None or torch.isfinite(a.grad).all() for a in params);assert all(a.grad is None for a in m.backbone.parameters() if not a.requires_grad);torch.nn.utils.clip_grad_norm_(params,1.)
  if i==0:
   peak=torch.cuda.max_memory_allocated()/2**30;assert peak<6.8;(O/'gate.json').write_text(json.dumps(dict(passed=True,optimizer_updates=0,finite_grad=True,frozen_scope_intact=True,peak_allocated_gib=peak)))
  opt.step();records.append(dict(step=i+1,id=row['id'],loss=float(loss.detach()),ce=float(ce.detach()),dice_loss=float(dice.detach())));status(phase='training',completed=i+1,total=total,records=records)
  if i+1==2 or (i+1)%250==0:save(i+1)
  if (i+1)%N==0:
   report=evaluate(i+1);validation.append(report)
   if report['turn_arrow_miou']>best:best=report['turn_arrow_miou'];torch.save(dict(model={k:v.cpu() for k,v in m.state_dict().items()},step=i+1,validation=report,protocol=p),O/'best.pt')
   save(i+1);save(i+1,'pass_%d.pt'%((i+1)//N))
 status(phase='complete',completed=total,total=total,best_external_validation_turn_arrow_miou=best,validation=validation,warning='External clear-road sampling comparison only. No snowy accuracy, original model or TEST changed.')
except Exception as e:status(phase='failed',error=repr(e));raise
