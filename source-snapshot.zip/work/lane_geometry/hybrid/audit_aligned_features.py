from pathlib import Path
import sys,json,hashlib,gc
import numpy as np,torch,cv2
from PIL import Image
from condlane_features import CondLaneFeatures,preprocess,R
from feature_alignment import align_crop_features
W=R/'work/lane_geometry';sys.path.insert(0,str(W));from benchmark import model_load
O=R/'outputs/lane_geometry/klein_hybrid/alignment_review';O.mkdir(exist_ok=True);C=W/'hybrid_validation_features';C.mkdir(exist_ok=True)
manifest={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};ids=json.loads((W/'evaluation_panels.json').read_text())['validation_annotation'][:6];assert all(manifest[i]['split']=='validation' for i in ids)
torch.set_num_threads(4);records={}
for arm in ['cond','clr']:
 model=CondLaneFeatures().cuda().eval() if arm=='cond' else model_load()[0]
 for sid in ids:
  path=Path(manifest[sid]['snowy']);assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest[sid]['snowy_sha256'];bgr=cv2.imread(str(path));h,w=bgr.shape[:2];cut=round(h*270/590)
  if arm=='cond':x,meta=preprocess(bgr)
  else:
   a=cv2.resize(bgr[cut:],(800,320),interpolation=cv2.INTER_AREA);x=torch.from_numpy(a.copy()).permute(2,0,1)[None].float()/255
  with torch.inference_mode():features=model(x.cuda()) if arm=='cond' else model.extract_feat(x.cuda());aligned=align_crop_features(features[0],w,h,cut).cpu().float()
  assert torch.isfinite(aligned).all() and aligned.shape==(1,64,32,32);dst=O/sid;dst.mkdir(exist_ok=True)
  energy=aligned[0].square().mean(0).sqrt().numpy();display=(energy-energy.min())/(np.ptp(energy)+1e-8);heat=cv2.applyColorMap((display*255).astype(np.uint8),cv2.COLORMAP_TURBO);cv2.imwrite(str(dst/(arm+'_feature_energy.png')),cv2.resize(heat,(512,512),interpolation=cv2.INTER_NEAREST))
  file=C/(sid+'.pt');data=torch.load(file,map_location='cpu',weights_only=False) if file.exists() else {'id':sid,'split':'validation','source_sha256':manifest[sid]['snowy_sha256'],'geometry':'full512letterbox32grid','warning':'feature activations, not calibrated lane probabilities'};data[arm]=aligned.half();torch.save(data,file)
  records.setdefault(sid,{})[arm]={'shape':list(aligned.shape),'nonzero_fraction':float((aligned!=0).float().mean()),'source_sha256':manifest[sid]['snowy_sha256']}
  scale=min(512/w,512/h);nw,nh=round(w*scale),round(h*scale);im=cv2.resize(bgr,(nw,nh));square=np.pad(im,(((512-nh)//2,512-nh-(512-nh)//2),((512-nw)//2,512-nw-(512-nw)//2),(0,0)),mode='edge');cv2.imwrite(str(dst/'snowy_canvas.png'),square)
 del model;gc.collect();torch.cuda.empty_cache()
summary={'phase':'complete','pairs':len(ids),'records':records,'feature_level':'highest resolution neck64x40x100 mapped from crop back to original letterbox','interpretation':'Feature energy is NOT a lane map or confidence. Display confirms coordinate support, not semantic detection correctness. No clean images or masks used. No training.'};(O/'summary.json').write_text(json.dumps(summary,indent=2))
page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white}img{width:32%}</style><h1>Feature alignment: six validation sources</h1><p>Left: snowy512canvas. Middle: CLR feature energy. Right: Cond feature energy. Energy is not lane probability; dark padding/crop region expected. Neither feature map is a verified lane prediction.</p>'
for sid in ids:page+='<h2>'+sid+'</h2>'+''.join(f'<img src="{sid}/{name}.png">' for name in ['snowy_canvas','clr_feature_energy','cond_feature_energy'])
(O/'index.html').write_text(page);print('Aligned six validation sources, two frozen extractors, serial GPU')
