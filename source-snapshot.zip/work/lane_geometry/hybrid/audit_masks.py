from pathlib import Path
import json,hashlib,gc
import numpy as np,torch
from PIL import Image
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
from road_only import compose_road
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/mask_review';O.mkdir(exist_ok=True);W=R/'work/lane_geometry';MP=R/'work/snow_replacements820/cityscapes_model';A=R/'outputs/lane_geometry/road_adaptation/latest.pt'
rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};ids=json.loads((W/'evaluation_panels.json').read_text())['validation_annotation'][:6]
torch.set_num_threads(4);proc=SegformerImageProcessor.from_pretrained(MP,local_files_only=True);m=SegformerForSemanticSegmentation.from_pretrained(MP,local_files_only=True).cuda().eval();cached={}
def labels(image):
 with torch.inference_mode():logits=m(**proc(images=image,return_tensors='pt').to('cuda')).logits
 return torch.nn.functional.interpolate(logits,size=(image.height,image.width),mode='bilinear',align_corners=False).argmax(1)[0].cpu().numpy()
for sid in ids:
 r=rows[sid];assert r['split']=='validation';im=Image.open(r['snowy']).convert('RGB');cached[sid]=labels(im)
m.load_state_dict(torch.load(A,map_location='cpu',weights_only=False)['model']);records=[]
for sid in ids:
 r=rows[sid];im=Image.open(r['snowy']).convert('RGB');a=np.array(im);h,w=a.shape[:2];road=labels(im)==0;sem=cached[sid];sidewalk=sem==1;foreground=sem>=11;nonroad=np.isin(sem,[1,2,3,4,5,6,7,8,10]);protected=foreground|nonroad
 # Conservative bottom strip is a policy, not a detected hood label.
 protected[round(h*.95):]=True;allowed=road&~protected
 out,_=compose_road(a,np.full_like(a,[210,50,180]),road,protected);assert np.array_equal(out[~allowed],a[~allowed]);dst=O/sid;dst.mkdir(exist_ok=True)
 for name,mask in [('road_candidate',road),('protected',protected),('sidewalk_prediction',sidewalk),('permitted',allowed)]:Image.fromarray(mask.astype(np.uint8)*255).save(dst/(name+'.png'))
 overlay=a.copy();overlay[allowed]=(.55*a[allowed]+.45*np.array([30,240,50])).astype(np.uint8);overlay[sidewalk]=(.55*a[sidewalk]+.45*np.array([220,60,230])).astype(np.uint8);Image.fromarray(overlay).save(dst/'overlay.png');Image.fromarray(out).save(dst/'edit_footprint_fixture.png');im.save(dst/'snowy.png')
 # Reference edit mask opened only after input-only predictions. It is not a complete road/foreground label.
 ref=np.array(Image.open(r['mask']).convert('L').resize((w,h),Image.Resampling.NEAREST))>127;inter=(allowed&ref).sum();den=allowed.sum()+ref.sum()
 records.append({'id':sid,'permitted_fraction':float(allowed.mean()),'verified_edit_mask_dice':float(2*inter/den) if den else None,'permitted_outside_historical_edit_pixels':int((allowed&~ref).sum()),'historical_edit_missed_pixels':int((ref&~allowed).sum()),'predicted_sidewalk_overlap_permitted_pixels':int((allowed&sidewalk).sum()),'outside_permitted_exact':bool(np.array_equal(out[~allowed],a[~allowed]))})
summary={'phase':'complete','validation_pairs':6,'records':records,'mean_edit_mask_dice':float(np.mean([r['verified_edit_mask_dice'] for r in records])),'models':{'road_adapted_sha256':hashlib.sha256(A.read_bytes()).hexdigest(),'protection':'original local Cityscapes SegFormer predictions; predicted sidewalk/nonroad/foreground excluded'},'policy':'Exclude predicted nonroad/foreground plus bottom5percent safety strip. No clean image or GT mask as inference input.','limitations':'Weakly adapted road model + out-of-domain Cityscapes protection are not verified semantic masks. Historical edit mask overlap is NOT whole-road accuracy. Bottom5percent strip is not a hood detector and may leave road snow. Magenta output is a synthetic edit-footprint test, not restored output.'};(O/'summary.json').write_text(json.dumps(summary,indent=2))
page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white}img{width:32%}</style><h1>Road-only mask development review</h1><p>Left: source. Middle: green permitted / purple predicted sidewalk. Right: synthetic magenta edit footprint (not generated road). Conservative policy can miss road and still has unknown segmentation errors.</p>'
for sid in ids:page+='<h2>'+sid+'</h2>'+''.join(f'<img src="{sid}/{n}.png">' for n in ['snowy','overlay','edit_footprint_fixture'])
(O/'index.html').write_text(page);print(json.dumps(summary,indent=2))
