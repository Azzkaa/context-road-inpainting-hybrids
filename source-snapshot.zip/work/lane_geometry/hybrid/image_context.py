"""Learn image-derived context to replace semantic language features; no text cache."""
import torch
from torch import nn
from torch.nn import functional as F
class ImageContextAdapter(nn.Module):
 def __init__(self,in_channels=131,width=64,context_dim=7680):
  super().__init__();self.encoder=nn.Sequential(nn.Conv2d(in_channels,width,3,padding=1),nn.GroupNorm(8,width),nn.SiLU());self.project=nn.Linear(width,context_dim)
 def forward(self,geometry):
  assert geometry.ndim==4 and geometry.shape[1]==131
  x=F.adaptive_avg_pool2d(self.encoder(geometry),(16,32)).flatten(2).transpose(1,2)
  return self.project(x)
