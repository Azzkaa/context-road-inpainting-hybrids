import torch,numpy as np
from torch import nn
from PIL import Image
class ShapeClassifier(nn.Module):
 def __init__(self):
  super().__init__();self.net=nn.Sequential(nn.Conv2d(1,16,5,2,2),nn.SiLU(),nn.Conv2d(16,32,3,2,1),nn.SiLU(),nn.Conv2d(32,64,3,2,1),nn.SiLU(),nn.AdaptiveAvgPool2d((4,4)),nn.Flatten(),nn.Linear(1024,128),nn.SiLU(),nn.Linear(128,11))
 def forward(self,x):return self.net(x)
def normalize(mask):
 box=mask.getbbox();assert box;im=mask.crop(box);im.thumbnail((112,112),Image.Resampling.NEAREST);out=Image.new('L',(128,128));out.paste(im,((128-im.width)//2,(128-im.height)//2));return np.array(out,dtype=np.uint8)

def normalize_main_component(mask):
 """Classification input only: discard detached islands before tight aspect crop."""
 from scipy.ndimage import label
 a=np.array(mask)>0;components,n=label(a,structure=np.ones((3,3),np.uint8))
 if not n:raise ValueError('Empty proposal')
 counts=np.bincount(components.ravel());counts[0]=0;main=components==counts.argmax()
 return normalize(Image.fromarray((main*255).astype(np.uint8)))
