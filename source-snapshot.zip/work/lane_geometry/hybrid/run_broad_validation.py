from pathlib import Path
import json,time,subprocess,fcntl,hashlib
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'broad_validation';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py='/path/to/user-home/anaconda3/envs/snow-edit/bin/python';protocol=json.loads((P/'broad_validation_protocol.json').read_text());rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())}
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
def active(path,title,total):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Frozen1400 vs2400 checkpoints on20 additional VAL images. No training or TEST tuning.',total=total,result_path='broad_validation_review/',show_loss=False,next_text='Inspect aggregate and per-image results before more optimization.')))
def run(interpreter,script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(interpreter),str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 for arm,folder in [('1400','expanded_study'),('2400','secondpass_study')]:assert hashlib.sha256((P/folder/'control/latest.pt').read_bytes()).hexdigest()==protocol['checkpoint'+arm+'_sha256']
 for stage,interpreter,script,path in [('features',R/'work/lane_geometry/venv/bin/python','cache_broad_features.py','broad_feature_cache/status.json'),('spatial masks',R/'work/inpainting_compare/venv/bin/python','cache_broad_geometry.py','broad_geometry_cache/status.json')]:
  status(phase='preparing',stage=stage);active(path,'Additional validation: '+stage,1020);run(interpreter,script)
 gallery=P/'broad_validation_review';gallery.mkdir(exist_ok=True)
 for sid in protocol['validation_ids']:
  assert rows[sid]['split']=='validation';ref=gallery/'references'/sid;ref.mkdir(parents=True,exist_ok=True)
  for key,name in [('clean','clean_reference.png'),('snowy','snowy.png')]:
   link=ref/name
   if not link.exists():link.symlink_to(rows[sid][key])
 done=0;active('broad_validation/status.json','20-image comparison: generating40 outputs',40)
 for arm in ['1400','2400']:
  for i,sid in enumerate(protocol['validation_ids']):
   dst=gallery/arm/sid
   if not (dst/'road_only_output.png').exists():
    status(phase='evaluating',arm=arm,id=sid,completed=done,total=40);run(py,'evaluate_broad_validation.py','--arm',arm,'--index',str(i))
   done+=1;status(phase='evaluating',arm=arm,completed=done,total=40)
 status(phase='scoring',completed=40,total=40);run(R/'work/inpainting_compare/venv/bin/python','score_broad_validation.py');status(phase='complete',completed=40,total=40,result='/lane_geometry/klein_hybrid/broad_validation_review/')
except Exception as e:status(phase='failed',error=repr(e));raise
