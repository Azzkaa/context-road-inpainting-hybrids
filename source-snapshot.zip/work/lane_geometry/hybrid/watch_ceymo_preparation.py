"""Keep the existing viewer on the active acquisition/audit stage; never launches training."""
from pathlib import Path
import json,time,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';lock=(P/'ceymo_train_acquisition/viewer.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);owner='ceymo_acquisition_audit';config=P/'progress/active_stage.json';last=None
while True:
 if config.exists() and json.loads(config.read_text()).get('owner')!=owner:break
 acq=json.loads((P/'ceymo_train_acquisition/status.json').read_text());audit=json.loads((P/'ceymo_train_audit/status.json').read_text());failed=acq['phase']=='failed' or audit['phase']=='failed'
 if failed:path='ceymo_train_acquisition/status.json' if acq['phase']=='failed' else 'ceymo_train_audit/status.json';title='CeyMo preparation needs attention';total=1;stage='failed'
 elif acq['phase']!='complete':path='ceymo_train_acquisition/status.json';title='Acquiring official CeyMo TRAIN archive';total=acq.get('total',1);stage=acq['phase']
 else:path='ceymo_train_audit/status.json';title='Auditing official CeyMo TRAIN annotations';total=2099;stage=audit['phase']
 if stage!=last:
  config.write_text(json.dumps(dict(owner=owner,enabled=True,status_path=path,title=title,description='External author-provided arrow/crosswalk polygons. Acquisition counts bytes/archive files; audit counts images. No model training, original paired dataset untouched.',total=total,result_path='ceymo_sample_audit/',show_loss=False,next_text='Validate classes, image/mask alignment and disjointness from exposed TEST sample before pretraining.'),indent=2));last=stage
 if failed or audit['phase']=='complete':break
 time.sleep(1)
