"""Finite 100-update instance pilot; initial/final fixed previews, no renderer integration."""
from directional_instances import *
import time,fcntl
O=P/'directional_instance_pilot';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);torch.set_num_threads(4);torch.manual_seed(20261125)
protocol=json.loads((O/'protocol.json').read_text());assert json.loads((P/'directional_instance_gate/target_audit.json').read_text())['phase']=='passed';assert json.loads((P/'architecture_gate.json').read_text())['training_allowed'];data=Data();m=model().cuda();opt=torch.optim.AdamW([p for p in m.parameters() if p.requires_grad],lr=1e-4,weight_decay=.01);rows=json.loads((P/'ceymo_pretraining/protocol.json').read_text());records=[];start=0
if (O/'latest.pt').exists():
 ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);m.load_state_dict(ck['trainable'],strict=False);opt.load_state_dict(ck['optimizer']);start=ck['step'];records=ck['records'];torch.set_rng_state(ck['rng']);torch.cuda.set_rng_state(ck['cuda_rng'])
def status(phase,done,total): (O/'status.json').write_text(json.dumps(dict(phase=phase,completed=done,total=total,records=records,updated_at=time.time())))
def checkpoint(i):
 state={n:p.detach().cpu().clone() for n,p in m.named_parameters() if p.requires_grad};torch.save(dict(trainable=state,optimizer=opt.state_dict(),step=i,records=records,rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state()),O/'latest.tmp');(O/'latest.tmp').replace(O/'latest.pt');loaded=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert all(torch.equal(v,loaded['trainable'][n]) for n,v in state.items())
def preview(stage):
 G=P/'directional_instance_review';G.mkdir(exist_ok=True);m.eval();page='<meta charset="utf-8"><style>body{background:#142033;color:white;font:18px system-ui}img{width:48%}a{color:#8df}</style><h1>Object-query pilot: '+stage+'</h1><p>Author regions(left) / predicted object regions(right). NOT snowy restoration or official benchmark. Fixed13 external VAL scenes; threshold0.5,mask0.5,overlap0.8. No tuning on these previews.</p><a href="../progress/">Progress</a>';summary=[]
 for row in [r for r in rows['external_validation'] if r['id'] in protocol['preview_ids']]:
  batch,masks,labels,im=data.get(row);H,W=im.size[1],im.size[0]
  with torch.inference_mode():out=m(**batch);result=data.proc.post_process_instance_segmentation(out,threshold=.5,mask_threshold=.5,overlap_mask_area_threshold=.8,target_sizes=[(H,W)])[0]
  target=np.array(im).copy();pred=target.copy();colors=np.array(COLORS,np.uint8)
  for mask,label in zip(masks.cpu().numpy(),labels.cpu().tolist()):target[mask>0]=(.3*target[mask>0]+.7*colors[label+1]).astype(np.uint8)
  seg=result['segmentation'].cpu().numpy()
  for item in result['segments_info']:
   region=seg==item['id'];pred[region]=(.3*pred[region]+.7*colors[item['label_id']+1]).astype(np.uint8)
  sid=row['id'];Image.fromarray(target).save(G/(stage+'_'+sid+'_author.png'));Image.fromarray(pred).save(G/(stage+'_'+sid+'_prediction.png'));page+='<h2>'+sid+'</h2><img src="'+stage+'_'+sid+'_author.png"><img src="'+stage+'_'+sid+'_prediction.png">';summary.append(dict(id=sid,predicted_objects=result['segments_info']))
 (G/(stage+'.html')).write_text(page);(G/'index.html').write_text('<meta charset="utf-8"><h1>Object-query candidate, not restoration</h1><a href="initial.html">Initial</a> · <a href="pilot100.html">100-update pilot (when ready)</a> · <a href="../progress/">Live progress</a>');(O/(stage+'_predictions.json')).write_text(json.dumps(summary,indent=2))
try:
 if start==0:
  status('initial_validation_previews',0,100);preview('initial')
 for i in range(start,100):
  m.train();m.model.pixel_level_module.eval();batch,masks,labels,_=data.get(rows['external_train'][i]);opt.zero_grad(set_to_none=True);torch.cuda.reset_peak_memory_stats();out=m(**batch,mask_labels=[masks],class_labels=[labels]);assert torch.isfinite(out.loss);out.loss.backward();assert all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None);assert all(p.grad is None for p in m.model.pixel_level_module.parameters());assert torch.cuda.max_memory_allocated()/2**30<6.8
  torch.nn.utils.clip_grad_norm_([p for p in m.parameters() if p.requires_grad],1.);opt.step();records.append(dict(step=i+1,id=rows['external_train'][i]['id'],loss=float(out.loss),peak_gib=torch.cuda.max_memory_allocated()/2**30));status('training',i+1,100)
  if i+1 in [1,2,25,50,75,100]:checkpoint(i+1)
 status('final_validation_previews',100,100);preview('pilot100');status('complete',100,100)
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
