"""Place detector crop features onto a shared full-frame Klein canvas before pooling."""
import torch
from torch.nn import functional as F
from coordinates import letterbox

def align_crop_features(features,width,height,crop_top,grid_size=(32,32),canvas=512):
    assert features.ndim==4 and 0<=crop_top<height
    meta=letterbox(width,height,canvas);y0=meta['top']+round(crop_top*meta['nh']/height);y1=meta['top']+meta['nh'];x0=meta['left'];x1=x0+meta['nw']
    expanded=F.interpolate(features,size=(y1-y0,x1-x0),mode='bilinear',align_corners=False)
    full=F.pad(expanded,(x0,canvas-x1,y0,canvas-y1))
    return F.adaptive_avg_pool2d(full,grid_size)

def combined_inputs(road,protected,curb,clr,cond):
    assert clr.shape==cond.shape and clr.shape[1]==64
    assert road.shape==protected.shape==curb.shape==(clr.shape[0],1,*clr.shape[-2:])
    # No confidence calibration/curve labels invented from image-feature magnitudes.
    return torch.cat([road,protected,curb,clr,cond],dim=1)

def normalize_expert(features,epsilon=1e-4):
    """Per-input channel RMS over nonzero support; preserve zero padding exactly.
    Controls incomparable raw feature magnitudes; this is not confidence calibration.
    """
    assert features.ndim==4 and torch.isfinite(features).all()
    support=features.abs().sum(1,keepdim=True)>0
    count=support.sum((-2,-1),keepdim=True).clamp_min(1)
    rms=((features.square()*support).sum((-2,-1),keepdim=True)/count).sqrt().clamp_min(epsilon)
    return features/rms*support
