"""Conservative black-panel/white-arrow geometry probe; unverified, abstains."""
import cv2,numpy as np
def arrow_candidates(crop):
 h,w=crop.shape[:2];gray=cv2.cvtColor(crop[:round(h*.72)],cv2.COLOR_RGB2GRAY);dark=(gray<100).astype(np.uint8);n,cc,stats,_=cv2.connectedComponentsWithStats(dark,8);results=[]
 for x,y,bw,bh,area in stats[1:]:
  if area<max(60,.04*gray.size) or not .65<bw/max(1,bh)<1.6 or area/max(1,bw*bh)<.45:continue
  panel=crop[y:y+bh,x:x+bw];fg=(cv2.cvtColor(panel,cv2.COLOR_RGB2GRAY)>180).astype(np.uint8);my,mx=max(2,round(bh*.07)),max(2,round(bw*.07));fg[:my]=0;fg[-my:]=0;fg[:,:mx]=0;fg[:,-mx:]=0;nn,labels,ss,_=cv2.connectedComponentsWithStats(fg,8);candidates=[]
  for j,(xx,yy,ww,hh,aa) in enumerate(ss[1:],1):
   if aa>max(20,.025*fg.size) and hh>.4*bh and ww>.25*bw:candidates.append((aa,j,xx,yy,ww,hh))
  if not candidates:continue
  _,j,xx,yy,ww,hh=max(candidates);mask=(labels==j).astype(np.uint8);ys,xs=np.where(mask);upper=xs[ys<yy+hh*.4];lower=xs[ys>yy+hh*.72]
  if len(upper)<5 or len(lower)<5:continue
  dx=float((upper.mean()-lower.mean())/max(1,ww));stem_width=(lower.max()-lower.min()+1)/max(1,ww)
  if stem_width>=.55 or abs(dx)<=.15:continue
  results.append(dict(direction='left' if dx<0 else 'right',panel_bbox=[int(x),int(y),int(x+bw),int(y+bh)],normalized_head_stem_offset=dx,panel=panel,icon=mask*255))
 return sorted(results,key=lambda r:r['panel_bbox'][0])
