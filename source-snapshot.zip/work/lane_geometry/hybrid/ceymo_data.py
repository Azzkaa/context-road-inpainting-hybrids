from pathlib import Path
import json,numpy as np,torch
from PIL import Image
from ceymo_layout import CLASSES,COLORS
class CeymoInput:
 def __init__(self,path,device='cuda'):
  cfg=json.loads((Path(path)/'preprocessor_config.json').read_text());self.device=device;self.mean=torch.tensor(cfg['image_mean'],device=device)[None,:,None,None];self.std=torch.tensor(cfg['image_std'],device=device)[None,:,None,None];self.lookup=np.full(2**24,255,np.uint8)
  for i,(r,g,b) in enumerate(COLORS):self.lookup[(r<<16)|(g<<8)|b]=i
 def load(self,row):
  im=Image.open(row['image']).convert('RGB');mask=Image.open(row['provided_mask']).convert('RGB');w,h=im.size;s=min(1024/w,1024/h);nw,nh=round(w*s),round(h*s);l,t=(1024-nw)//2,(1024-nh)//2;image=np.array(im.resize((nw,nh),Image.Resampling.LANCZOS));canvas=np.pad(image,((t,1024-nh-t),(l,1024-nw-l),(0,0)),mode='edge');rgb=np.array(mask.resize((nw,nh),Image.Resampling.NEAREST)).astype(np.int32);labels=self.lookup[(rgb[:,:,0]<<16)|(rgb[:,:,1]<<8)|rgb[:,:,2]];assert (labels!=255).all();target=np.full((1024,1024),255,np.uint8);target[t:t+nh,l:l+nw]=labels;x=torch.from_numpy(canvas.copy()).permute(2,0,1)[None].to(self.device).float()/255;y=torch.from_numpy(target.copy())[None].to(self.device).long();return (x-self.mean)/self.std,y,image,(l,t,l+nw,t+nh)
def metrics(matrix):
 scores={}
 for i,name in enumerate(CLASSES):
  tp=int(matrix[i,i]);gt=int(matrix[i].sum());predicted=int(matrix[:,i].sum());union=gt+predicted-tp;scores[name]=dict(gt_pixels=gt,predicted_pixels=predicted,pixel_iou=tp/union if union else None,pixel_f1=2*tp/(gt+predicted) if gt+predicted else None)
 return dict(scores=scores,foreground_miou_present_gt=float(np.mean([r['pixel_iou'] for n,r in scores.items() if n!='background' and r['gt_pixels']>0])),warning='External clear-road author region masks; pixel metrics, not paper instanceF1 or snowy accuracy.')
