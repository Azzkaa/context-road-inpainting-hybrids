from pathlib import Path
import subprocess,json,time,fcntl,torch
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'marking_shape_component_domain_study';lock=(O/'sequence.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);py=R/'work/inpainting_compare/venv/bin/python';H=R/'work/lane_geometry/hybrid'
def active(arm,evaluate=False):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=('marking_shape_component_domain_evaluation/' if evaluate else 'marking_shape_component_domain_study/')+arm+'/status.json',title='Final shape-domain test: '+arm+(' validation' if evaluate else ' training'),description='Identical initial weights/optimizer/RNG and class labels each batch. Only author vs predicted input shape differs. No generator changes.',total=228 if evaluate else 1000,result_path='marking_shape_component_domain_review/',show_loss=False,next_text='Fixed full228before/afterobjectF1; stop shape-onlybranch if no reliable gain over45.17%detector.')))
try:
 with (O/'sequence.log').open('a') as log:
  for a in ['clean_control','mixed_predicted']:
   active(a);subprocess.run([str(py),str(H/'train_component_domain_study.py'),'--arm',a],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True);active(a,True);subprocess.run([str(py),str(H/'evaluate_component_domain_study.py'),'--arm',a],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
 initial=[torch.load(O/a/'initial.pt',map_location='cpu',weights_only=True) for a in ['clean_control','mixed_predicted']];assert all(torch.equal(initial[0][k],initial[1][k]) for k in initial[0]);ck=[torch.load(O/a/'latest.pt',map_location='cpu',weights_only=False) for a in ['clean_control','mixed_predicted']];assert [v['labels'] for v in ck[0]['records'][-1000:]]==[v['labels'] for v in ck[1]['records'][-1000:]];(O/'matched_state_check.json').write_text(json.dumps(dict(phase='passed',initial_weights_exact=True,last1000_batch_labels_exact=True)))
 page='<meta charset="utf-8"><style>body{background:#142033;color:white;font:18px system-ui;margin:30px}a{color:#8df}td,th{padding:12px}</style><h1>Final matched shape-domain comparison</h1><p>Identical initial model/optimizer/RNG and class-label batches. Fixed228externalVAL detector masks; no GT classifier inputs.</p><table><tr><th>Arm</th><th>ObjectF1</th><th>RegionmIoU</th></tr>'
 reports={}
 for a in ['clean_control','mixed_predicted']:
  d=json.loads((P/'marking_shape_component_domain_evaluation'/a/'pass1.json').read_text());reports[a]=d;page+='<tr><td>'+a+'</td><td>%.2f%%</td><td>%.2f%%</td></tr>'%(100*d['micro_object_f1'],100*d['foreground_pixel_miou'])
 page+='</table><p>Original detector baselineF1=45.17%. No automatic promotion; inspect directions/falsepositives.</p><a href="../progress/">Progress</a>';(P/'marking_shape_component_domain_review/index.html').write_text(page);(O/'comparison.json').write_text(json.dumps(reports,indent=2));(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=2,total=2,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
