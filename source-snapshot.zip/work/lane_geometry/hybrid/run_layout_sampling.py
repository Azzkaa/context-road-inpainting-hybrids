from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'layout_sampling_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py=R/'work/inpainting_compare/venv/bin/python'
def active(path,title,total,loss=False):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Same explicit-layout model and1,000TRAIN pairs; uniform versus crosswalk-balanced second pass. Teacher pseudo-labels, not verified lane accuracy. Generator unchanged.',total=total,result_path='layout_sampling_review/',show_loss=loss,next_text='Eight validation layout comparisons; inspect before any restoration integration.')))
def run(script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 audit=json.loads((P/'expanded_layout_cache/audit.json').read_text());assert audit['phase']=='passed';(O/'protocol.json').write_text(json.dumps(dict(parent_sha256=audit['parent_sha256'],training_pairs=1000,first_pass='All1000uniform in botharms',second_pass='uniform1000 vs500crosswalk+500uniform',crosswalk_candidates=audit['crosswalk_edit_cases'],updates_per_arm=2000,lr=.0001,validation_images=8,warning='CleanTRAIN teacher masks only supervision; no clean inference input. Not verified GT.'),indent=2))
 for arm in ['uniform','balanced']:active('layout_sampling_study/'+arm+'/status.json','Layout sampling: '+arm,2000,True);run('train_layout_sampling.py','--arm',arm)
 import torch
 a=torch.load(O/'uniform/shared_first_pass.pt',map_location='cpu',weights_only=False);b=torch.load(O/'balanced/shared_first_pass.pt',map_location='cpu',weights_only=False);diff=max(float((a['model'][k]-b['model'][k]).abs().max()) for k in a['model']);assert diff<1e-6;(O/'first_pass_match.json').write_text(json.dumps(dict(passed=True,max_parameter_difference=diff,same_first1000_train_ids=a['order'][:1000]==b['order'][:1000])))
 active('layout_sampling_study/evaluation_status.json','Generating expanded-layout sampling comparisons',8)
 for arm in ['uniform','balanced']:run('evaluate_layout_sampling.py','--arm',arm)
 G=P/'layout_sampling_review';G.mkdir(exist_ok=True);ids=json.loads((P/'lane_generation_protocol.json').read_text())['validation_ids'];page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white;margin:25px}a{color:#8df}img{width:100%}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}</style><h1>1,000-pair layout: uniform vs balanced sampling</h1><p>Predicted maps only; not restored paint or verified lane accuracy. Left clean reference / middle uniform / right crosswalk-balanced.</p><p><a href="../progress/">Live progress</a> · <a href="changes.html">Changes</a></p>'
 for sid in ids:page+='<h2>'+sid+'</h2><div class="grid">'+''.join('<img src="'+p+'">' for p in ['uniform/'+sid+'/clean_reference.png','uniform/'+sid+'/layout_overlay.png','balanced/'+sid+'/layout_overlay.png'])+'</div>'
 (G/'index.html').write_text(page);(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=16,total=16,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
