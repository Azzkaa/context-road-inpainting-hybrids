"""Audit official external TRAIN annotations after bounded acquisition; no training."""
from pathlib import Path
import json,time,hashlib,math
from PIL import Image
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'ceymo_train_audit';O.mkdir(exist_ok=True);A=P/'ceymo_train_acquisition';classes=['BL','CL','DM','JB','LA','PC','RA','SA','SL','SLA','SRA']
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 while True:
  state=json.loads((A/'status.json').read_text())
  if state['phase']=='complete':break
  if state['phase']=='failed':raise RuntimeError('Acquisition failed; inspect acquisition status.')
  status(phase='waiting_for_acquisition',completed=0,total=2099);time.sleep(1)
 acquisition=json.loads((A/'summary.json').read_text());root=Path(acquisition['dataset_root']);folders=list(root.rglob('polygon_annotations'));assert len(folders)==1;annotation_dir=folders[0];base=annotation_dir.parent;files=sorted(annotation_dir.glob('*.json'));assert len(files)==2099;sample=json.loads((P/'ceymo_sample_audit/annotation_audit.json').read_text());sample_hashes={r['image_sha256'] for r in sample['records']};records=[];counts={c:0 for c in classes};out_of_bounds=0
 for n,file in enumerate(files):
  d=json.loads(file.read_text());image=base/'images'/(file.stem+'.jpg');mask=base/'mask_annotations'/(file.stem+'.png');assert image.exists() and mask.exists();size=Image.open(image).size;assert size==Image.open(mask).size==(d['imageWidth'],d['imageHeight']);W,H=size;sha=hashlib.sha256(image.read_bytes()).hexdigest();assert sha not in sample_hashes,'Official TRAIN/test-sample image content overlap';shape_counts={}
  for s in d['shapes']:
   assert s['label'] in classes and s['shape_type']=='polygon' and len(s['points'])>=3;assert all(len(p)==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in p) for p in s['points']);out_of_bounds+=sum(not(0<=x<=W and 0<=y<=H) for x,y in s['points']);counts[s['label']]+=1;shape_counts[s['label']]=shape_counts.get(s['label'],0)+1
  records.append(dict(id=file.stem,external_split='official_train',image=str(image),polygon_annotation=str(file),provided_mask=str(mask),image_sha256=sha,annotation_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),width=W,height=H,vehicle=d.get('vehicle'),camera=d.get('camera'),class_instances=shape_counts));status(phase='auditing',completed=n+1,total=2099)
 result=dict(phase='passed',external_train_images=2099,class_instances=counts,author_vertices_outside_image=out_of_bounds,exposed_test_sample_overlap=0,archive_sha256=acquisition['archive_sha256'],records=records,training_updates=0,warning='External author annotations only. Does not validate snowy-domain accuracy. Keep sampleTEST out of training and all original paired splits unchanged.');(O/'summary.json').write_text(json.dumps(result,indent=2));(root.parent/'official_train_manifest.json').write_text(json.dumps(result,indent=2));status(phase='complete',completed=2099,total=2099);print('Official TRAIN annotation audit passed:',counts,'out-of-bounds vertices:',out_of_bounds)
except Exception as e:status(phase='failed',error=repr(e));raise
