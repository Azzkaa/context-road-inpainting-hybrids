"""No-optimizer architecture gate: pretrained query masks, 11 directional region classes."""
from pathlib import Path
import json,time,hashlib,torch,numpy as np
from PIL import Image,ImageDraw
from torch import nn
from transformers import Mask2FormerForUniversalSegmentation,AutoImageProcessor
from transformers.models.mask2former.modeling_mask2former import Mask2FormerLoss
from ceymo_layout import CLASSES
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'directional_instance_gate';O.mkdir(exist_ok=True);torch.set_num_threads(4)
def save(d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 save(dict(phase='loading',completed=0,total=1))
 path=R/'work/lane_geometry/models/mask2former_mapillary';m=Mask2FormerForUniversalSegmentation.from_pretrained(path,local_files_only=True)
 old=m.class_predictor;torch.manual_seed(20261125);new=nn.Linear(old.in_features,12)
 with torch.no_grad():
  for i,c in enumerate(CLASSES[1:]):new.weight[i].copy_(old.weight[23 if c=='PC' else 24]);new.bias[i].copy_(old.bias[23 if c=='PC' else 24])
  new.weight[11].copy_(old.weight[-1]);new.bias[11].copy_(old.bias[-1])
 m.class_predictor=new;m.config.num_labels=11;m.config.id2label=dict(enumerate(CLASSES[1:]));m.config.label2id={v:k for k,v in m.config.id2label.items()};m.criterion=Mask2FormerLoss(config=m.config,weight_dict=m.weight_dict)
 m.model.pixel_level_module.requires_grad_(False);m.train();m.model.pixel_level_module.eval()
 protocol=json.loads((P/'ceymo_pretraining/protocol.json').read_text());rows=protocol.get('external_train',protocol.get('train',[]))
 # Explicitly select an author TRAIN example through the frozen protocol, never VAL.
 if not rows:
  print('protocol keys',list(protocol));raise RuntimeError('TRAIN key not found')
 row=rows[0];sid=row['id'];root=R/'work/lane_geometry/external_data/ceymo/official_train/train';im=Image.open(root/'images'/(sid+'.jpg')).convert('RGB');ann=json.loads((root/'polygon_annotations'/(sid+'.json')).read_text());w,h=im.size
 proc=AutoImageProcessor.from_pretrained(path,local_files_only=True);batch=proc(images=im,return_tensors='pt',size={'shortest_edge':768,'longest_edge':1024});H,W=batch['pixel_values'].shape[-2:];masks=[];labels=[]
 for shape in ann['shapes']:
  assert shape['label'] in CLASSES[1:];mask=Image.new('L',(W,H));ImageDraw.Draw(mask).polygon([(x*W/w,y*H/h) for x,y in shape['points']],fill=1);masks.append(torch.from_numpy(np.array(mask).copy()).float());labels.append(CLASSES[1:].index(shape['label']))
 assert masks
 m=m.cuda();torch.cuda.reset_peak_memory_stats();batch={k:v.cuda() for k,v in batch.items()};save(dict(phase='forward_backward_no_optimizer',completed=0,total=1))
 out=m(**batch,mask_labels=[torch.stack(masks).cuda()],class_labels=[torch.tensor(labels,device='cuda')]);assert torch.isfinite(out.loss);out.loss.backward();grads=[p.grad for p in m.parameters() if p.requires_grad and p.grad is not None];assert grads and all(torch.isfinite(g).all() for g in grads);assert m.class_predictor.weight.grad.abs().sum()>0;assert all(p.grad is None for p in m.model.pixel_level_module.parameters());peak=torch.cuda.max_memory_allocated()/2**30;assert peak<6.8
 trainable={n:p.detach().cpu().clone() for n,p in m.named_parameters() if p.requires_grad};torch.save({'trainable':trainable,'class_names':CLASSES[1:],'optimizer_updates':0},O/'initial_trainable.pt');loaded=torch.load(O/'initial_trainable.pt',map_location='cpu',weights_only=False)['trainable'];assert all(torch.equal(v,loaded[n]) for n,v in trainable.items())
 report=dict(checkpoint_reload_exact=True,phase='passed',completed=1,total=1,no_optimizer_updates=True,train_id=sid,input_shape=list(batch['pixel_values'].shape),class_logits_shape=list(out.class_queries_logits.shape),mask_logits_shape=list(out.masks_queries_logits.shape),finite_loss=float(out.loss),peak_gib=peak,trainable_parameters=sum(p.numel() for p in m.parameters() if p.requires_grad),frozen_parameters=sum(p.numel() for p in m.parameters() if not p.requires_grad),class_mapping=m.config.id2label,initialization='PC from pretrained crosswalk23; remaining classes from generic marking24; null from old null. No pretrained direction recognition claimed.',scope='Frozen Swin/pixel decoder; trainable query transformer, query-mask embeddings and 12-way classifier. Not Klein integration.',limitations='New classes initialized identically; training required. Author polygons are object regions, not paint strokes. No snowy accuracy or sign association.',source_sha256=hashlib.sha256((path/'model.safetensors').read_bytes()).hexdigest())
 (O/'gate.json').write_text(json.dumps(report,indent=2));save(report)
except Exception as e:save(dict(phase='failed',error=repr(e)));raise
