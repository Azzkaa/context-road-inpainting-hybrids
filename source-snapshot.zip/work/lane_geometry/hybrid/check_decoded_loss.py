"""Full NF4 model structural gate: no optimizer, no parameter updates, no test inputs."""
from pathlib import Path
import sys,os,json,time
R=Path(__file__).resolve().parents[3];ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');W=R/'work/lane_geometry';O=R/'outputs/lane_geometry/klein_hybrid'
sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'));sys.path.insert(0,str(W/'klein_training_dependencies'));os.environ['HF_HUB_OFFLINE']='1'
import torch
from diffusers import Flux2Transformer2DModel,Flux2KleinPipeline,BitsAndBytesConfig,AutoencoderKLFlux2
from peft import LoraConfig,set_peft_model_state_dict
from spatial_adapter import SpatialGeometryAdapter
from image_context import ImageContextAdapter
from klein_bridge import forward_text_free
start=time.time();torch.set_num_threads(4);torch.manual_seed(20261122)
(O/'decoded_loss_gate_status.json').write_text(json.dumps({'phase':'loading','optimizer_updates':0}))
try:
 m=Flux2Transformer2DModel.from_pretrained(W/'klein_base/transformer',local_files_only=True,torch_dtype=torch.float16,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'})
 m.add_adapter(LoraConfig(r=4,lora_alpha=4,target_modules=['to_q','to_k','to_v','to_out.0']));ck=torch.load(R/'outputs/lane_geometry/klein_paired_training/latest.pt',map_location='cpu',weights_only=False);assert ck['step']==6783;set_peft_model_state_dict(m,ck['adapter']);del ck
 m.requires_grad_(False);m.enable_gradient_checkpointing();m.train()
 for mod in m.modules():
  if hasattr(mod,'compute_dtype'):mod.compute_dtype=torch.float16
 adapter=SpatialGeometryAdapter(input_channels=131).cuda();context=ImageContextAdapter().cuda()
 rows=json.loads((O/'attention_study_protocol.json').read_text())['train_ids'];d=torch.load(W/'klein_full_cache'/(rows[0]+'_512.pt'),map_location='cuda',weights_only=False);assert d['split']=='train'
 source=Flux2KleinPipeline._pack_latents(d['snowy']).half();target=Flux2KleinPipeline._pack_latents(d['clean']).half();ids=torch.cat([d['target_ids'],d['source_ids']],dim=1);sigma=torch.tensor([.25],device='cuda');clean_tokens=target.clone();noise=torch.randn_like(target);expected=noise-clean_tokens;target=(.75*clean_tokens+.25*noise).requires_grad_(True)
 geometry=torch.load(W/'hybrid_pilot_geometry'/(rows[0]+'.pt'),map_location='cuda',weights_only=False)['geometry'].float()
 vae=AutoencoderKLFlux2.from_pretrained(ROOT/'work/klein_local_20/models/klein_nf4/vae',local_files_only=True,torch_dtype=torch.float32).cuda().eval();vae.requires_grad_(False);vae.enable_gradient_checkpointing()
 rgb=torch.load(W/'rgb_cache'/(rows[0]+'.pt'),map_location='cuda',weights_only=False);clean_rgb=rgb['clean'][None].float()/127.5-1;roi=rgb['mask'][None].float()*rgb['valid'][None].float()
 with torch.autocast('cuda',dtype=torch.float16):out=forward_text_free(m,adapter,target,source,geometry,sigma,ids,context_adapter=context)
 estimate=target.float()-sigma[:,None,None]*out.float();packed=Flux2KleinPipeline._unpack_latents_with_ids(estimate,d['target_ids']);mean=vae.bn.running_mean[None,:,None,None];std=(vae.bn.running_var[None,:,None,None]+vae.config.batch_norm_eps).sqrt();z=Flux2KleinPipeline._unpatchify_latents(packed*std+mean);decoded=vae.decode(z.float(),return_dict=False)[0]
 assert decoded.shape==clean_rgb.shape and torch.isfinite(decoded).all()
 pixel=((decoded-clean_rgb).abs()*roi).sum()/(roi.sum()*3).clamp_min(1)
 dx=(decoded[:,:,:,1:]-decoded[:,:,:,:-1])-(clean_rgb[:,:,:,1:]-clean_rgb[:,:,:,:-1]);dy=(decoded[:,:,1:,:]-decoded[:,:,:-1,:])-(clean_rgb[:,:,1:,:]-clean_rgb[:,:,:-1,:]);edge=(dx.abs()*roi[:,:,:,1:]).mean()+(dy.abs()*roi[:,:,1:,:]).mean()
 flow=(out.float()-expected.float()).square().mean();loss=flow+.1*pixel+.05*edge
 assert torch.isfinite(loss);loss.backward()
 grads=[p.grad for p in list(adapter.parameters())+list(context.parameters()) if p.grad is not None];assert grads and all(torch.isfinite(g).all() for g in grads);assert adapter.output.weight.grad.abs().sum()>0 and context.project.weight.grad.abs().sum()>0
 assert all(p.grad is None for p in m.parameters())
 peak=torch.cuda.max_memory_allocated()/2**30;assert peak<6.8
 result={'phase':'passed','optimizer_updates':0,'base_and_existing_lora_frozen':True,'source_conditioning_connected':True,'vae_activation_checkpointing':True,'decoded_image_shape':list(decoded.shape),'flow_loss':float(flow.detach()),'pixel_loss':float(pixel.detach()),'edge_loss':float(edge.detach()),'image_context_gradient_finite_nonzero':True,'adapter_gradients_finite_nonzero':True,'peak_allocated_gib':peak,'seconds':time.time()-start,'input_split':'train','conditioning':'512 learned image-derived context vectors; no tokenizer/Qwen/prompt cache','limitations':'One TRAIN case at sigma.25, no optimizer updates. Decoded RGB/edge objectives are paired-image supervision, not verified lane labels. Full future training memory/quality still requires a bounded pilot.'}
 (O/'decoded_loss_gate.json').write_text(json.dumps(result,indent=2));(O/'decoded_loss_gate_status.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
except Exception as e:
 (O/'decoded_loss_gate_status.json').write_text(json.dumps({'phase':'failed','error':repr(e),'optimizer_updates':0}));raise
