"""Official public TRAIN archive, bounded download/path checks; no model training."""
from pathlib import Path
import requests,json,time,hashlib,zipfile,shutil
from html.parser import HTMLParser
from urllib.parse import urlparse
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'ceymo_train_acquisition';O.mkdir(exist_ok=True);D=R/'work/lane_geometry/external_data/ceymo';D.mkdir(parents=True,exist_ok=True);file_id='1-TDEfGXtEQ4s037M_ynmV6aiOfNp2NZv';assert file_id in (P/'ceymo_sample_audit/README.md').read_text()
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
class Form(HTMLParser):
 def __init__(self):super().__init__();self.action=None;self.fields={}
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='form' and a.get('id')=='download-form':self.action=a.get('action')
  if tag=='input' and a.get('type')=='hidden' and a.get('name'):self.fields[a['name']]=a.get('value','')
try:
 file=D/'official_train.zip';status(phase='resolving',completed=0,total=1)
 if not file.exists():
  session=requests.Session();response=session.get('https://drive.google.com/uc',params=dict(export='download',id=file_id),stream=True,timeout=60);response.raise_for_status();iterator=response.iter_content(2**20);first=next(iterator,b'')
  if not first.startswith(b'PK'):
   text=(first+b''.join(iterator)).decode('utf-8','replace');response.close();form=Form();form.feed(text);assert form.action and urlparse(form.action).hostname=='drive.usercontent.google.com' and form.fields.get('id')==file_id,'Public endpoint did not provide expected download confirmation; no login bypass attempted.';response=session.get(form.action,params=form.fields,stream=True,timeout=60);response.raise_for_status();iterator=response.iter_content(2**20);first=next(iterator,b'')
  assert first.startswith(b'PK'),'Expected public ZIP, got nonarchive response';total=int(response.headers.get('Content-Length',0));assert total<2*1024**3;assert shutil.disk_usage(D).free>6*1024**3;done=0;h=hashlib.sha256();tmp=D/'official_train.part'
  with tmp.open('wb') as out:
   for block in (first,):out.write(block);done+=len(block);h.update(block)
   for block in iterator:
    if not block:continue
    done+=len(block);assert done<2*1024**3;out.write(block);h.update(block);status(phase='downloading',completed=done,total=total or done)
  if total:assert done==total
  response.close();assert zipfile.is_zipfile(tmp);tmp.rename(file)
 else:
  h=hashlib.sha256()
  with file.open('rb') as f:
   for block in iter(lambda:f.read(2**20),b''):h.update(block)
  done=file.stat().st_size
 z=zipfile.ZipFile(file);members=z.infolist();unpacked=sum(i.file_size for i in members);assert unpacked<8*1024**3 and shutil.disk_usage(D).free>unpacked+2*1024**3;dest=D/'official_train';dest.mkdir(exist_ok=True)
 for n,info in enumerate(members):
  target=(dest/info.filename).resolve();assert target.is_relative_to(dest.resolve()) and ((info.external_attr>>16)&0o170000)!=0o120000
  if not target.exists():z.extract(info,dest)
  status(phase='extracting',completed=n+1,total=len(members))
 summary=dict(phase='complete',official_repository='https://github.com/oshadajay/CeyMo',official_file_id=file_id,archive_sha256=h.hexdigest(),archive_bytes=done,uncompressed_bytes=unpacked,members=len(members),dataset_root=str(dest),external_split='train_only',original_paired_splits_unchanged=True,training_updates=0,warning='Audit annotation classes, image/label alignment and sample TEST disjointness before any pretraining.');(O/'summary.json').write_text(json.dumps(summary,indent=2));status(phase='complete',completed=1,total=1);print('Official TRAIN archive acquired, no training:',done,'bytes')
except Exception as e:status(phase='failed',error=repr(e));raise
