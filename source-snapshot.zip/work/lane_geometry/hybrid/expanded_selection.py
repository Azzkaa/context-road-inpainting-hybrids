"""Deterministic 1k TRAIN expansion; original splits and 128-case protocol untouched."""
from pathlib import Path
import json,random
R=Path(__file__).resolve().parents[3]
def selection():
 rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};ids=sorted(i for i,r in rows.items() if r['split']=='train');random.Random(20261122).shuffle(ids);val=json.loads((R/'outputs/lane_geometry/klein_hybrid/feature_study_protocol.json').read_text())['validation_ids'];return rows,ids[:1000],val
