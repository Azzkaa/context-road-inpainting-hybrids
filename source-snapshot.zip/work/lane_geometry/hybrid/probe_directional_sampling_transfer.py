"""External pretrained arrow/crossing component on paired development images; no GT accuracy claim."""
import argparse
a=argparse.ArgumentParser();a.add_argument('--arm',choices=['uniform','balanced'],required=True);args=a.parse_args()
from pathlib import Path
import json,time,torch,numpy as np
from PIL import Image
from ceymo_layout import DirectionalMarkingModel,COLORS,CLASSES
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/('directional_transfer_'+args.arm);O.mkdir(exist_ok=True);torch.set_num_threads(4);path=R/'work/snow_replacements820/cityscapes_model';m=DirectionalMarkingModel(path).cuda().eval();ck=torch.load(P/'ceymo_arrow_balancing'/args.arm/'pass_3.pt',map_location='cpu',weights_only=False);m.load_state_dict(ck['model']);cfg=json.loads((path/'preprocessor_config.json').read_text());mean=torch.tensor(cfg['image_mean'],device='cuda')[None,:,None,None];std=torch.tensor(cfg['image_std'],device='cuda')[None,:,None,None];ids=json.loads((P/'lane_generation_protocol.json').read_text())['validation_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};records=[];colors=np.array(COLORS,np.uint8);page='<meta charset="utf-8"><style>body{font:18px system-ui;background:#122033;color:white;margin:25px}a{color:#8df}img{width:48%}</style><h1>Directional component: paired transfer probe</h1><p>Left separate clean-side recognition probe / right snowy-input recognition probe. Colored regions are class predictions, NOT restored paint. Clean image is never supplied to the snowy prediction. CeyMo does not label ordinary solid/dashed lane dividers; this component targets symbols/crossing regions.</p><a href="../progress/">Live progress</a>'
try:
 for n,sid in enumerate(ids):
  r=rows[sid];assert r['split']=='validation';dst=O/sid;dst.mkdir(exist_ok=True)
  for kind in ['clean','snowy']:
   im=Image.open(r[kind]).convert('RGB');w,h=im.size;s=min(1024/w,1024/h);nw,nh=round(w*s),round(h*s);l,t=(1024-nw)//2,(1024-nh)//2;image=np.array(im.resize((nw,nh),Image.Resampling.LANCZOS));a=np.pad(image,((t,1024-nh-t),(l,1024-nw-l),(0,0)),mode='edge');x=torch.from_numpy(a.copy()).permute(2,0,1)[None].cuda().float()/255
   with torch.inference_mode():pred=m((x-mean)/std).argmax(1)[0,t:t+nh,l:l+nw].cpu().numpy().astype(np.uint8)
   overlay=image.copy();overlay[pred>0]=(.3*image[pred>0]+.7*colors[pred][pred>0]).astype(np.uint8);Image.fromarray(overlay).save(dst/(kind+'_overlay.png'));np.save(dst/(kind+'_labels.npy'),pred);records.append(dict(id=sid,kind=kind,predicted_class_pixels={CLASSES[i]:int((pred==i).sum()) for i in range(1,12)}))
  page+='<h2>'+sid+'</h2><img src="'+sid+'/clean_overlay.png"><img src="'+sid+'/snowy_overlay.png">';(O/'status.json').write_text(json.dumps(dict(phase='probing',completed=n+1,total=8,updated_at=time.time())))
 (O/'summary.json').write_text(json.dumps(dict(phase='complete',development_pairs=8,records=records,warning='No verified directional masks on these pairs; this is qualitative transfer, not accuracy. Snowy inference never uses clean reference. Original generator unchanged.'),indent=2));(O/'index.html').write_text(page);(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=8,total=8,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
