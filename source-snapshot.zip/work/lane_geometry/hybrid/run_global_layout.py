from pathlib import Path
import json,time,fcntl,subprocess,hashlib
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'global_layout_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py=R/'work/inpainting_compare/venv/bin/python'
def active(path,title,total,loss=False):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='Matched explicit-layout control vs global attention; supervise valid background as well as edit regions. Pseudo-label experiment, no generator integration.',total=total,result_path='global_layout_review/',show_loss=loss,next_text='Review16predicted layouts before using them to guide paint rendering.')))
def run(script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(py),str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 (O/'protocol.json').write_text(json.dumps(dict(parent_sha256=hashlib.sha256((P/'marking_layout/latest.pt').read_bytes()).hexdigest(),updates_per_arm=1000,lr=.0001,training_images=250,validation_images=8,change='Both arms add valid-background supervision .25valid+.75edit; global adds2attention blocks,256spatial tokens,width96,4heads,zero-output residual.',warning='Teacher pseudo-labels only; generator remains unchanged.'),indent=2))
 for arm in ['control','global']:active('global_layout_study/'+arm+'/status.json','Explicit layout training: '+arm,1000,True);run('train_global_layout.py','--arm',arm)
 active('global_layout_study/evaluation_status.json','Generating explicit-layout comparison',8)
 for arm in ['control','global']:run('evaluate_global_layout.py','--arm',arm)
 ids=json.loads((P/'lane_generation_protocol.json').read_text())['validation_ids'];G=P/'global_layout_review';G.mkdir(exist_ok=True);page='<meta charset="utf-8"><style>body{font:17px system-ui;background:#122033;color:white;margin:25px}a{color:#8df}img{width:100%}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}</style><h1>Explicit layout: corrected loss + global attention</h1><p>Predicted maps only, not restored paint or verified accuracy. Left clean reference / middle corrected-loss control / right global-attention layout.</p><p><a href="../progress/">Live progress</a> · <a href="changes.html">Short changes</a></p>'
 for sid in ids:page+='<h2>'+sid+'</h2><div class="grid">'+''.join('<img src="'+path+'">' for path in ['control/'+sid+'/clean_reference.png','control/'+sid+'/layout_overlay.png','global/'+sid+'/layout_overlay.png'])+'</div>'
 (G/'index.html').write_text(page);(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=16,total=16,updated_at=time.time())))
except Exception as e:(O/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
