"""Zero-initialized full-frame visual residual, no language or clean-image input."""
import torch
from torch import nn
from torch.nn import functional as F
from image_context import ImageContextAdapter
class SceneContextAdapter(ImageContextAdapter):
 def __init__(self):
  super().__init__();self.scene_encoder=nn.Sequential(nn.Conv2d(192,64,3,padding=1),nn.GroupNorm(8,64),nn.SiLU());self.scene_project=nn.Linear(64,7680);nn.init.zeros_(self.scene_project.weight);nn.init.zeros_(self.scene_project.bias);self.visual=None
 def forward(self,geometry):
  base=super().forward(geometry);assert self.visual is not None and self.visual.shape==(geometry.shape[0],192,64,64)
  x=F.adaptive_avg_pool2d(self.scene_encoder(self.visual),(16,32)).flatten(2).transpose(1,2)
  return base+self.scene_project(x)
