from pathlib import Path
import json,time,hashlib,numpy as np,torch
from PIL import Image
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'scene_context_cache';O.mkdir(exist_ok=True);C=R/'work/lane_geometry/scene_context_cache';C.mkdir(exist_ok=True);p=json.loads((P/'lane_generation_protocol.json').read_text());ids=[p['train_ids'][i%len(p['train_ids'])] for i in range(2400,2650)]+p['validation_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};MP=R/'work/snow_replacements820/cityscapes_model';torch.set_num_threads(4);m=SegformerForSemanticSegmentation.from_pretrained(MP,local_files_only=True).cuda().eval();m.requires_grad_(False);proc=SegformerImageProcessor.from_pretrained(MP,local_files_only=True)
for n,sid in enumerate(ids):
 r=rows[sid];assert r['split']==('train' if n<250 else 'validation');file=C/(sid+'.pt')
 if file.exists():
  d=torch.load(file,map_location='cpu',weights_only=False);assert d['source_sha256']==r['snowy_sha256'] and d['features'].shape==(1,192,64,64);continue
 assert hashlib.sha256(Path(r['snowy']).read_bytes()).hexdigest()==r['snowy_sha256'];im=Image.open(r['snowy']).convert('RGB');w,h=im.size;scale=min(1024/w,1024/h);nw,nh=round(w*scale),round(h*scale);a=np.array(im.resize((nw,nh),Image.Resampling.LANCZOS));left,top=(1024-nw)//2,(1024-nh)//2;canvas=Image.fromarray(np.pad(a,((top,1024-nh-top),(left,1024-nw-left),(0,0)),mode='edge'));grid=torch.zeros(1,192,64,64)
 for y in range(2):
  for x in range(2):
   tile=canvas.crop((x*512,y*512,(x+1)*512,(y+1)*512))
   with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):f=m.segformer(**proc(images=tile,return_tensors='pt').to('cuda'),output_hidden_states=True).hidden_states
   v=torch.cat([torch.nn.functional.adaptive_avg_pool2d(f[0].float(),(32,32)),torch.nn.functional.adaptive_avg_pool2d(f[2].float(),(32,32))],1).cpu();assert v.shape==(1,192,32,32);grid[:,:,y*32:(y+1)*32,x*32:(x+1)*32]=v
 rms=grid.square().mean((-2,-1),keepdim=True).sqrt().clamp_min(1e-4);grid=grid/rms;assert torch.isfinite(grid).all();torch.save(dict(id=sid,split=r['split'],source_sha256=r['snowy_sha256'],features=grid.half(),provenance='Frozen local Cityscapes SegFormer hidden stages0+2, four tiles of1024letterbox, snowyRGBonly; not sign recognition labels.'),file);(O/'status.json').write_text(json.dumps(dict(phase='caching',completed=n+1,total=len(ids),updated_at=time.time())))
(O/'status.json').write_text(json.dumps(dict(phase='complete',completed=len(ids),total=len(ids),updated_at=time.time())))
