"""Directional marking segmentation component; no language or source-road editing."""
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
from transformers import SegformerForSemanticSegmentation
CLASSES=['background','BL','CL','DM','JB','LA','PC','RA','SA','SL','SLA','SRA']
COLORS=[(0,0,0),(0,255,255),(0,128,255),(178,102,255),(255,255,51),(255,102,178),(255,255,0),(255,0,127),(255,0,255),(0,255,0),(255,128,0),(255,0,0)]
class DirectionalMarkingModel(nn.Module):
 def __init__(self,path):
  super().__init__();base=SegformerForSemanticSegmentation.from_pretrained(path,local_files_only=True);self.backbone=base.segformer;self.backbone.requires_grad_(False)
  for name,p in self.backbone.named_parameters():
   if name.startswith(('encoder.block.2.','encoder.block.3.','encoder.patch_embeddings.2.','encoder.patch_embeddings.3.','encoder.layer_norm.2.','encoder.layer_norm.3.')):p.requires_grad_(True)
  torch.manual_seed(20261124);self.project=nn.ModuleList([nn.Conv2d(c,32,1) for c in [32,64,160,256]]);self.decoder=nn.Sequential(nn.Conv2d(128,64,3,padding=1),nn.GroupNorm(8,64),nn.SiLU(),nn.Conv2d(64,len(CLASSES),1))
 def forward(self,x):
  features=self.backbone(pixel_values=x,output_hidden_states=True).hidden_states;size=features[0].shape[-2:];f=[F.interpolate(p(a),size=size,mode='bilinear',align_corners=False) for p,a in zip(self.project,features)];return F.interpolate(self.decoder(torch.cat(f,1)),size=x.shape[-2:],mode='bilinear',align_corners=False)
