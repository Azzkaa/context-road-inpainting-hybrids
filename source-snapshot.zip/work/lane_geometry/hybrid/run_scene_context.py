from pathlib import Path
import json,time,subprocess,fcntl,hashlib
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'scene_context_study';O.mkdir(exist_ok=True);lock=(O/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);H=R/'work/lane_geometry/hybrid';py='/path/to/user-home/anaconda3/envs/snow-edit/bin/python';protocol=json.loads((P/'scene_context_protocol.json').read_text())
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
def active(path,title,total,loss):
 (P/'progress/active_stage.json').write_text(json.dumps(dict(enabled=True,status_path=path,title=title,description='New full-scene visual context from four tiles; text-free, base frozen, no clean deployment inputs. See short changes list in results page.',total=total,result_path='scene_context_review/',show_loss=loss,next_text='Numerical/memory gate first, then matched250updates and eight scene comparisons.')))
def run(interpreter,script,*args):
 with (O/'sequence.log').open('a') as log:subprocess.run([str(interpreter),str(H/script),*args],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
try:
 assert json.loads((P/'scene_context_gate.json').read_text())['phase']=='passed'
 assert hashlib.sha256((P/'secondpass_study/control/latest.pt').read_bytes()).hexdigest()==protocol['continuation_sha256']
 active('scene_context_cache/status.json','Reading full-scene visual context',258,False);status(phase='caching');run(R/'work/inpainting_compare/venv/bin/python','cache_scene_context.py')
 # Structural/provenance audit before any optimizer update.
 import torch
 rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};train=[protocol['train_ids'][i%len(protocol['train_ids'])] for i in range(2400,2650)]
 for sid in train+protocol['validation_ids']:
  d=torch.load(R/'work/lane_geometry/scene_context_cache'/(sid+'.pt'),map_location='cpu',weights_only=False);assert d['features'].shape==(1,192,64,64) and torch.isfinite(d['features']).all();assert d['source_sha256']==rows[sid]['snowy_sha256'] and d['split']==('train' if sid in train else 'validation')
 (O/'cache_audit.json').write_text(json.dumps(dict(passed=True,train=250,validation=8,finite=True,source_hashes_matched=True,no_clean_conditioning=True)))
 active('scene_context_study/scene/status.json','Training full-scene context branch',250,True);status(phase='training',completed=0,total=250);run(py,'train_scene_context.py','--arm','scene')
 assert json.loads((O/'scene/smoke_check.json').read_text())['passed']
 active('scene_context_study/status.json','Generating full-scene lane comparisons',8,False)
 for i,sid in enumerate(protocol['validation_ids']):
  status(phase='generating',completed=i,total=8,id=sid)
  if not (P/'scene_context_review/scene'/sid/'road_only_output.png').exists():run(py,'evaluate_scene_context.py','--arm','scene','--index',str(i))
  assert (P/'scene_context_review/scene'/sid/'raw_null_text.png').exists()
 status(phase='scoring',completed=8,total=8);run(R/'work/inpainting_compare/venv/bin/python','score_scene_context.py');status(phase='complete',completed=8,total=8,result='/lane_geometry/klein_hybrid/scene_context_review/')
except Exception as e:status(phase='failed',error=repr(e));raise
