"""Conservative TRAIN-template cue filter; no training ground truth or road rendering."""
from pathlib import Path
import json,time,cv2,numpy as np
from PIL import Image
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';T=P/'train_sign_cue_audit';O=P/'filtered_sign_cues';O.mkdir(exist_ok=True);index=json.loads((T/'review_index.json').read_text());template_indices=[9,10,17,24];plausible=[3,4,9,10,14,16,17,19,20,24,28,29,30,34,35,36,37,43,44,45]
def normalized(path):
 a=(np.array(Image.open(path).convert('L'))>127).astype(np.uint8);ys,xs=np.where(a)
 if not len(xs):return np.zeros((64,64),np.uint8)
 a=a[ys.min():ys.max()+1,xs.min():xs.max()+1];h,w=a.shape;s=min(56/w,56/h);nw,nh=max(1,round(w*s)),max(1,round(h*s));b=cv2.resize(a,(nw,nh),interpolation=cv2.INTER_NEAREST);out=np.zeros((64,64),np.uint8);l,t=(64-nw)//2,(64-nh)//2;out[t:t+nh,l:l+nw]=b;return out
def similarity(a,b):
 best=0.
 for dy in [-2,0,2]:
  for dx in [-2,0,2]:
   moved=cv2.warpAffine(a,np.float32([[1,0,dx],[0,1,dy]]),(64,64),flags=cv2.INTER_NEAREST);best=max(best,float((moved&b).sum())/max(1,int((moved|b).sum())))
 return best
templates=[(r['direction'],normalized(T/r['id']/r['icon']),r['index']) for r in index if r['index'] in template_indices]
def classify(path,exclude=None):
 a=normalized(path);scores={d:max([similarity(a,b) for dd,b,k in templates if dd==d and k!=exclude] or [0.]) for d in ['left','right']};winner=max(scores,key=scores.get);margin=scores[winner]-scores['right' if winner=='left' else 'left'];return winner if scores[winner]>=.55 and margin>=.08 else 'unknown',scores,margin
records=[]
for r in index:
 direction,scores,margin=classify(T/r['id']/r['icon'],exclude=r['index']);records.append(dict(**r,filtered_direction=direction,template_iou=scores,margin=margin,visual_review_draft='plausible_curved_turn_symbol' if r['index'] in plausible else 'reject_or_ambiguous',verified=False))
# Apply fixed TRAIN templates to the eight development scenes without using their icons as templates.
development=json.loads((P/'sign_arrow_probe_v2/summary.json').read_text());dev=[]
for rec in development['records']:
 ds=[]
 for sign in rec['signs']:
  for u in sign['candidates']:
   d,scores,margin=classify(P/'sign_arrow_probe_v2'/rec['id']/u['icon_file']);ds.append(dict(direction=d,scores=scores,panel=u['panel_file'],icon=u['icon_file']))
 dev.append(dict(id=rec['id'],candidates=ds))
summary=dict(phase='complete',template_train_indices=template_indices,threshold=.55,margin_threshold=.08,train_records=records,development_records=dev,warning='Template proposals and AI visual-review drafts are unverified, not ground truth. Leave-one-template-out scores on TRAIN are not independent accuracy. No lane association or paint generation.');(O/'summary.json').write_text(json.dumps(summary,indent=2));(O/'review_draft.json').write_text(json.dumps(dict(plausible_indices=plausible,reviewed_candidates=47,reviewer='AI visual inspection, draft only',verified=False),indent=2));page='<meta charset="utf-8"><style>body{font:18px system-ui;background:#122033;color:white;margin:30px}a{color:#8df}img{max-width:240px;max-height:180px;margin:10px}</style><h1>Conservative sign-symbol proposals</h1><p>Fixed templates from four TRAIN proposals, unverified. Unknown means abstention. No model training, clean-image inputs or road rendering. AI-reviewed drafts are not ground truth.</p><a href="../progress/">Live progress</a><h2>Development example</h2>'
for rec in dev:
 if not rec['candidates']:continue
 page+='<h3>'+rec['id']+'</h3>'
 for c in rec['candidates']:page+='<p>Filtered candidate: '+c['direction']+'</p><img src="../sign_arrow_probe_v2/'+rec['id']+'/'+c['panel']+'">'
page+='<h2>TRAIN proposals: leave-one-template-out filter</h2>'
for r in records:
 page+='<p>#'+str(r['index'])+' — '+r['direction']+' → '+r['filtered_direction']+'; AI draft: '+r['visual_review_draft']+'</p><img src="../train_sign_cue_audit/'+r['id']+'/'+r['panel']+'">'
(O/'index.html').write_text(page);print('retained',[(r['index'],r['filtered_direction']) for r in records if r['filtered_direction']!='unknown']);print('development',dev)
