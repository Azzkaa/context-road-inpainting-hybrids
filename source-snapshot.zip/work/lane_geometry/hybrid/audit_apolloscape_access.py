"""Read official metadata and HEAD sample access only; no dataset/weights download."""
from pathlib import Path
import requests,json,re,time,hashlib
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/apolloscape_access_audit';O.mkdir(exist_ok=True);base='https://raw.githubusercontent.com/ApolloScapeAuto/dataset-api/master/';records=[]
for name in ['lane_segmentation/README.md','lane_segmentation/helpers/laneMarkDetection.py','README.md','LICENSE']:
 url=base+name
 try:
  r=requests.get(url,timeout=30);record=dict(path=name,url=url,status=r.status_code)
  if r.status_code==200:
   (O/name.replace('/','_')).write_text(r.text);record['sha256']=hashlib.sha256(r.content).hexdigest()
   if name=='lane_segmentation/README.md':record['download_urls']=re.findall(r'https?://[^\s\)\]\>"]+',r.text)
   if name.endswith('laneMarkDetection.py'):record['arrow_definitions']=[x.strip() for x in r.text.splitlines() if 'arrow' in x.lower() or 'crosswalk' in x.lower()]
  records.append(record)
 except Exception as e:records.append(dict(path=name,error=repr(e)))
# Probe only official linked lane sample URLs; no guessed mirror or login bypass.
probes=[]
for r in records:
 for url in r.get('download_urls',[]):
  if 'lane_marking_examples' not in url:continue
  try:
   x=requests.head(url,allow_redirects=True,timeout=30);probes.append(dict(url=url,status=x.status_code,bytes=x.headers.get('Content-Length'),content_type=x.headers.get('Content-Type')))
  except Exception as e:probes.append(dict(url=url,error=repr(e)))
(O/'summary.json').write_text(json.dumps(dict(phase='complete',records=records,sample_access=probes,updated_at=time.time(),scope='Official metadata/access audit only. No data/weights downloaded or new training. License and actual label/sample provenance require review before use.'),indent=2));print(json.dumps(dict(sample_access=probes,arrow_definitions=[r.get('arrow_definitions') for r in records if 'arrow_definitions' in r]),indent=2))
