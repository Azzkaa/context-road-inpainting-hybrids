from pathlib import Path
import json,hashlib,random
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'ceymo_arrow_balancing';O.mkdir(exist_ok=True);p=json.loads((P/'ceymo_directional_training/protocol.json').read_text());p.update(parent_checkpoint_sha256=hashlib.sha256((P/'ceymo_directional_training/latest.pt').read_bytes()).hexdigest(),parent_step=5613,additional_passes=3,additional_updates=3*len(p['external_train']),head_lr=.0001,encoder_lr=.000005,turn_classes=['LA','RA','SLA','SRA'],sampler_comparison='Uniform vs halfturn-classbalanced/halfuniform. Same model/optimizercheckpoint, lowerLRboth,5613updates/arm.',primary_diagnostic='ExternalVALturn-arrowmeanpixelIoU, secondaryallforegroundIoU; no automaticKleinintegration.')
preview=[r['id'] for r in p['external_validation'][:8]]
for cls in p['turn_classes']:
 for r in [r for r in p['external_validation'] if r['class_instances'].get(cls,0)>0][:2]:
  if r['id'] not in preview:preview.append(r['id'])
p['preview_ids']=preview;f=O/'protocol.json'
if f.exists():assert json.loads(f.read_text())==p
else:f.write_text(json.dumps(p,indent=2))
print('Prepared matched3passarms,',len(preview),'fixed/arrow-focusedpreviews.')
