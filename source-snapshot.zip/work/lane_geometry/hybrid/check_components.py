from pathlib import Path
import json,sys
import numpy as np,torch
sys.path.insert(0,str(Path(__file__).parent))
from road_only import compose_road
from spatial_adapter import SpatialGeometryAdapter
O=Path(__file__).resolve().parents[3]/'outputs/lane_geometry/klein_hybrid'
torch.set_num_threads(2);torch.manual_seed(42);rng=np.random.default_rng(42)
x=rng.integers(0,256,(57,91,3),dtype=np.uint8);y=rng.integers(0,256,(24,32,3),dtype=np.uint8);road=np.zeros((57,91),bool);road[20:,5:86]=True;protect=np.zeros_like(road);protect[25:40,40:50]=True
out,allowed=compose_road(x,y,road,protect,alpha=rng.random((57,91)));assert np.array_equal(out[~allowed],x[~allowed]);assert np.array_equal(out[protect],x[protect]);empty,_=compose_road(x,y,road&False,protect);assert np.array_equal(empty,x)
m=SpatialGeometryAdapter();g=torch.zeros(1,7,64,64);g[:,0,20:,10:54]=1;g[:,3,24:60,30]=1
source=torch.randn(1,1024,128);delta=m(g);assert delta.shape==source.shape and torch.equal(source+delta,source)
loss=(source+delta).square().mean();loss.backward();assert all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters());assert m.output.weight.grad.abs().sum()>0
# Nonzero weights only in this disposable fixture, not learned/checkpointed as a real adapter.
with torch.no_grad():m.output.weight.fill_(.01)
changed=m(g);blank=g.clone();blank[:,3]=0;assert (changed-m(blank)).abs().max()>0
z=m(torch.zeros_like(g));assert torch.count_nonzero(z)==0
protected=g.clone();protected[:,1]=1;assert torch.count_nonzero(m(protected))==0
save=O/'prototype_adapter_fixture.pt';torch.save(m.state_dict(),save);m2=SpatialGeometryAdapter();m2.load_state_dict(torch.load(save,map_location='cpu',weights_only=True));assert torch.equal(m(g),m2(g));save.unlink()
r={'phase':'components_checked_cpu','compositor':'native original exact outside permitted mask; protected region exact; empty mask identity; generated image resampled only','adapter_zero_init_exact':True,'adapter_output_shape':list(delta.shape),'finite_nonzero_output_projection_gradient':True,'geometry_sensitivity_after_fixture_nonzero_projection':True,'empty_or_fully_protected_roi_zero_residual':True,'checkpoint_reload_exact':True,'adapter_parameters':sum(p.numel() for p in m.parameters()),'limitations':['Not integrated into full Klein yet','No training performed','Predicted road/object masks not semantically validated','Prototype source-token conditioning; not proven lane improvement','Full4B GPU memory and coordinate transforms still pending']}
(O/'component_checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
