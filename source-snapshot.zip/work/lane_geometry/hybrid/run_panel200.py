from pathlib import Path
import json,time,subprocess,fcntl
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/image_pilot200_review';protocol=json.loads((O.parent/'image_pilot200_protocol.json').read_text());lock=(O/'panel.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def status(**d):(O/'panel_status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
try:
 for i,sid in enumerate(protocol['validation_ids']):
  if (O/sid/'instructed_parent.png').exists():continue
  status(phase='evaluating',completed_pairs=i,total_pairs=4,current_id=sid,current_stage='text-free200 + instructed parent; source-only generation')
  with (O/'panel.log').open('a') as log:subprocess.run(['/path/to/user-home/anaconda3/envs/snow-edit/bin/python',str(R/'work/lane_geometry/hybrid/evaluate_image_panel200.py'),'--index',str(i),'--compare-parent'],stdout=log,stderr=subprocess.STDOUT,check=True)
 status(phase='scoring',completed_pairs=4,total_pairs=4)
 with (O/'panel.log').open('a') as log:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(R/'work/lane_geometry/hybrid/score_panel200.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
 status(phase='complete',completed_pairs=4,total_pairs=4)
except Exception as e:status(phase='failed',error=repr(e));raise
