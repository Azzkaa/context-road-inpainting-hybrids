from directional_instances import *
import hashlib,collections,time
O=P/'predicted_shape_component_training_audit';C=R/'work/lane_geometry/predicted_shape_component_training_cache';rows=json.loads((P/'ceymo_pretraining/protocol.json').read_text())['external_train'];sha=hashlib.sha256((P/'directional_instance_class_study/control/latest.pt').read_bytes()).hexdigest();counts=collections.Counter();selected=collections.defaultdict(list);unknown=0;empty_unknown=0
for r in rows:
 c=torch.load(C/(r['id']+'.pt'),map_location='cpu',weights_only=False);assert c['split']=='train' and c['id']==r['id'] and c['source_checkpoint_sha256']==sha
 for key,path in [('source_image_sha256',r['image']),('source_annotation_sha256',r['polygon_annotation'])]:assert c[key]==hashlib.sha256(Path(path).read_bytes()).hexdigest()
 assert c['shapes'].dtype==torch.uint8 and list(c['shapes'].shape[1:])==[128,128] and len(c['author_labels'])==len(c['shapes'])==len(c['metadata'])
 for i,y in enumerate(c['author_labels'].tolist()):
  assert y in range(-1,11)
  if y<0:unknown+=1;empty_unknown+=int(c['shapes'][i].sum()==0);continue
  assert c['shapes'][i].sum()>0
  assert c['metadata'][i]['matched_iou']>=.5;name=CLASSES[y+1];counts[name]+=1
  if len(selected[name])<6:
   f='audit_'+name+'_'+r['id']+'_'+str(i)+'.png';Image.fromarray(c['shapes'][i].numpy()).save(O/f);selected[name].append(dict(file=f,id=r['id'],label=name,iou=c['metadata'][i]['matched_iou']))
report=dict(phase='passed',images=len(rows),matched_instances=sum(counts.values()),matched_classes=dict(counts),unknown_ignored=unknown,empty_unknown_ignored=empty_unknown,source_checkpoint_sha256=sha,hash_split_shape_label_checks=True,selected=dict(selected),warning='IoU matched author labels, not independent manual proposal verification. Sparse LA32; unknown815 excluded from loss.');(O/'cache_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='selected'}))
out=Image.new('RGB',(6*140,5*165),'#142033');from PIL import ImageDraw
d=ImageDraw.Draw(out)
for j,name in enumerate(['LA','RA','SA','SLA','SRA']):
 for k,r in enumerate(selected[name]):out.paste(Image.open(O/r['file']).convert('RGB'),(k*140,j*165+25));d.text((k*140,j*165),name+' '+r['id']+' %.2f'%r['iou'],fill='white')
out.save(O/'class_diverse_audit.jpg')
