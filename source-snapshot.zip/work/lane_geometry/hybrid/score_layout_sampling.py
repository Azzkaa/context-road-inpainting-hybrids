"""Clean-teacher agreement on development VAL; NOT verified marking accuracy."""
from pathlib import Path
import json,time,fcntl,torch,numpy as np
from PIL import Image
from transformers import AutoImageProcessor,Mask2FormerForUniversalSegmentation
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'layout_sampling_study';lock=(O/'run.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX);assert json.loads((O/'status.json').read_text())['phase']=='complete';ids=json.loads((P/'lane_generation_protocol.json').read_text())['validation_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};M=R/'work/lane_geometry/models/mask2former_mapillary';C=P/'layout_sampling_review/evaluation_teacher';C.mkdir(parents=True,exist_ok=True);torch.set_num_threads(4)
def status(**d):(O/'agreement_status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 status(phase='loading',completed=0,total=8);processor=AutoImageProcessor.from_pretrained(M,local_files_only=True);model=Mask2FormerForUniversalSegmentation.from_pretrained(M,local_files_only=True,torch_dtype=torch.float16).cuda().eval();model.requires_grad_(False);records=[]
 for n,sid in enumerate(ids):
  r=rows[sid];assert r['split']=='validation';im=Image.open(r['clean']).convert('RGB');w,h=im.size;scale=min(512/w,512/h);nw,nh=round(w*scale),round(h*scale);left,top=(512-nw)//2,(512-nh)//2;a=np.array(im.resize((nw,nh),Image.Resampling.LANCZOS));canvas=Image.fromarray(np.pad(a,((top,512-nh-top),(left,512-nw-left),(0,0)),mode='edge'));valid=torch.zeros(1,1,512,512);valid[:,:,top:top+nh,left:left+nw]=1;valid=torch.nn.functional.avg_pool2d(valid,4,4)[0,0].numpy()>.99;inputs=processor(images=canvas,return_tensors='pt',size=dict(shortest_edge=512,longest_edge=768)).to('cuda');inputs['pixel_values']=inputs['pixel_values'].half()
  with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):out=model(**inputs);labels=processor.post_process_semantic_segmentation(out,target_sizes=[(512,512)])[0].cpu();teacher=torch.nn.functional.avg_pool2d(torch.stack([labels==24,labels==23]).float()[None],4,4)[0].numpy()
  np.save(C/(sid+'.npy'),teacher)
  for arm in ['uniform','balanced']:
   pred=np.load(P/'layout_sampling_review'/arm/sid/'probabilities.npy');assert pred.shape==teacher.shape==(2,128,128)
   for c,name in enumerate(['general_marking','crosswalk']):
    aa=pred[c]>.25;bb=teacher[c]>.25;tp=int((aa&bb&valid).sum());fp=int((aa&~bb&valid).sum());fn=int((~aa&bb&valid).sum());records.append(dict(id=sid,arm=arm,marking_class=name,tp=tp,fp=fp,fn=fn))
  status(phase='scoring',completed=n+1,total=8)
 means={}
 for arm in ['uniform','balanced']:
  means[arm]={}
  for name in ['general_marking','crosswalk']:
   r=[x for x in records if x['arm']==arm and x['marking_class']==name];tp=sum(x['tp'] for x in r);fp=sum(x['fp'] for x in r);fn=sum(x['fn'] for x in r);means[arm][name]=dict(pseudo_label_f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None,pseudo_label_iou=tp/(tp+fp+fn) if tp+fp+fn else None,tp=tp,fp=fp,fn=fn)
 result=dict(phase='complete',validation_images=8,probability_threshold=.25,mean=means,records=records,warning='Agreement with frozen clean-image teacher pseudo-labels ONLY. Not verified lane accuracy, not independent final TEST. Teacher can be wrong; source-only student never receives clean images or these evaluation references.');(O/'teacher_agreement.json').write_text(json.dumps(result,indent=2));status(phase='complete',completed=8,total=8)
 G=P/'layout_sampling_review';q=G/'index.html';page=q.read_text();table='<h2>Clean-teacher agreement diagnostic</h2><p>Unverified pseudo-label agreement, NOT true accuracy. Fixed probability threshold0.25, eight development scenes.</p><table><tr><th>Arm</th><th>Class</th><th>Pseudo-label F1</th><th>Pseudo-label IoU</th></tr>'
 for arm in means:
  for name,r in means[arm].items():table+='<tr><td>'+arm+'</td><td>'+name+'</td><td>'+str(r['pseudo_label_f1'])+'</td><td>'+str(r['pseudo_label_iou'])+'</td></tr>'
 q.write_text(page+table+'</table>');print(json.dumps(means))
except Exception as e:status(phase='failed',error=repr(e));raise
