"""Source-only sign/icon evidence probe. No prompts, OCR, clean inputs or road painting."""
from pathlib import Path
import json,time,torch,numpy as np,cv2
from PIL import Image
from transformers import AutoImageProcessor,Mask2FormerForUniversalSegmentation
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'sign_arrow_probe';O.mkdir(exist_ok=True);M=R/'work/lane_geometry/models/mask2former_mapillary';torch.set_num_threads(4);ids=json.loads((P/'lane_generation_protocol.json').read_text())['validation_ids'];ids=[ids[3]]+[x for i,x in enumerate(ids) if i!=3];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};records=[]
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 status(phase='loading',completed=0,total=8);proc=AutoImageProcessor.from_pretrained(M,local_files_only=True);m=Mask2FormerForUniversalSegmentation.from_pretrained(M,local_files_only=True,torch_dtype=torch.float16).cuda().eval();m.requires_grad_(False);assert m.config.id2label[50]=='Traffic Sign (Front)'
 for n,sid in enumerate(ids):
  r=rows[sid];assert r['split']=='validation';im=Image.open(r['snowy']).convert('RGB');W,H=im.size;scale=min(1.,1024/max(W,H));sw,sh=round(W*scale),round(H*scale);inputs=proc(images=im,return_tensors='pt',size=dict(shortest_edge=768,longest_edge=1024)).to('cuda');inputs['pixel_values']=inputs['pixel_values'].half()
  with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):out=m(**inputs);labels=proc.post_process_semantic_segmentation(out,target_sizes=[(sh,sw)])[0].cpu().numpy()
  mask=(labels==50).astype(np.uint8);count,cc,stats,_=cv2.connectedComponentsWithStats(mask,8);dst=O/sid;dst.mkdir(exist_ok=True);source=np.array(im);detections=[]
  for idx,(x,y,w,h,area) in enumerate(stats[1:],1):
   if area<8 or w<4 or h<4:continue
   l,t,rr,b=max(0,int(x/scale)),max(0,int(y/scale)),min(W,int((x+w)/scale)+1),min(H,int((y+h)/scale)+1);crop=source[t:b,l:rr];ch,cw=crop.shape[:2]
   if ch<12 or cw<12:continue
   icon=crop[:max(1,round(ch*.68))];gray=cv2.cvtColor(icon,cv2.COLOR_RGB2GRAY);binary=(gray>180).astype(np.uint8);my,mx=max(1,int(binary.shape[0]*.08)),max(1,int(binary.shape[1]*.08));binary[:my]=0;binary[-my:]=0;binary[:,:mx]=0;binary[:,-mx:]=0;nc,comp,st,_=cv2.connectedComponentsWithStats(binary,8);direction='unknown';dx=None;chosen=np.zeros_like(binary)
   candidates=[]
   for j,(xx,yy,ww,hh,aa) in enumerate(st[1:],1):
    if aa>=max(12,.015*binary.size) and hh>=.35*binary.shape[0] and ww>=.2*binary.shape[1]:candidates.append((aa,j,xx,yy,ww,hh))
   if candidates:
    _,j,xx,yy,ww,hh=max(candidates);chosen=(comp==j).astype(np.uint8);ys,xs=np.where(chosen);upper=xs[ys<=yy+hh*.35];lower=xs[ys>=yy+hh*.7]
    if len(upper)>3 and len(lower)>3:
     dx=float((upper.mean()-lower.mean())/max(1,ww));dark_fraction=float((gray<110).mean());arrow_like=dark_fraction>.3 and (lower.max()-lower.min()+1)<.6*ww
     if arrow_like and abs(dx)>.12:direction='left' if dx<0 else 'right'
   k=len(detections);Image.fromarray(crop).save(dst/('sign_%02d.png'%k));Image.fromarray(chosen*255).save(dst/('icon_%02d.png'%k));detections.append(dict(crop='sign_%02d.png'%k,icon='icon_%02d.png'%k,native_bbox=[l,t,rr,b],candidate_direction=direction,icon_upper_minus_stem_x=dx,warning='Unverified geometric icon heuristic, not calibrated sign recognition. Unknown when checks fail.'))
  records.append(dict(id=sid,detected_signs=detections));status(phase='probing',completed=n+1,total=8)
 summary=dict(phase='complete',validation_images=8,records=records,peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,warning='Source-only sign detection/icon probe, not restored markings or verified directions. Does not determine painted-arrow position or association with a particular lane.');(O/'summary.json').write_text(json.dumps(summary,indent=2));page='<meta charset="utf-8"><style>body{font:18px system-ui;background:#122033;color:white;margin:30px}a{color:#8df}img{max-width:300px;max-height:220px;margin:10px}.card{display:inline-block;padding:10px;border:1px solid #789}</style><h1>Source-only sign/icon probe</h1><p>Native-resolution sign crops from snowy inputs. Direction candidates are unverified geometric heuristics; unknown is intentional. No clean input, text instruction, OCR or generated paint.</p><a href="../progress/">Live progress</a>'
 for rec in records:
  page+='<h2>'+rec['id']+'</h2>'
  for d in rec['detected_signs']:page+='<div class="card"><p>Candidate: '+d['candidate_direction']+'</p><img src="'+rec['id']+'/'+d['crop']+'"><img src="'+rec['id']+'/'+d['icon']+'"></div>'
 (O/'index.html').write_text(page);status(phase='complete',completed=8,total=8)
except Exception as e:status(phase='failed',error=repr(e));raise
