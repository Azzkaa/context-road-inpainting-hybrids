"""Validate explicit review exports; preserve splits and ignore unannotated pixels."""
from pathlib import Path
import json,argparse,hashlib,math,shutil
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';parser=argparse.ArgumentParser();parser.add_argument('export');parser.add_argument('--write',action='store_true');args=parser.parse_args();source=Path(args.export);data=json.loads(source.read_text());known={r['id']:r for r in json.loads((P/'lane_association_review/cases.json').read_text())};seen=set();accepted=[];ignored=[];classes={'road_background':0,'left_arrow':1,'right_arrow':2,'straight_arrow':3,'crosswalk':4,'other_marking':5}
assert data.get('schema_version')==1 and isinstance(data.get('cases'),list)
for case in data['cases']:
 sid=case['id'];assert sid in known and sid not in seen;seen.add(sid);ref=known[sid];assert case['split']==ref['split'] and case['clean_sha256']==ref['clean_sha256'] and case['snowy_sha256']==ref['snowy_sha256']
 if not case.get('reviewed') or case.get('visibility')!='visible' or not case.get('shapes'):
  ignored.append(dict(id=sid,reason='Unreviewed, unsure/no visible markings, or no geometry. Never treat as negative/background.'));continue
 shapes=[]
 for s in case['shapes']:
  kind=s['kind'];assert kind in classes or kind=='lane_boundary';points=s['points'];assert 2<=len(points)<=1000 and (kind=='lane_boundary' or len(points)>=3);assert all(len(p)==2 and all(isinstance(x,(int,float)) and math.isfinite(x) and 0<=x<=1 for x in p) for p in points);assert isinstance(s.get('lane_index',-1),int) and s.get('lane_index',-1)>=-1;shapes.append(s)
 accepted.append(dict(id=sid,split=ref['split'],source_sha256=ref['snowy_sha256'],clean_sha256=ref['clean_sha256'],shapes=shapes,relation=case.get('relation','uncertain'),provenance='Explicit review export; not automatic sign/teacher labels.',annotation_source=data.get('annotation_source')))
report=dict(phase='validated',accepted_cases=len(accepted),train_cases=sum(r['split']=='train' for r in accepted),validation_cases=sum(r['split']=='validation' for r in accepted),ignored=ignored,export_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),class_ids=classes,unannotated_pixel=255,warning='Validation remains evaluation-only; unannotated and ambiguous pixels ignored. Lane-boundary polylines are geometry only, not paint.')
if args.write:
 O=P/'reviewed_lane_associations'/report['export_sha256'][:12];O.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,O/'original_export.json')
 for split in ['train','validation']:
  target=O/split;target.mkdir(exist_ok=True);records=[]
  for rec in accepted:
   if rec['split']!=split:continue
   # Positive/background polygons only; unlabelled pixels stay255. Lane lines separate.
   import numpy as np
   labels=np.full((512,512),255,np.uint8);assigned=np.zeros((512,512),bool);ambiguous=np.zeros((512,512),bool)
   for s in rec['shapes']:
    if s['kind']=='lane_boundary':continue
    m=Image.new('L',(512,512));ImageDraw.Draw(m).polygon([(round(x*511),round(y*511)) for x,y in s['points']],fill=1);a=np.array(m).astype(bool);cls=classes[s['kind']];ambiguous|=a&assigned&(labels!=cls);labels[a]=cls;assigned|=a
   labels[ambiguous]=255;Image.fromarray(labels).save(target/(rec['id']+'.png'));records.append(dict(**rec,ambiguous_pixels=int(ambiguous.sum())))
  (target/'annotations.json').write_text(json.dumps(records,indent=2))
 (O/'manifest.json').write_text(json.dumps(report,indent=2));report['saved_to']=str(O)
print(json.dumps(report,indent=2))
