"""Download a public safetensors checkpoint and probe TRAIN images locally; no optimization."""
from pathlib import Path
import requests,json,time,hashlib,sys
R=Path(__file__).resolve().parents[3];P=R/'outputs/lane_geometry/klein_hybrid';O=P/'marking_teacher_probe';O.mkdir(exist_ok=True);M=R/'work/lane_geometry/models/mask2former_mapillary';M.mkdir(exist_ok=True);model_id='facebook/mask2former-swin-large-mapillary-vistas-semantic'
def status(**d):(O/'status.json').write_text(json.dumps(dict(updated_at=time.time(),**d),indent=2))
try:
 status(phase='resolving',completed=0,total=1);res=requests.get('https://huggingface.co/api/models/'+model_id,timeout=30);res.raise_for_status();meta=res.json();rev=meta['sha'];files={x['rfilename'] for x in meta['siblings']};assert 'model.safetensors' in files;hashes={}
 for name in ['config.json','preprocessor_config.json','model.safetensors','README.md']:
  if name not in files:continue
  dst=M/name
  if not dst.exists():
   response=requests.get('https://huggingface.co/'+model_id+'/resolve/'+rev+'/'+name,stream=True,timeout=60);response.raise_for_status();total=int(response.headers.get('Content-Length',0));done=0;tmp=M/(name+'.part')
   with tmp.open('wb') as out:
    for block in response.iter_content(2**20):
     if block:out.write(block);done+=len(block);status(phase='downloading',file=name,completed=done,total=total or done)
   if total:assert done==total
   tmp.rename(dst)
  hashes[name]=hashlib.sha256(dst.read_bytes()).hexdigest()
 (O/'provenance.json').write_text(json.dumps(dict(model_id=model_id,revision=rev,sha256=hashes,license_metadata=meta.get('cardData',{}).get('license'),model_card='https://huggingface.co/'+model_id,scope='Local noncommercial research probe; model-card license markedother. No external image uploads, no remote code.65classes includes general markings/crosswalk,NOTdirection-specific arrows.'),indent=2))
 import torch,numpy as np
 from PIL import Image
 from transformers import AutoImageProcessor,Mask2FormerForUniversalSegmentation
 torch.set_num_threads(4);status(phase='loading',completed=0,total=8);processor=AutoImageProcessor.from_pretrained(M,local_files_only=True);model=Mask2FormerForUniversalSegmentation.from_pretrained(M,local_files_only=True,torch_dtype=torch.float16).cuda().eval();model.requires_grad_(False);assert model.config.id2label[23]=='Lane Marking - Crosswalk' and model.config.id2label[24]=='Lane Marking - General'
 protocol=json.loads((P/'lane_generation_protocol.json').read_text());ids=protocol['train_ids'][:8];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};records=[]
 for n,sid in enumerate(ids):
  r=rows[sid];assert r['split']=='train';dst=O/sid;dst.mkdir(exist_ok=True)
  for kind in ['clean','snowy']:
   im=Image.open(r[kind]).convert('RGB');im.thumbnail((768,768));inputs=processor(images=im,return_tensors='pt',size=dict(shortest_edge=512,longest_edge=768)).to('cuda');inputs['pixel_values']=inputs['pixel_values'].half()
   with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):output=model(**inputs);labels=processor.post_process_semantic_segmentation(output,target_sizes=[im.size[::-1]])[0].cpu().numpy()
   a=np.array(im);mark=labels==24;cross=labels==23;overlay=a.copy();overlay[mark]=(.3*overlay[mark]+.7*np.array([255,200,0])).astype(np.uint8);overlay[cross]=(.3*overlay[cross]+.7*np.array([255,0,220])).astype(np.uint8);Image.fromarray(overlay).save(dst/(kind+'_overlay.png'));im.save(dst/(kind+'.png'));Image.fromarray(labels.astype(np.uint8)).save(dst/(kind+'_labels.png'));records.append(dict(id=sid,kind=kind,general_marking_pixels=int(mark.sum()),crosswalk_pixels=int(cross.sum())))
  status(phase='probing',completed=n+1,total=8)
 summary=dict(phase='complete',train_images=8,optimizer_updates=0,records=records,limitations='Predicted marking segmentation, not restored paint or verified GT; direction-specific arrow labels absent. Clean TRAIN probes test teacher suitability only, not deployment inputs. Inspect overlays before distillation.',peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30);(O/'summary.json').write_text(json.dumps(summary,indent=2))
 page='<meta charset="utf-8"><style>body{font:18px system-ui;background:#122033;color:white;margin:30px}a{color:#8df}img{width:48%}</style><h1>Pretrained marking teacher: TRAIN-only probe</h1><p>Not restoration results. Yellow=general marking prediction; pink=crosswalk. No direction-specific arrow classes; predictions are not verified labels.</p><p><a href="../progress/">Live progress</a></p>'
 for sid in ids:page+='<h2>'+sid+'</h2><img src="'+sid+'/clean_overlay.png"><img src="'+sid+'/snowy_overlay.png">'
 (O/'index.html').write_text(page);status(phase='complete',completed=8,total=8)
except Exception as e:status(phase='failed',error=repr(e));raise
