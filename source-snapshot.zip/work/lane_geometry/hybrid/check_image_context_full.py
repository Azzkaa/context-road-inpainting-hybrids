"""Full NF4 model structural gate: no optimizer, no parameter updates, no test inputs."""
from pathlib import Path
import sys,os,json,time
R=Path(__file__).resolve().parents[3];ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');W=R/'work/lane_geometry';O=R/'outputs/lane_geometry/klein_hybrid'
sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'));sys.path.insert(0,str(W/'klein_training_dependencies'));os.environ['HF_HUB_OFFLINE']='1'
import torch
from diffusers import Flux2Transformer2DModel,Flux2KleinPipeline,BitsAndBytesConfig
from peft import LoraConfig,set_peft_model_state_dict
from spatial_adapter import SpatialGeometryAdapter
from image_context import ImageContextAdapter
from klein_bridge import forward_text_free
start=time.time();torch.set_num_threads(4);torch.manual_seed(20261122)
(O/'image_context_full_gate_status.json').write_text(json.dumps({'phase':'loading','optimizer_updates':0}))
try:
 m=Flux2Transformer2DModel.from_pretrained(W/'klein_base/transformer',local_files_only=True,torch_dtype=torch.float16,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'})
 m.add_adapter(LoraConfig(r=4,lora_alpha=4,target_modules=['to_q','to_k','to_v','to_out.0']));ck=torch.load(R/'outputs/lane_geometry/klein_paired_training/latest.pt',map_location='cpu',weights_only=False);assert ck['step']==6783;set_peft_model_state_dict(m,ck['adapter']);del ck
 m.requires_grad_(False);m.enable_gradient_checkpointing();m.train()
 for mod in m.modules():
  if hasattr(mod,'compute_dtype'):mod.compute_dtype=torch.float16
 adapter=SpatialGeometryAdapter(input_channels=131).cuda();context=ImageContextAdapter().cuda()
 rows=sorted(r['id'] for r in json.loads((R/'work/road_restoration/manifest.json').read_text()) if r['split']=='train');d=torch.load(W/'klein_full_cache'/(rows[0]+'_512.pt'),map_location='cuda',weights_only=False);assert d['split']=='train'
 source=Flux2KleinPipeline._pack_latents(d['snowy']).half();target=Flux2KleinPipeline._pack_latents(d['clean']).half();ids=torch.cat([d['target_ids'],d['source_ids']],dim=1);sigma=torch.tensor([.5],device='cuda');target=(.5*target+.5*torch.randn_like(target)).requires_grad_(True)
 geometry=torch.zeros(1,131,64,64,device='cuda');geometry[:,0,20:]=1;geometry[:,3,25:60,30]=1
 with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16):
  y=forward_text_free(m,adapter,target,source,geometry,sigma,ids,context_adapter=context)
  blank=forward_text_free(m,adapter,target,source,geometry,sigma,ids,context_adapter=context)
  assert torch.equal(y,blank),'Repeated forward must be reproducible'
 with torch.autocast('cuda',dtype=torch.float16):out=forward_text_free(m,adapter,target,source,geometry,sigma,ids,context_adapter=context);loss=out.float().square().mean()
 assert torch.isfinite(loss);loss.backward()
 grads=[p.grad for p in list(adapter.parameters())+list(context.parameters()) if p.grad is not None];assert grads and all(torch.isfinite(g).all() for g in grads);assert adapter.output.weight.grad.abs().sum()>0 and context.project.weight.grad.abs().sum()>0
 assert all(p.grad is None for p in m.parameters())
 peak=torch.cuda.max_memory_allocated()/2**30;assert peak<6.8
 result={'phase':'passed','optimizer_updates':0,'base_and_existing_lora_frozen':True,'source_conditioning_connected':True,'repeated_forward_exact':True,'image_context_gradient_finite_nonzero':True,'adapter_gradients_finite_nonzero':True,'peak_allocated_gib':peak,'seconds':time.time()-start,'input_split':'train','conditioning':'512 learned image-derived context vectors; no tokenizer/Qwen/prompt cache','limitations':'Synthetic131channel fixture. Training-mode full4B connector forward/backward, frozen parent; no optimizer updates. No semantics or trained-quality verification.'}
 (O/'image_context_full_gate.json').write_text(json.dumps(result,indent=2));(O/'image_context_full_gate_status.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
except Exception as e:
 (O/'image_context_full_gate_status.json').write_text(json.dumps({'phase':'failed','error':repr(e),'optimizer_updates':0}));raise
