from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/klein_hybrid/roi_pilot';s=json.loads((O/'status.json').read_text());assert s['phase']=='complete';vs=s['validation'];fig,axes=plt.subplots(1,2,figsize=(12,4));r=s['records'];axes[0].plot([x['step'] for x in r],[x['loss'] for x in r]);axes[0].set(title='Training loss (not accuracy)',xlabel='Optimizer update',ylabel='Weighted BCE + soft Dice loss');axes[1].plot([x['step'] for x in vs],[x['mean_dice'] for x in vs],marker='o',label='Dice');axes[1].plot([x['step'] for x in vs],[x['mean_iou'] for x in vs],marker='o',label='IoU');axes[1].set(title='40 validation edit-mask overlaps',xlabel='Optimizer update',ylim=(0,1.02));axes[1].legend();fig.tight_layout();fig.savefig(O/'learning_curve.png',dpi=150);plt.close(fig)
text='<h2>Completed200-update ROI-head pilot</h2><table border="1" cellpadding="10"><tr><th>Update</th><th>Validation Dice</th><th>Validation IoU</th></tr>'+''.join(f'<tr><td>{v["step"]}</td><td>{v["mean_dice"]:.4f}</td><td>{v["mean_iou"]:.4f}</td></tr>' for v in vs)+'</table><p>Historical edit-mask overlap, not verified lane accuracy or universal road/hood segmentation.</p><img style="width:90%" src="learning_curve.png">'
p=O/'index.html';page=p.read_text();p.write_text(page.replace('<h1>Verified edit-mask training pilot</h1>','<h1>Verified edit-mask training pilot</h1>'+text))
print(vs)
