"""25-update exploratory image-context + spatial adapter pilot; immutable parent."""
from pathlib import Path
import sys,os,json,time,random
R=Path(__file__).resolve().parents[3];W=R/'work/lane_geometry';P=R/'outputs/lane_geometry/klein_hybrid';O=P/'image_pilot200';O.mkdir(exist_ok=True);ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'));sys.path.insert(0,str(W/'klein_training_dependencies'));os.environ['HF_HUB_OFFLINE']='1'
import torch
from diffusers import Flux2Transformer2DModel,Flux2KleinPipeline,BitsAndBytesConfig
from peft import LoraConfig,set_peft_model_state_dict
from spatial_adapter import SpatialGeometryAdapter
from image_context import ImageContextAdapter
from klein_bridge import forward_text_free
protocol=json.loads((P/'image_pilot200_protocol.json').read_text());assert json.loads((P/'image_context_full_gate.json').read_text())['phase']=='passed';torch.set_num_threads(4);torch.manual_seed(protocol['seed']);start=time.time()
def status(**d):(O/'status.json').write_text(json.dumps({'updated_at':time.time(),**d},indent=2))
try:
 status(phase='loading',step=0,total=200)
 m=Flux2Transformer2DModel.from_pretrained(W/'klein_base/transformer',local_files_only=True,torch_dtype=torch.float16,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'});m.add_adapter(LoraConfig(r=4,lora_alpha=4,target_modules=['to_q','to_k','to_v','to_out.0']));parent=torch.load(R/'outputs/lane_geometry/klein_paired_training/latest.pt',map_location='cpu',weights_only=False);assert parent['step']==6783;set_peft_model_state_dict(m,parent['adapter']);del parent;m.requires_grad_(False);m.enable_gradient_checkpointing();m.train()
 for mod in m.modules():
  if hasattr(mod,'compute_dtype'):mod.compute_dtype=torch.float16
 spatial=SpatialGeometryAdapter(input_channels=131).cuda();context=ImageContextAdapter().cuda();params=list(spatial.parameters())+list(context.parameters());opt=torch.optim.AdamW(params,lr=protocol['lr'],weight_decay=.01);scaler=torch.amp.GradScaler('cuda',init_scale=256);records=[];done=0
 continuing=not (O/'latest.pt').exists()
 checkpoint=R/'outputs/lane_geometry/klein_hybrid/image_pilot/latest.pt' if continuing else O/'latest.pt'
 if checkpoint.exists():
  ck=torch.load(checkpoint,map_location='cpu',weights_only=False);assert (ck['step']==25 and __import__('hashlib').sha256(checkpoint.read_bytes()).hexdigest()==protocol['continuation_sha256']) if continuing else ck['protocol']==protocol;spatial.load_state_dict(ck['spatial']);context.load_state_dict(ck['context']);opt.load_state_dict(ck['optimizer']);scaler.load_state_dict(ck['scaler']);done=ck['step'];records=ck['records'];torch.set_rng_state(ck['rng']);torch.cuda.set_rng_state_all(ck['cuda_rng'])
  for group in opt.param_groups:group['lr']=protocol['lr']
 def save(step):
  ck={'spatial':{k:v.detach().cpu() for k,v in spatial.state_dict().items()},'context':{k:v.detach().cpu() for k,v in context.state_dict().items()},'optimizer':opt.state_dict(),'scaler':scaler.state_dict(),'step':step,'records':records,'protocol':protocol,'rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all()};tmp=O/'latest.tmp';torch.save(ck,tmp);tmp.replace(O/'latest.pt')
 for i in range(done,200):
  sid=protocol['train_ids'][i%len(protocol['train_ids'])];d=torch.load(W/'klein_full_cache'/(sid+'_512.pt'),map_location='cuda',weights_only=False);g=torch.load(W/'hybrid_pilot_geometry'/(sid+'.pt'),map_location='cuda',weights_only=False);assert d['split']==g['split']=='train';source=Flux2KleinPipeline._pack_latents(d['snowy']).half();clean=d['clean'];noise=torch.randn_like(clean);sigma=torch.rand(1,device='cuda').clamp(.001,.999);target=Flux2KleinPipeline._pack_latents(noise-clean).float();x=Flux2KleinPipeline._pack_latents((1-sigma[:,None,None,None])*clean+sigma[:,None,None,None]*noise).half().requires_grad_(True);ids=torch.cat([d['target_ids'],d['source_ids']],dim=1);geometry=g['geometry'].float();weight=g['loss_weights'].flatten(2).transpose(1,2)
  for attempt in range(6):
   opt.zero_grad(set_to_none=True);x.grad=None
   with torch.autocast('cuda',dtype=torch.float16):pred=forward_text_free(m,spatial,x,source,geometry,sigma,ids,context_adapter=context)
   loss=((pred.float()-target).square()*weight).sum()/(weight.sum()*pred.shape[-1]).clamp_min(1);assert torch.isfinite(loss);scaler.scale(loss).backward();scaler.unscale_(opt)
   if all(p.grad is None or torch.isfinite(p.grad).all() for p in params):torch.nn.utils.clip_grad_norm_(params,1.);scaler.step(opt);scaler.update();break
   before=[p.detach().clone() for p in params];old=scaler.get_scale();scaler.step(opt);scaler.update();assert all(torch.equal(a,b) for a,b in zip(before,params));assert scaler.get_scale()<old
  else:raise RuntimeError('Persistent nonfinite gradients; no hidden skip')
  assert all(p.grad is None for p in m.parameters());records.append({'step':i+1,'id':sid,'loss':float(loss.detach()),'seconds':time.time()-start});status(phase='training',step=i+1,total=200,records=records);print(records[-1],flush=True)
  if i+1 in [2,10,25,27,50,100,150,200]:
   save(i+1)
   if i+1==27:
    ck=torch.load(O/'latest.pt',map_location='cpu',weights_only=False);assert all(torch.isfinite(v).all() for v in list(ck['spatial'].values())+list(ck['context'].values()));assert torch.cuda.max_memory_allocated()/2**30<6.8;(O/'smoke_check.json').write_text(json.dumps({'passed':True,'step':27,'finite_weights':True,'parent_frozen':True,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30}))
 status(phase='complete',step=200,total=200,records=records,seconds=time.time()-start,warning='Short development pilot, not final convergence or lane accuracy')
except Exception as e:status(phase='failed',error=repr(e));raise
