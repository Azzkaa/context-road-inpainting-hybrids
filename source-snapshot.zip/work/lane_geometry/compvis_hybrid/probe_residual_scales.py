from pathlib import Path
import json,time,torch
from hybrid import ContextInpainting
from source_data import R
O=R/'outputs/lane_geometry/compvis_hybrid';C=R/'work/lane_geometry/compvis_hybrid/cache';torch.set_num_threads(4);ids=json.loads((O/'pilot_protocol.json').read_text())['validation_ids'][:4];records=[]
def rms(t):return float(t.detach().float().square().mean().sqrt())
for variant in ['B','C']:
 m=ContextInpainting().cuda().eval();params=dict(m.named_parameters());ck=torch.load(O/'pilot100'/variant/'latest.pt',map_location='cpu',weights_only=False)
 with torch.no_grad():
  for n,v in ck['trainable'].items():params[n].copy_(v)
 for h in m.handles:h.remove()
 obs={}
 def input_hook(module,args,out):
  delta=m._condition[0].to(out.dtype);obs['spatial_base_rms']=rms(out);obs['spatial_delta_rms']=rms(delta);return out+delta
 def mid_hook(module,args,out):
  y=m.visual['context'](out,m._condition[1],m._condition[2]);obs['mid_base_rms']=rms(out);obs['mid_delta_rms']=rms(y-out);return y
 h1=m.ldm.model.diffusion_model.input_blocks[0].register_forward_hook(input_hook);h2=m.ldm.model.diffusion_model.middle_block.register_forward_hook(mid_hook)
 for j,sid in enumerate(ids):
  d=torch.load(C/(sid+'.pt'),map_location='cpu',weights_only=False);s={k:([v.cuda() for v in a] if isinstance(a,list) else a.cuda() if torch.is_tensor(a) else a) for k,a in d['source'].items() if k!='content_box'};cond=d['conditioning'].cuda();torch.manual_seed(20261126+j)
  with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16):pred=m(torch.randn(1,3,128,128,device='cuda'),torch.tensor([500],device='cuda'),cond,**s,variant=variant)
  r=dict(id=sid,variant=variant,timestep=500,**obs);r['spatial_relative_rms']=r['spatial_delta_rms']/r['spatial_base_rms'];r['context_relative_rms']=r['mid_delta_rms']/r['mid_base_rms'];records.append(r)
 h1.remove();h2.remove();del m,params,ck;torch.cuda.empty_cache()
(O/'pilot100/residual_scale_probe.json').write_text(json.dumps(dict(records=records,scope='Frozen trained100checkpoints; fixedsource-onlyVALfeatures and standardGaussianlatent at timestep500; no optimization or accuracy claim.'),indent=2));print(json.dumps(records))
