"""One source-only sign-proposal pass for the frozen64TRAIN/20VAL pilot IDs."""
from pathlib import Path
import json,time,hashlib,torch,numpy as np,cv2
from PIL import Image
from transformers import Mask2FormerForUniversalSegmentation,AutoImageProcessor
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/compvis_hybrid';D=O/'source_sign_proposals';D.mkdir(exist_ok=True);torch.set_num_threads(4);protocol=json.loads((O/'pilot_protocol.json').read_text());ids=protocol['train_ids']+protocol['validation_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};path=R/'work/lane_geometry/models/mask2former_mapillary';proc=AutoImageProcessor.from_pretrained(path,local_files_only=True,use_fast=False);m=Mask2FormerForUniversalSegmentation.from_pretrained(path,local_files_only=True,torch_dtype=torch.float16).cuda().eval().requires_grad_(False)
for n,sid in enumerate(ids):
 r=rows[sid];dst=D/(sid+'.json');assert r['split'] in ['train','validation'];assert hashlib.sha256(Path(r['snowy']).read_bytes()).hexdigest()==r['snowy_sha256']
 if dst.exists():assert json.loads(dst.read_text())['source_sha256']==r['snowy_sha256']
 else:
  im=Image.open(r['snowy']).convert('RGB');W,H=im.size;scale=min(1,1024/max(W,H));sw,sh=round(W*scale),round(H*scale);batch=proc(images=im,return_tensors='pt',size={'shortest_edge':768,'longest_edge':1024});batch={k:v.cuda() for k,v in batch.items()};batch['pixel_values']=batch['pixel_values'].half()
  with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16):out=m(**batch);labels=proc.post_process_semantic_segmentation(out,target_sizes=[(sh,sw)])[0].cpu().numpy()
  _,_,stats,_=cv2.connectedComponentsWithStats((labels==50).astype(np.uint8),8);boxes=[]
  for x,y,w,h,area in sorted(stats[1:],key=lambda a:-a[4]):
   if area<8 or w<4 or h<4:continue
   b=[max(0,int(x/scale)),max(0,int(y/scale)),min(W,int((x+w)/scale)+1),min(H,int((y+h)/scale)+1)]
   if min(b[2]-b[0],b[3]-b[1])<12:continue
   boxes.append(b)
   if len(boxes)==4:break
  dst.write_text(json.dumps(dict(id=sid,split=r['split'],source_sha256=r['snowy_sha256'],boxes=boxes,verified=False,proposal_availability=.5,warning='Frozen source traffic-sign-front regions, not verified sign meaning/lane association or calibrated confidence. No clean input.'),indent=2))
 d=json.loads((O/'status.json').read_text());d.update(phase='Caching source-only pilot sign crops',message='Fixed64TRAIN/20VALsources only; unverified proposals, no clean or lane labels used for detection.',completed=n+1,total=84,updated_at=time.time());(O/'status.json').write_text(json.dumps(d,indent=2))
(D/'summary.json').write_text(json.dumps(dict(phase='complete',sources=84,clean_input_used=False,train_images_with_signs=sum(bool(json.loads((D/(sid+'.json')).read_text())['boxes']) for sid in protocol['train_ids']),validation_images_with_signs=sum(bool(json.loads((D/(sid+'.json')).read_text())['boxes']) for sid in protocol['validation_ids'])),indent=2))
