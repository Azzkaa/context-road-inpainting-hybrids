from source_data import R
import subprocess,json,time,fcntl
O=R/'outputs/lane_geometry/compvis_hybrid';D=O/'lama_fallback/pilot100';D.mkdir(exist_ok=True,parents=True);lock=(D/'sequence.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
with (D/'sequence.log').open('a') as log:
 for v in ['A1','B','C']:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(R/'work/lane_geometry/compvis_hybrid/train_lama_pilot.py'),'--variant',v],stdout=log,stderr=subprocess.STDOUT,check=True)
a={v:json.loads((D/v/'status.json').read_text())['records'] for v in ['A1','B','C']};assert all([r['id'] for r in a[v]]==[r['id'] for r in a['A1']] for v in ['B','C']);(D/'matched_order_gate.json').write_text(json.dumps(dict(phase='passed',updates=100)))
ids=json.loads((O/'pilot_protocol.json').read_text())['validation_ids'][:4];page='<meta charset="utf-8"><h1>LaMa100-update matched pilot</h1><p>Snowy / A1 / B scene / C scene+sign. Not verified lane accuracy.</p>'
for sid in ids:page+='<h2>'+sid+'</h2><img width="24%" src="A1/'+sid+'/snowy.png">'+''.join('<img width="24%" src="'+v+'/'+sid+'/output.png">' for v in ['A1','B','C'])
(D/'index.html').write_text(page);s=json.loads((O/'status.json').read_text());s.update(phase='LaMa100-update outputs ready for review',output_url='../lama_fallback/pilot100/',output_message='Actual matched LaMa pilot images ready; quality and lane geometry not yet reviewed.',updated_at=time.time());(O/'status.json').write_text(json.dumps(s,indent=2))
