from pathlib import Path
import json,time,math,html
from PIL import Image,ImageDraw,ImageFont
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.section import WD_SECTION_START,WD_ORIENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/compvis_hybrid';O.mkdir(exist_ok=True)
plan='''# CompVis context inpainting hybrid experiment plan

Date: 26 November 2026. First backbone: CompVis inpainting_big. Fallback: Big LaMa. No text instruction at inference.

## Objective and deliverables
Produce a restored road image from a snowy image while using the whole scene and high-resolution sign crops as learned visual context. Copy pixels outside the permitted native-resolution road mask exactly from the input. Deliver real input / output / clean-reference comparisons, a live progress page, resumable checkpoints and a concise change log. A sign can constrain lane use but cannot uniquely specify hidden paint geometry. Do not promise perfect recovery.

## Why this is a new experiment
The earlier CompVis adapter used snowy latents and a mask, mostly frozen weights, and weighted noise loss. It did not explicitly route high-resolution sign crops into a scene-conditioned inpainting network. The Klein branch and external marking classifiers are preserved, but are not the backbone for this experiment. The best external marking classifier reached 49.5% object F1 on 228 clear-road development images; it still falsely labels large snow areas as crosswalks. Those predictions must not become ground truth or confident snow conditioning. Procedural snow previews are unvalidated stress tests and remain out of training until reviewed.

## Proposed CompVis structure
The local official checkpoint uses a VQ first stage with 3 latent channels and 4x spatial compression, not a 4-channel Stable Diffusion VAE. At a 512px square working canvas, target latents are 3 x 128 x 128. The denoiser input remains 7 channels: noisy target latent (3), masked snowy-image latent (3), and resized edit mask (1). Confirm preprocessing and mask polarity against the original inpainting script before running. The U-Net has four channel stages, 256 / 512 / 768 / 1024, with two residual blocks per configured stage and eight attention heads where attention is present. These stage counts are not a total layer count. The instantiated module ledger records 12 input blocks, 12 output blocks and385leaf modules; leaf modules are not a total CNN layer count. The U-Net has387245827parameters.

A frozen SegFormer B0 image encoder reads the complete snowy scene, including surroundings outside the edit mask. Its multiscale features feed a small spatial adapter, combined with source-predicted road/protection confidence. A zero-initialized projection injects that adapter after the U-Net input convolution. Its initial effect must be exactly zero.

The full-scene encoder also supplies 64 context tokens of width 192. Up to four source-detected sign crops supply 16 tokens each at higher spatial resolution; attach normalized box coordinates, source confidence and validity. Use cached source-only traffic-sign detections where possible. Sign proposals and directional icon heuristics are unverified cues, not approved lane associations. A missing sign must yield a finite, neutral path. Do not fabricate sign-to-lane labels.

A new narrow cross-attention residual at the U-Net bottleneck uses eight heads with attention width 128. Queries come from the denoiser features; keys/values come from scene/sign tokens. Attention softmax is over context tokens, not a final road-class softmax. Its output projection is initialized to zero so that the original denoiser is preserved exactly at initialization. Use SiLU in the new feature adapters. No text encoder, cached prompt or hardcoded language instruction is required.

Start with the VQ encoder/decoder, image encoder and pretrained U-Net frozen. Train rank 8 attention adapters and the new conditioning modules. Keep the same rank 8 adapters in matched controls. Initial adapter learning rate1e-4 is a pilot setting, not an optimal value. Only unfreeze a documented block or change width/rank after a controlled result identifies a reason. Do not join arbitrary halves of Klein and LDM. Klein is an immutable comparison; any later distillation is a separate ablation with predicted teacher outputs clearly labeled.

## Road mask contract
Training edit masks and verified lane files are supervision only. At deployment, derive the edit permit and protected foreground from the snowy image. The current predicted-mask implementation needs a semantic review for hood, sidewalks, vehicles and missed road edges. Exact copying outside a predicted mask does not prove the mask is correct. Feed full scene context into the model even though generation/compositing is road restricted. Save raw output separately and assert pixel equality outside the native-resolution permit on the delivered result.

## Controlled experiments and losses
A0 is the frozen official mask-conditioned checkpoint; A1 is the same backbone with rank 8 adapter training but no new visual context. B adds the spatial road adapter and full-scene context. C adds high-resolution sign tokens to B. Use identical source checkpoint, data order, training exposure, sampler and seeds for A1/B/C. Run one GPU job at a time. Compare frozen initialization first, then 2-step memory/checkpoint smoke tests, then 100-update pilots on a fixed64TRAIN subset. Review output images before proceeding to a bounded250-update comparison. Permit one evidence-led structural/objective correction, followed by a repeat with a matched control. Longer training follows only a demonstrated useful signal.

Use weighted noise MSE as the initial common objective: road weight 1.05, valid context 0.05 and verified lane corridor additional 4 within road; padding zero. Add a checkpointed decoded road reconstruction term and a road gradient-alignment term only in a separate common-objective ablation, with fixed candidate coefficients 0.1 and 0.05. Their magnitude and gradients must be inspected in the smoke test. Do not present gradient alignment as lane accuracy; it also responds to curbs and texture. Frozen VQ weights may pass gradients to adapters during decoded-loss training. Sign-to-lane association loss remains disabled until real reviewed training associations exist.

## Data and evaluation
Preserve the original2835pair manifest and split:2261TRAIN / 284VALIDATION / 290TEST. The already-exposed finalTEST is not for tuning, fallback selection or new training. Verify file hashes and group membership. Pick the pilot subset from existingTRAIN only and record it before optimization; include several sign-containing TRAIN cases without using validation information. Freeze a development panel from existingVALIDATION, with at least 20 cases for bounded comparisons. Existing clear targets are evaluation references, never inference inputs. Retain collection/group breakdowns and deterministic sampling seeds.

Measure road-only LPIPS (lower), PSNR/SSIM (higher), road gradient error (lower), outside-permit changed pixels (must be0), and visual failures for wrong/missing markings, shifted lanes, sign contradiction, hood/vehicle edits and missed road. Road masks define these image metrics, not semantic truth. Require at least 5% relative road LPIPS improvement over A1 on the fixed20case development panel, without meaningful PSNR/SSIM regression or outside-permit edits, before calling the context branch worth extending. This practical pilot rule is not proof of lane accuracy. Report paired per-image differences and uncertainty when sample size permits.

Verified UQTR701 lane files are allTRAIN and one geographic group. Use them for training/capacity checks, not independent validation F1. Teacher agreement is not true accuracy. The20case lane-association review workspace remains unapproved. Independent lane/arrow claims require genuinely reviewed held-out labels; continue image-quality and architecture work while that limitation remains. Do not invent zeros, ground truth or test scores to fill a table.

## LaMa fallback and stop rule
If the bounded CompVis A1/B/C pilots and one justified correction fail the extension rule or retain severe lane/road errors, save the negative result and switch autonomously to Big LaMa. Carry over the audited source-only context/sign encoders and road compositor. First reproduce frozen LaMa, then add a zero-initialized conditioned residual feature path at the Fourier-feature bottleneck. Generate a module/shape ledger and fresh finite-gradient, checkpoint and8GB memory gates before training. Compare with and without context on the same data using paired road reconstruction/gradient losses; LaMa is not diffusion. This is a new LaMa hybrid, not a claim that the old frozen LaMa plus LDM experiment trained LaMa. Stop any variant on numerical instability, outside-permit edits or a clear persistent regression; preserve checkpoints and continue useful diagnosis.

## Gates and next actions
G0: plan, diagram, checkpoint/config provenance, split hashes and trainable-scope ledger. G1: real model attachment, tensor/mask alignment, no-sign finite behavior and zero-initialization baseline equality. G2: real first-batch finite loss/gradients, frozen-parameter protection, memory allocation and reserved-memory headroom on the8GB GPU, and exact checkpoint/optimizer/RNG resume. G3: short paired pilot with actual output images. No long training before G0/G1/G2 pass. The diagram is proposed architecture until the attachment gate is recorded. Initial independent adapter tests do not establish full-LDM memory readiness.

Standalone spatial/context interfaces are implemented and CPU-tested; they are not attached to the U-Net yet. Next wire source-only masked-image conditioning and these interfaces into the real model, use the inspected module ledger, then reproduce a same-seed frozen baseline. Never call a plan or a stand-alone classifier result a final restored output.

## Execution and reporting
Use one existing-thread scheduled task every30minutes, replacing the old3hour cadence without a duplicate. At every check inspect existing processes/status first, advance independent useful work, update live progress and change log, and give a concise update containing completed work, current stage, evidence links, next action and blockers. Keep the page fresh during active runs and distinguish plans, gates, training and actual rendered outputs. A check is not a promise that training finishes within30minutes. Remove the automation after this agreed CompVis-first/LaMa-fallback experiment is evaluated or if the user stops it. No paid services or external image uploads.

## Sources
CompVis official implementation and inpainting checkpoint configuration: https://github.com/CompVis/latent-diffusion#inpainting
Latent diffusion paper: https://arxiv.org/abs/2112.10752
LaMa official implementation: https://github.com/advimman/lama
LaMa paper: https://arxiv.org/abs/2109.07161
Local configuration: work/inpainting_compare/repos/latent-diffusion/models/ldm/inpainting_big/config.yaml
Local prior adaptation: work/road_restoration/models.py
'''
(O/'EXPERIMENT_PLAN.md').write_text(plan)
# Visual code diagram with real local source thumbnails, no generated result placeholder.
W,H=2400,1530;im=Image.new('RGB',(W,H),'#101c2c');d=ImageDraw.Draw(im);font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def txt(x,y,s,size=30,color='#eaf1fa',strong=False):
 for j,line in enumerate(s.split('\n')):d.text((x,y+j*(size+9)),line,font=ImageFont.truetype(bold if strong else font,size),fill=color)
def box(rect,title,body='',fill='#20354b',accent='#77cbd6'):
 d.rounded_rectangle(rect,20,fill=fill,outline=accent,width=3);x,y,x2,y2=rect;txt(x+18,y+16,title,32,accent,True)
 if body:txt(x+18,y+65,body,27)
def arrow(points,color='#8babbf',width=5):
 d.line(points,fill=color,width=width,joint='curve');x,y=points[-1];px,py=points[-2];ang=math.atan2(y-py,x-px);d.polygon([(x,y),(x-17*math.cos(ang-.45),y-17*math.sin(ang-.45)),(x-17*math.cos(ang+.45),y-17*math.sin(ang+.45))],fill=color)
def thumb(image,rect):
 q=image.copy();q.thumbnail((rect[2]-rect[0],rect[3]-rect[1]));im.paste(q,(rect[0],rect[1]))
def maps(x,y):
 for k in range(4):
  d.rectangle((x+k*17,y-k*13,x+115+k*17,y+95-k*13),fill=['#176675','#25889a','#39a6b8','#7dcbd0'][k],outline='#c5f5f6',width=2)
  for a in range(4):d.line((x+k*17+a*29,y-k*13,x+k*17+a*29,y+95-k*13),fill='#b3e5e6')
row=next(r for r in json.loads((R/'work/road_restoration/manifest.json').read_text()) if r['id']=='1528_BOREAS_boreas-2021-06-17-17-52_1623967740454394');snow=Image.open(row['snowy']).convert('RGB');sw,sh=snow.size
# top

txt(55,35,'CompVis road inpainting with scene and sign context',52,strong=True)
txt(58,106,'PROPOSED STRUCTURE  |  Frozen backbone + learned adapters  |  No text prompt  |  LaMa fallback',28,'#a5bdcf')
box((50,210,490,510),'1  Snowy input',fill='#20354b');thumb(snow,(66,273,474,493))
box((565,210,1725,380),'2  Masked-image latent conditioning','3 noisy latent channels  +  3 masked-image latent channels  +  1 edit mask')
for k,(label,c,color) in enumerate([('Noise',3,'#a889cf'),('Masked source',3,'#3b8caa'),('Mask',1,'#e1af54')]):
 x=595+k*365
 for z in range(c):d.rounded_rectangle((x+z*25,322-z*7,x+140+z*25,353-z*7),5,fill=color,outline='#dce6f1')
 txt(x+185,320,label,22)
arrow([(490,350),(565,350)])
box((50,570,490,835),'3  Whole-scene encoder','Frozen SegFormer B0\nSees sky, signs, cars, curbs')
thumb(snow,(70,705,260,820));maps(295,750)
box((50,925,490,1230),'4  Sign crop encoder','Up to 4 source-only crops\nPosition + confidence + validity')
sign=snow.crop((int(.80*sw),int(.37*sh),int(.97*sw),int(.55*sh)));thumb(sign,(70,1068,260,1212));maps(295,1107)
arrow([(263,510),(263,570)]);arrow([(490,410),(525,410),(525,900),(270,900),(270,925)])
# U-Net visual stages
box((565,445,1725,1000),'5  CompVis U-Net denoiser','Pretrained weights frozen first; same rank 8 attention adapters in matched controls',fill='#1c2c43',accent='#bfa2e7')
xs=[620,870,1120,1370];chs=[256,512,768,1024];heights=[180,155,135,115]
for j,(x,c,h) in enumerate(zip(xs,chs,heights)):
 y=600+(180-h)//2;d.rounded_rectangle((x,y,x+145,y+h),12,fill='#5a4b78',outline='#ddc4fb',width=3);txt(x+22,y+20,str(c),31,'#fff',True);txt(x+20,y+h-47,'Down',25)
 if j<3:arrow([(x+145,y+h//2),(xs[j+1],600+(180-heights[j+1])//2+heights[j+1]//2)],'#c3a8e9')
 y2=838;d.rounded_rectangle((x,y2,x+145,y2+95),12,fill='#2b6572',outline='#90d8de',width=3);txt(x+23,y2+18,str(c),31);txt(x+30,y2+58,'Up',24)
 arrow([(x+73,y+h),(x+73,838)],'#537f9b',3)
 if j>0:arrow([(x,y2+48),(xs[j-1]+145,y2+48)],'#78cad3')
arrow([(1515,690),(1590,690),(1590,885),(1515,885)],'#dbb77d');txt(1545,742,'Mid',27,'#f1cd91')
txt(610,954,'Four channel stages; 12 input and 12 output blocks; 385 leaf modules in the real U-Net ledger',23,'#c4cfdf')
arrow([(1145,380),(1145,445)])
# new branches
box((600,1080,1115,1315),'6  Spatial road adapter','Scene maps + predicted permit\n+ protected foreground\nSiLU layers → ZERO projection',fill='#183d43',accent='#69d6c7')
box((1180,1080,1725,1315),'7  Scene and sign attention','64 scene + up to 64 sign tokens\n8 heads, width 128; softmax\nZERO residual into bottleneck',fill='#183d43',accent='#69d6c7')
arrow([(490,730),(550,730),(550,1175),(600,1175)],'#69d6c7');arrow([(490,1170),(565,1170),(565,1370),(1450,1370),(1450,1315)],'#69d6c7');arrow([(490,790),(530,790),(530,1397),(1520,1397),(1520,1315)],'#69d6c7')
arrow([(860,1080),(860,1040),(610,1040),(610,690)],'#69d6c7');arrow([(1450,1080),(1450,1030),(1660,1030),(1660,790),(1590,790)],'#69d6c7')
box((1810,455,2350,695),'8  VQ decoder','Frozen 3-channel VQ first stage\nDenoise iteratively → decode RGB\n4x latent compression',fill='#20354b')
arrow([(620,885),(550,885),(550,1015),(1770,1015),(1770,575),(1810,575)],'#8babbf')
box((1810,830,2350,1165),'9  Road-only output','Copy original outside permit\nProtect cars, hood and sidewalks\nAssert changed pixels outside = 0\n\nActual output appears after pilot\nNo generated result yet',fill='#3a3426',accent='#e7bc69')
arrow([(2080,695),(2080,830)])
arrow([(490,300),(525,300),(525,170),(2300,170),(2300,830)],'#e7bc69',4);txt(1800,180,'Original pixels bypass generation',24,'#e7bc69')
box((1810,1230,2350,1390),'Fallback after failed pilot','Big LaMa + audited context path\nFresh gates and matched control',fill='#2e2940',accent='#bfa2e7')
for x,c,label in [(65,'#20354b','Existing pretrained component'),(665,'#183d43','New trainable conditioning'),(1260,'#3a3426','Exact road-mask compositing')]:
 d.rounded_rectangle((x,1455,x+32,1487),5,fill=c,outline='#9eb9ce');txt(x+48,1456,label,25)
im.save(O/'architecture.png')
# Five-page Word plan with a full landscape diagram page.
doc=Document();sec=doc.sections[0];sec.page_width=Inches(8.27);sec.page_height=Inches(11.69);sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.7)
styles=doc.styles
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2']:
 styles[name].font.name='Calibri';styles[name].font.color.rgb=RGBColor(0,0,0)
styles['Normal'].font.size=Pt(11);styles['Normal'].paragraph_format.space_after=Pt(7);styles['Normal'].paragraph_format.line_spacing=1.08;styles['Title'].font.size=Pt(27);styles['Heading 1'].font.size=Pt(16);styles['Heading 2'].font.size=Pt(12)
def para(t,style=None):return doc.add_paragraph(t,style)
def heading(t):doc.add_heading(t,1)
def table(headers,rows):
 t=doc.add_table(rows=1,cols=len(headers));t.style='Light Shading Accent 1'
 for i,h in enumerate(headers):t.rows[0].cells[i].text=h
 for row in rows:
  for c,v in zip(t.add_row().cells,row):c.text=v
 for cell in t.rows[0].cells:
  tcPr=cell._tc.get_or_add_tcPr();shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E8EDF2');tcPr.append(shade)
  for r in cell.paragraphs[0].runs:r.font.bold=True;r.font.color.rgb=RGBColor(0,0,0)
 return t
para('CompVis context inpainting hybrid', 'Title');para('Experiment plan and LaMa fallback', 'Subtitle');para('26 November 2026   |   Working plan   |   Checks every 30 minutes')
heading('Decision and intended output');para('Start with the official CompVis inpainting checkpoint, add learned whole-scene and high-resolution sign conditioning, then try Big LaMa if a bounded CompVis pilot fails. The output must be a restored road image, with original pixels copied exactly outside the permitted road mask. No text instruction is required at inference.')
heading('Why the approach is changing');para('A plausible road surface has not translated into reliable lane markings. Earlier LDM adapters lacked an explicit sign-crop context path. The external marking component improved clear-road object F1 to 49.5%, but still mistakes snow for crosswalks. It will not be treated as ground truth or trusted snowy conditioning. Klein stays preserved as a comparison, rather than being mixed into the first backbone.')
table(['First experiment','If the bounded pilot fails'],[['CompVis inpainting_big plus scene and sign adapters','Big LaMa plus the same audited visual context'],['Frozen base first with small trainable adapters','Fresh LaMa shape gradient and memory checks'],['Matched control and actual restored-image previews','Matched control with paired road reconstruction losses']])
heading('What will be visible');para('The live page will show the current stage, completed steps, latest timestamp, readiness failures and real result comparisons when available. A concise change log will name each layer, weight, loss or data change and its reason. The scheduled check advances work every 30 minutes; it does not imply a result will finish every 30 minutes.')
para('A sign can constrain lane use, but cannot uniquely reveal the exact shape and position of fully hidden paint.')
para('Read-only source inspection: 387.25 million U-Net parameters, 12 input blocks, 12 output blocks and 385 leaf modules. Leaf modules are not a count of CNN layers. The full ledger is linked from the live page.')
# diagram landscape page
sec=doc.add_section(WD_SECTION_START.NEW_PAGE);sec.orientation=WD_ORIENT.LANDSCAPE;sec.page_width=Inches(11.69);sec.page_height=Inches(8.27);sec.top_margin=Inches(.38);sec.bottom_margin=Inches(.35);sec.left_margin=sec.right_margin=Inches(.55)
heading('Proposed visual structure');doc.add_picture(str(O/'architecture.png'),width=Inches(10.55));para('Conceptual architecture with a real snowy input crop. New branches are proposals until the full-model attachment gate passes. No trained output is pictured.').runs[0].font.size=Pt(9)
# portrait architecture page
sec=doc.add_section(WD_SECTION_START.NEW_PAGE);sec.orientation=WD_ORIENT.PORTRAIT;sec.page_width=Inches(8.27);sec.page_height=Inches(11.69);sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.7)
heading('Architecture and trainable scope');para('The local official CompVis configuration uses a three-channel VQ first stage with fourfold spatial compression. At a 512 pixel working canvas, a latent is 3 x 128 x 128. The seven U-Net input channels are noisy target latent 3, masked snowy latent 3, and edit mask 1. The official input mask is binary1 for editing, then normalized to minus1 and plus1 for conditioning. Confirm preprocessing before implementation; this is not a four-channel Stable Diffusion VAE.')
table(['Part','Initial design and status'],[['U-Net backbone','Existing channel stages 256 512 768 1024; two configured residual blocks per stage and eight attention heads where present. 385 leaf modules recorded in the instantiated U-Net ledger; not 385 CNN layers.'],['Scene path','Frozen SegFormer B0 reads the complete snowy image. Source-only features and permit/protection confidence feed a new spatial adapter.'],['Sign path','Up to four source-detected crops at higher resolution. Sixteen tokens each, plus box position confidence and validity. These are cues, not verified lane associations.'],['Conditioning','64 scene tokens plus up to 64 sign tokens of width 192. New bottleneck cross-attention uses eight heads and width 128.'],['New activations','SiLU in adapters; attention softmax across context tokens. Zero output projections preserve the original denoiser at initialization.'],['Initial training','Freeze VQ, image encoder and U-Net. Train rank 8 attention adapters plus new visual adapters. Same rank 8 adapters in matched controls.']])
heading('Mask and missing cue behavior');para('Read the whole scene while editing only the road. At deployment, road and protected foreground masks must come from the snowy input. Review hood, vehicle, sidewalk and missed-edge failures separately. Exact copying outside a predicted permit does not prove the permit is correct. A missing sign must produce finite neutral conditioning; no cached language prompt is allowed.')
para('Supervise sign to lane association only when real reviewed training labels exist. Until then, paired image supervision can train visual conditioning but cannot establish that the network understands a sign. Do not turn rejected snow-crosswalk predictions into labels.')
# eval page
sec=doc.add_section(WD_SECTION_START.NEW_PAGE)
heading('Controlled comparisons and evaluation');table(['Variant','Only intended addition'],[['A0','Frozen official mask-conditioned model'],['A1','Rank8 adapter training without new visual context'],['B','Spatial road adapter and whole-scene context'],['C','High-resolution sign tokens added to B']])
para('Match source checkpoint, data order, training exposure, sampler and seeds. Use one GPU job at a time. Start with zero-initialization equality and a two-step memory and resume test, then 100-update pilots on a recorded 64-image TRAIN subset. Review real outputs before a bounded 250-update comparison. Permit one evidence-led correction with a matched control before deciding whether to continue CompVis or switch to LaMa.')
heading('Losses and practical extension rule');para('Common initial loss: weighted noise MSE with road weight 1.05, valid context 0.05, verified lane corridor additional 4 within road and zero padding weight. Test decoded road reconstruction and gradient alignment separately, using fixed candidate coefficients 0.1 and 0.05 after a real gradient and memory check. These coefficients are pilot choices. Gradient alignment is not verified lane accuracy.')
para('On a fixed development panel of at least 20 VALIDATION cases, measure road LPIPS, PSNR, SSIM, road gradient error and outside-permit changed pixels. Require at least 5% relative road LPIPS improvement over A1 without meaningful PSNR or SSIM regression or outside-permit edits before extending the context variant. Inspect wrong and missing markings, shifted lanes, sign contradiction and foreground spill. This practical rule is not proof of lane accuracy.')
heading('Data and honest metric boundaries');para('Keep the original split: 2261 TRAIN, 284 VALIDATION and 290 TEST. The already-exposed finalTEST is not for tuning or fallback selection. Fix subset IDs and hashes before training; clean images are targets or evaluation references only. Report development results and group breakdowns honestly.')
para('The verified 701 UQTR lane files all belong to TRAIN and one geographic group. Use them for training and capacity checks, not independent validation F1. Held-out reviewed lane associations remain unavailable. Continue image and architecture work, but do not invent ground truth or report teacher agreement as lane accuracy.')
# gates fallback references page
sec=doc.add_section(WD_SECTION_START.NEW_PAGE)
heading('Readiness gates and fallback');table(['Gate','Evidence required before advancing'],[['G0','Plan diagram source hashes split ledger and proposed trainable scope'],['G1','Real model attachments tensor alignment mask semantics zero-init equality and finite no-sign path'],['G2','Real first-batch finite gradients frozen scope memory headroom on 8 GB and exact model optimizer RNG resume'],['G3','Short paired pilot with actual restored output and failure review']])
para('A stand-alone adapter test does not establish full-model readiness. No longer training starts before G0 G1 and G2 pass. Log each addition or parameter change with its reason, preserved baseline and measured effect.')
heading('When to switch to LaMa');para('If the bounded A1 B C comparison and one justified correction fail the extension rule or keep severe road and lane errors, preserve the negative results and switch to Big LaMa. Reproduce frozen LaMa, then test a zero-initialized context residual at its Fourier-feature bottleneck. Keep the same audited scene/sign encoder and road compositor. Build a fresh module ledger and run finite gradient checkpoint and8GB memory gates before training. LaMa uses paired reconstruction losses and is not diffusion.')
heading('Next implementation steps');para('Verify masked-image conditioning and signed mask polarity. Connect the CPU-tested spatial and scene/sign interfaces to the actual U-Net. Use the completed instantiated module ledger for attachment points. Reproduce a frozen same-seed baseline, then pass attachment and memory gates. Save all historical checkpoints and keep earlier Klein results separate. No paid services or external image uploads.')
heading('Schedule and continuity');para('Replace the existing research schedule with a 30-minute check in this chat. Each check inspects healthy jobs before launching work, updates progress and the short change log, and reports evidence, next action and blockers. Keep checkpoints resumable and avoid GPU overlap. Remove the schedule when this CompVis-first and LaMa-fallback experiment has been evaluated or when the user stops it.')
heading('Primary references');para('CompVis implementation and checkpoint: github.com/CompVis/latent-diffusion#inpainting\nLatent diffusion paper: arxiv.org/abs/2112.10752\nLaMa implementation: github.com/advimman/lama\nLaMa paper: arxiv.org/abs/2109.07161')
# Strip paragraph borders inherited from the bundled default template.
for el in list(doc.styles.element.iter(qn('w:pBdr')))+list(doc.element.iter(qn('w:pBdr'))):
 el.getparent().remove(el)
doc.core_properties.title='CompVis context inpainting hybrid experiment plan';doc.core_properties.author='';doc.save(O/'CompVis_Hybrid_Experiment_Plan.docx')
print('Created plan, architecture.png and Word document')
