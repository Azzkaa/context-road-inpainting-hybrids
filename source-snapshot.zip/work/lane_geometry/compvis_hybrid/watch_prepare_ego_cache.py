from pathlib import Path
import json,time,subprocess
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/compvis_hybrid';deadline=time.time()+7200
while time.time()<deadline:
 p=O/'source_ego_proposals/status.json'
 if p.exists():
  d=json.loads(p.read_text())
  if d['phase']=='failed':raise RuntimeError(str(d))
  s=json.loads((O/'status.json').read_text());s.update(phase='Caching source-only ego protection proposals',message='FrozenMapillaryEgoVehicle/CarMountmasks;no correctedtraining. Oldimagecache/checkpointsunchanged.',completed=d['completed'],total=d['total'],updated_at=time.time(),next_action='After source mask cache completes and GPUisfree, prepare isolated ego-protectedv3inputs; fresh loss/memorygate stillrequired.');(O/'status.json').write_text(json.dumps(s,indent=2))
  if d['phase']=='complete':
   active=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
   if not active:
    with (O/'ego_corrected_cache_sequence.log').open('a') as log:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(R/'work/lane_geometry/compvis_hybrid/prepare_ego_corrected_cache.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
    break
 time.sleep(3)
else:raise TimeoutError('Protection caching/GPUavailabilitynotready; no correctedcacheortrainingstarted')
