"""Frozen LaMa baseline and actual shape ledger. No optimization."""
from source_data import R,canvas
import sys,json,torch,numpy as np,hashlib,time
from PIL import Image
sys.path.insert(0,str(R/'work/road_restoration'))
from models import load_lama
O=R/'outputs/lane_geometry/compvis_hybrid';D=O/'lama_fallback';D.mkdir(exist_ok=True);torch.set_num_threads(4);m=load_lama().cuda();ledger=[]
def shape(x):
 if torch.is_tensor(x):return list(x.shape)
 if isinstance(x,(tuple,list)):return [shape(y) for y in x]
 return str(type(x))
handles=[mod.register_forward_hook(lambda mod,args,out,name=name:ledger.append(dict(name=name,type=type(mod).__name__,input=shape(args),output=shape(out)))) for name,mod in m.named_modules() if name and not list(mod.children())]
p=json.loads((O/'pilot_protocol.json').read_text());rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};page='<meta charset="utf-8"><h1>Frozen Big LaMa fallback baseline</h1><p>No hybrid training yet. Snowy / restored road / clean reference. Predictions are not verified lane geometry.</p>'
for sid in p['validation_ids'][:4]:
 row=rows[sid];ck=torch.load(R/'work/lane_geometry/compvis_hybrid/cache_ego_v3'/(sid+'.pt'),weights_only=False);assert ck['supervision'] is None;src=Image.open(row['snowy']).convert('RGB');a=canvas(src)[0];x=torch.from_numpy(a.copy()).permute(2,0,1)[None].cuda().float()/255;mask=ck['permit_working'].cuda().float();torch.cuda.reset_peak_memory_stats()
 with torch.no_grad():rgb=m(torch.cat([x*(1-mask),mask],1));assert torch.isfinite(rgb).all()
 l,t,w,h=ck['source']['content_box'];raw=(rgb[0].clamp(0,1)*255).permute(1,2,0).cpu().numpy().round().astype(np.uint8);gen=np.array(Image.fromarray(raw[t:t+h,l:l+w]).resize(src.size,Image.Resampling.LANCZOS));allow=np.array(Image.fromarray((ck['permit_working'][0,0,t:t+h,l:l+w].numpy()*255).astype(np.uint8)).resize(src.size,Image.Resampling.NEAREST))>127;out=np.array(src).copy();out[allow]=gen[allow];assert np.array_equal(out[~allow],np.array(src)[~allow]);dest=D/sid;dest.mkdir(exist_ok=True);src.save(dest/'snowy.png');Image.fromarray(out).save(dest/'output.png');Image.open(row['clean']).save(dest/'clean_reference.png');page+='<h2>'+sid+'</h2>'+''.join('<img width="32%" src="'+sid+'/'+f+'.png">' for f in ['snowy','output','clean_reference']);(D/'index.html').write_text(page)
 if handles:
  for handle in handles:handle.remove()
  handles=[]
  (D/'module_shape_ledger.json').write_text(json.dumps(ledger,indent=2))
report=dict(phase='frozen_baseline_complete',parameters=sum(p.numel() for p in m.parameters()),checkpoint_sha256=hashlib.sha256((R/'work/inpainting_compare/models/big-lama/models/best.ckpt').read_bytes()).hexdigest(),peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,outside_permit_changed_pixels=0,training_updates=0);(D/'status.json').write_text(json.dumps(report,indent=2));print(report)
