"""Common decoded-road objective: TRAIN references only, no inference target."""
import torch
from torch.utils.checkpoint import checkpoint

def corrected_loss(model,noisy,t,pred,noise,weight,road,target_rgb):
 mse=((pred.float()-noise.float()).square()*weight).sum()/(weight.sum()*3).clamp_min(1)
 # Match the official quantizing VQ decode; preserve its straight-through gradients.
 z=model.ldm.predict_start_from_noise(noisy,t,pred).float()/model.ldm.scale_factor
 # Low-resolution auxiliary objective only; denoiser and inference remain 512px.
 z=torch.nn.functional.avg_pool2d(z,2)
 target_rgb=torch.nn.functional.avg_pool2d(target_rgb,2);road=torch.nn.functional.avg_pool2d(road,2)
 rgb=checkpoint(model.ldm.first_stage_model.decode,z,use_reentrant=False)
 assert rgb.shape==target_rgb.shape and road.sum()>0
 l1=((rgb.float()-target_rgb).abs()*road).sum()/(road.sum()*3)
 gx=(rgb[:,:,:,1:]-rgb[:,:,:,:-1])-(target_rgb[:,:,:,1:]-target_rgb[:,:,:,:-1]);gy=(rgb[:,:,1:,:]-rgb[:,:,:-1,:])-(target_rgb[:,:,1:,:]-target_rgb[:,:,:-1,:]);wx=road[:,:,:,1:]*road[:,:,:,:-1];wy=road[:,:,1:,:]*road[:,:,:-1,:]
 grad=(gx.abs()*wx).sum()/(wx.sum()*3).clamp_min(1)+(gy.abs()*wy).sum()/(wy.sum()*3).clamp_min(1)
 return mse+.1*l1+.05*grad,dict(noise_mse=float(mse.detach()),decoded_road_l1=float(l1.detach()),road_gradient_l1=float(grad.detach()))
