"""Preserve native reflection forward; evaluate its small boundary-gradient reduction on CPU."""
import torch,types
from torch import nn
from torch.nn import functional as F
class Reflect(torch.autograd.Function):
 @staticmethod
 def forward(ctx,x,pad):
  ctx.pad=tuple(pad);ctx.shape=x.shape;ctx.device=x.device;return F.pad(x,ctx.pad,mode='reflect')
 @staticmethod
 def backward(ctx,grad):
  with torch.enable_grad():
   x=torch.zeros(ctx.shape,dtype=grad.dtype,device='cpu',requires_grad=True);y=F.pad(x,ctx.pad,mode='reflect');g=torch.autograd.grad(y,x,grad.cpu())[0]
  return g.to(ctx.device),None
class DeterministicReflect(nn.Module):
 def __init__(self,pad):super().__init__();self.pad=(pad,)*4 if isinstance(pad,int) else tuple(pad)
 def forward(self,x):return Reflect.apply(x,self.pad)
def install(module):
 count=0
 for name,child in list(module.named_children()):
  if isinstance(child,nn.ReflectionPad2d):setattr(module,name,DeterministicReflect(child.padding));count+=1
  else:count+=install(child)
  if isinstance(child,nn.Conv2d) and child.padding_mode=='reflect':
   def forward(self,x):return F.conv2d(Reflect.apply(x,self._reversed_padding_repeated_twice),self.weight,self.bias,self.stride,0,self.dilation,self.groups)
   child.forward=types.MethodType(forward,child);count+=1
 return count
