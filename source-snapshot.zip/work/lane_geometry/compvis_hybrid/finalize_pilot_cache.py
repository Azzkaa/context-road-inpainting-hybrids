from pathlib import Path
import json,hashlib,torch,numpy as np
from PIL import Image
from torch.nn import functional as F
from source_data import R,canvas
O=R/'outputs/lane_geometry/compvis_hybrid';C=R/'work/lane_geometry/compvis_hybrid/cache';p=json.loads((O/'pilot_protocol.json').read_text());rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};verification=json.loads((R/'work/road_restoration/lane_weight_verification_extended.json').read_text());verified={r['id']:r for r in verification['records'] if 'annotation' in r};used=[];torch.set_num_threads(4)
for sid in p['train_ids']+p['validation_ids']:
 r=rows[sid];path=C/(sid+'.pt');ck=torch.load(path,map_location='cpu',weights_only=False);assert ck['source_sha256']==r['snowy_sha256'] and ck['split']==r['split'] and ck['preprocessing_version']==2
 if r['split']=='validation':assert ck['supervision'] is None;continue
 assert ck['supervision']['clean_sha256']==r['clean_sha256'] and ck['supervision']['edit_mask_sha256']==r['mask_sha256'];im=Image.open(r['clean']);mask=Image.open(r['mask']).convert('L').resize(im.size,Image.Resampling.NEAREST);a,v,box=canvas(mask,True);assert box==ck['source']['content_box'];edit=torch.from_numpy((a>127).astype(np.float32))[None,None];valid=ck['working_valid'].float();weight=F.avg_pool2d((edit+.05*valid)*valid,4)
 if sid in verified:
  rec=verified[sid];assert rec['split']=='train' and rec['source_sha256_matches'] and rec['dimensions_match'];assert hashlib.sha256(Path(rec['annotation']).read_bytes()).hexdigest()==rec['annotation_sha256'];lane=torch.load(R/'work/road_restoration/lane_weights_extended'/(sid+'.pt'),map_location='cpu',weights_only=False).float().reshape(1,1,128,128);weight+=4*lane*F.avg_pool2d(edit,4)*F.avg_pool2d(valid,4);used.append(sid)
 ck['supervision']['weight']=weight;ck['loss_weights_version']=2;torch.save(ck,path.with_suffix('.tmp'));path.with_suffix('.tmp').replace(path)
a=json.loads((O/'pilot_cache_audit.json').read_text());a['finalized_verified_lane_weights']=True;a['verified_lane_train_examples']=len(used);a['lane_weight_ids']=used;a['loss_weight_rule']='TRAINhumaneditmask1 + validcontext0.05 + extra4verifiedlane intersectedit; paddingzero. Full701verifiedextendedfilecoverage; VALno supervision.';a['mask_coordinate_rule']='Verifiedstoredworkmask resizedNNto clean native frame then identical512letterbox, matching prior established cache convention.';(O/'pilot_cache_audit.json').write_text(json.dumps(a,indent=2));print(json.dumps({'phase':'passed','verified_lane_train_examples':len(used)}))
