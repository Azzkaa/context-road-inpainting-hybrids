"""Audited pilot caches; source conditioning and TRAIN supervision are separate fields."""
from pathlib import Path
import sys,json,time,hashlib,torch
from torch.nn import functional as F
from source_data import SourceEncoder,prepare_train_supervision,R
sys.path.insert(0,str(R/'work/road_restoration'));from models import load_ldm
O=R/'outputs/lane_geometry/compvis_hybrid';C=R/'work/lane_geometry/compvis_hybrid/cache';C.mkdir(exist_ok=True,parents=True);torch.set_num_threads(4)
def cpu(x):
 if torch.is_tensor(x):return x.detach().cpu()
 if isinstance(x,list):return [cpu(v) for v in x]
 return x
try:
 protocol=json.loads((O/'pilot_protocol.json').read_text());rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};ids=protocol['train_ids']+protocol['validation_ids'];base=load_ldm(None);vq=base.first_stage_model;scale=base.scale_factor;del base;vq.cuda();vq.eval();vq.requires_grad_(False)
 class FirstStage:
  cond_stage_model=vq
  def encode_first_stage(self,x):return vq.encode(x)
  def get_first_stage_encoding(self,z):return z*scale
 stage=FirstStage();enc=SourceEncoder();records=[]
 for n,sid in enumerate(ids):
  row=rows[sid];dst=C/(sid+'.pt');signrec=O/'source_sign_proposals'/(sid+'.json');assert signrec.exists();sign_sha=hashlib.sha256(signrec.read_bytes()).hexdigest()
  if dst.exists():
   ck=torch.load(dst,map_location='cpu',weights_only=False);assert ck['preprocessing_version']==2;assert ck['source_sha256']==row['snowy_sha256'] and ck['source_sign_record_sha256']==sign_sha and ck['split']==row['split']
  else:
   source_row={k:row[k] for k in ['id','snowy','snowy_sha256']};s=enc.prepare(source_row)
   with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16):z=vq.encode(s['x']*(1-s['permit'])*2-1);cond=torch.cat([z,F.interpolate(s['permit']*2-1,z.shape[-2:],mode='nearest')],1).detach()
   ck=dict(preprocessing_version=2,id=sid,split=row['split'],source_sha256=row['snowy_sha256'],source_sign_record_sha256=sign_sha,source_input_keys=list(source_row),conditioning=cond.cpu(),source={k:cpu(s[k]) for k in ['features','planes','signs','boxes','confidence','valid','content_box']},permit_working=s['permit'].cpu().byte(),working_valid=s['working_valid'].cpu().byte(),supervision=None)
   if row['split']=='train':
    target,targetcond,weight=prepare_train_supervision(row,stage,s);assert torch.equal(cond,targetcond);ck['supervision']=dict(target=target.cpu(),weight=weight.cpu(),clean_sha256=row['clean_sha256'],edit_mask_sha256=row['mask_sha256'])
   torch.save(ck,dst)
  assert ck['conditioning'].shape==(1,4,128,128);assert all(torch.isfinite(t).all() for t in ck['source']['features']);assert torch.isfinite(ck['conditioning']).all();assert set(ck['source_input_keys'])=={'id','snowy','snowy_sha256'}
  valid_tokens=(F.adaptive_avg_pool2d(ck['source']['planes'][:,3:4].float(),(8,8))>.5).sum().item();assert valid_tokens>0
  if row['split']=='validation':assert ck['supervision'] is None
  else:assert ck['supervision']['target'].shape==(1,3,128,128) and torch.isfinite(ck['supervision']['weight']).all() and ck['supervision']['weight'].sum()>0
  records.append(dict(id=sid,split=row['split'],permit_pixels=int(ck['permit_working'].sum()),valid_pixels=int(ck['working_valid'].sum()),scene_valid_tokens=int(valid_tokens),signs=0 if ck['source']['signs'] is None else ck['source']['signs'].shape[1],has_train_supervision=ck['supervision'] is not None));d=json.loads((O/'status.json').read_text());d.update(phase='Caching source features and isolated TRAIN targets',message='TRAIN targets are separate from source features; validation caches have no clean supervision. No pilot optimization yet.',completed=n+1,total=84,updated_at=time.time());(O/'status.json').write_text(json.dumps(d,indent=2))
 report=dict(phase='passed',train=64,validation=20,records=records,zero_permit_cases=[r['id'] for r in records if not r['permit_pixels']],warning='Source-predicted permits and sign proposals unverified; exact mask equality is not semantic accuracy. Clean TRAIN targets are isolated; no validation targets in caches.');(O/'pilot_cache_audit.json').write_text(json.dumps(report,indent=2));d=json.loads((O/'status.json').read_text());d.update(phase='Pilot caches audited; matched runner next',message='64TRAIN and20VALIDATION input caches passed shape/hash/source isolation checks. No pilot training yet.',updated_at=time.time(),next_action='Review mask/sign coverage and implement the matched100-update A1/B/C pilot with actual same-seed outputs.');(O/'status.json').write_text(json.dumps(d,indent=2));print(json.dumps({'phase':'passed','train':64,'validation':20,'zero_permit_cases':report['zero_permit_cases']}))
except Exception as e:
 (O/'pilot_cache_failure.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
