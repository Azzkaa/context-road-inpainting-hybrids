"""Experimental source-only ego protection and re-encoded masked source; old caches untouched."""
from pathlib import Path
import json,time,torch,numpy as np,hashlib,sys
from PIL import Image
from torch.nn import functional as F
from source_data import R,canvas
sys.path.insert(0,str(R/'work/road_restoration'));from models import load_ldm
O=R/'outputs/lane_geometry/compvis_hybrid';C=R/'work/lane_geometry/compvis_hybrid/cache';D=C.parent/'cache_ego_v3';D.mkdir(exist_ok=True);torch.set_num_threads(4);p=json.loads((O/'pilot_protocol.json').read_text());rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};base=load_ldm(None);vq=base.first_stage_model;del base;vq.cuda();vq.eval();vq.requires_grad_(False);records=[];verified={r['id']:r for r in json.loads((R/'work/road_restoration/lane_weight_verification_extended.json').read_text())['records'] if 'annotation'in r}
for j,sid in enumerate(p['train_ids']+p['validation_ids']):
 row=rows[sid];maskfile=O/'source_ego_proposals'/(sid+'_protection.png');recfile=O/'source_ego_proposals'/(sid+'_record.json');rec=json.loads(recfile.read_text());assert rec['source_sha256']==row['snowy_sha256'];dst=D/(sid+'.pt')
 if dst.exists():ck=torch.load(dst,map_location='cpu',weights_only=False);assert ck['ego_protection_sha256']==hashlib.sha256(maskfile.read_bytes()).hexdigest()
 else:
  ck=torch.load(C/(sid+'.pt'),map_location='cpu',weights_only=False);assert ck['source_sha256']==row['snowy_sha256'];native=Image.open(row['snowy']).convert('RGB');a,_,box=canvas(native);ego,_,ego_box=canvas(Image.open(maskfile).resize(native.size,Image.Resampling.NEAREST),True);assert box==ego_box==ck['source']['content_box'];protect=torch.from_numpy((ego>127).copy())[None,None];old=ck['permit_working'].bool();permit=old&~protect;assert not (permit&~old).any();ck['base_permit_pixels']=int(old.sum());ck['permit_working']=permit.byte();ck['source']['planes'][:,0:1]=F.interpolate(permit.float(),(128,128),mode='nearest');ck['source']['planes'][:,1:2]=torch.maximum(ck['source']['planes'][:,1:2],F.interpolate(protect.float(),(128,128),mode='nearest'));x=torch.from_numpy(a.copy()).permute(2,0,1)[None].cuda().float()/255
  with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16):lat=vq.encode((x*(1-permit.cuda().float()))*2-1);cond=torch.cat([lat,F.interpolate(permit.cuda().float()*2-1,lat.shape[-2:],mode='nearest')],1)
  ck['conditioning']=cond.cpu();ck['ego_working']=protect.byte();ck['ego_protection_sha256']=hashlib.sha256(maskfile.read_bytes()).hexdigest();ck['preprocessing_version']=3
  if row['split']=='train':
   clean=Image.open(row['clean']);edit,_,_=canvas(Image.open(row['mask']).convert('L').resize(clean.size,Image.Resampling.NEAREST),True);road=torch.from_numpy((edit>127).astype(np.float32))[None,None]*(~protect).float();valid=ck['working_valid'].float();weight=F.avg_pool2d((road+.05*valid)*valid,4)
   if sid in verified:
    lane=torch.load(R/'work/road_restoration/lane_weights_extended'/(sid+'.pt'),map_location='cpu',weights_only=False).float().reshape(1,1,128,128);weight+=4*lane*F.avg_pool2d(road,4)*F.avg_pool2d(valid,4)
   ck['supervision']['weight']=weight;ck['supervision']['decoded_road_weight']=road*valid
  else:assert ck['supervision'] is None
  torch.save(ck,dst)
 assert torch.isfinite(ck['conditioning']).all();assert not (ck['permit_working'].bool()&ck['ego_working'].bool()).any();records.append(dict(id=sid,split=row['split'],base_permit_pixels=ck['base_permit_pixels'],new_permit_pixels=int(ck['permit_working'].sum()),protected_pixels=int(ck['ego_working'].sum())));s=json.loads((O/'status.json').read_text());s.update(phase='Preparing experimental ego-protected pilot inputs',message='Source-onlyfrozenEgoVehicle/CarMountmasks subtractfromeditpermit;oldcachespreserved. No correctedtraining yet.',completed=j+1,total=84,updated_at=time.time());(O/'status.json').write_text(json.dumps(s,indent=2))
report=dict(phase='passed',records=records,zero_permit_cases=[r['id'] for r in records if not r['new_permit_pixels']],warning='Protectionpredictionsunverified. Newpermitsdifferfromoldpilot;re-evaluateALLmatchedcontrolsundernewpolicy,nevercountROIshrinkasreconstructiongain. Realnewdecodedloss/memorygateandsemanticreviewrequiredbeforetraining.');(O/'ego_corrected_cache_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({'phase':'passed','zero_permit_cases':report['zero_permit_cases']}))
