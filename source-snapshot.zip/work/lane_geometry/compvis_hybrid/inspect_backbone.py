"""Read-only pretrained source/config/module ledger, no forward or optimization."""
from pathlib import Path
import sys,json,csv,hashlib,time
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/compvis_hybrid';sys.path.insert(0,str(R/'work/road_restoration'));import models

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while True:
   b=f.read(8*1024*1024)
   if not b:break
   h.update(b)
 return h.hexdigest()
try:
 (O/'inspection_status.json').write_text(json.dumps(dict(phase='loading_pretrained_on_cpu',completed=0,total=1,updated_at=time.time())))
 m=models.load_ldm(None);net=m.model.diffusion_model;rows=[]
 for n,v in net.named_modules():
  if not list(v.children()):rows.append(dict(name=n,type=type(v).__name__,parameters=sum(p.numel() for p in v.parameters(recurse=False)),trainable=sum(p.numel() for p in v.parameters(recurse=False) if p.requires_grad)))
 with (O/'unet_module_ledger.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 manifest=R/'work/road_restoration/manifest.json';records=json.loads(manifest.read_text());split={k:sum(r['split']==k for r in records) for k in ['train','validation','test']};report=dict(phase='passed',scope='CPU instantiated pretrained source and module ledger ONLY',base_parameters=sum(p.numel() for p in m.parameters()),unet_parameters=sum(p.numel() for p in net.parameters()),base_trainable_parameters=sum(p.numel() for p in m.parameters() if p.requires_grad),unet_leaf_modules=len(rows),in_channels=net.in_channels,out_channels=net.out_channels,input_blocks=len(net.input_blocks),output_blocks=len(net.output_blocks),middle_block_modules=[type(v).__name__ for v in net.middle_block],first_stage=type(m.first_stage_model).__name__,manifest_sha256=sha(manifest),split_counts=split,checkpoint_sha256=sha(R/'work/inpainting_compare/models/ldm.ckpt'),config_sha256=sha(R/'work/inpainting_compare/repos/latent-diffusion/models/ldm/inpainting_big/config.yaml'),mask_semantics='Official script: binary1=edit; masked_image=(1-mask)*image in0..1 then all batch tensors normalized2*x-1, including mask. Do not confuse signedconditioningmaskwithbinaryeditpermit.',no_optimization=True);assert report['base_trainable_parameters']==0 and report['in_channels']==7 and report['out_channels']==3;(O/'backbone_inspection.json').write_text(json.dumps(report,indent=2));(O/'inspection_status.json').write_text(json.dumps(dict(phase='complete',completed=1,total=1,updated_at=time.time())));print(json.dumps(report))
except Exception as e:(O/'inspection_status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
