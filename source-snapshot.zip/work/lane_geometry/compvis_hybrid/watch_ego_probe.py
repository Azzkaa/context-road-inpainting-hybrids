from pathlib import Path
import time,json,subprocess
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/compvis_hybrid';end=time.time()+7200
while time.time()<end:
 f=O/'pilot100_guarded/status.json';failure=O/'pilot100_guarded/failure.json'
 if failure.exists():raise RuntimeError('Guarded generation failed; do not overlap unknown job')
 if f.exists() and json.loads(f.read_text())['phase']=='complete':
  with (O/'ego_probe_sequence.log').open('a') as log:subprocess.run([str(R/'work/inpainting_compare/venv/bin/python'),str(R/'work/lane_geometry/compvis_hybrid/probe_ego_protection.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
  break
 time.sleep(3)
else:raise TimeoutError('PriorGPUstage did notfinish; no probe started')
