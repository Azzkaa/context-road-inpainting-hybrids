"""Frozen source-only Mapillary ego-vehicle/car-mount protection probe, no optimization."""
from pathlib import Path
import json,time,torch,numpy as np,hashlib
from PIL import Image
from transformers import AutoImageProcessor,Mask2FormerForUniversalSegmentation
R=Path(__file__).resolve().parents[3];O=R/'outputs/lane_geometry/compvis_hybrid';D=O/'source_ego_proposals';D.mkdir(exist_ok=True);torch.set_num_threads(4);p=json.loads((O/'pilot_protocol.json').read_text());ids=p['train_ids']+p['validation_ids'];rows={r['id']:r for r in json.loads((R/'work/road_restoration/manifest.json').read_text())};path=R/'work/lane_geometry/models/mask2former_mapillary';cfg=json.loads((path/'config.json').read_text());assert cfg['id2label']['63']=='Car Mount' and cfg['id2label']['64']=='Ego Vehicle';proc=AutoImageProcessor.from_pretrained(path,local_files_only=True,use_fast=False);m=Mask2FormerForUniversalSegmentation.from_pretrained(path,local_files_only=True,torch_dtype=torch.float16).cuda().eval().requires_grad_(False);records=[]
try:
 for j,sid in enumerate(ids):
  r=rows[sid];assert r['split'] in ['train','validation'];assert hashlib.sha256(Path(r['snowy']).read_bytes()).hexdigest()==r['snowy_sha256'];im=Image.open(r['snowy']).convert('RGB');W,H=im.size;cached=D/(sid+'_record.json')
  if cached.exists():
   rec=json.loads(cached.read_text());assert rec['source_sha256']==r['snowy_sha256'];records.append(rec);continue
  sw=1024;sh=round(H*sw/W);batch=proc(images=im,return_tensors='pt',size={'shortest_edge':768,'longest_edge':1024});batch={k:v.cuda() for k,v in batch.items()};batch['pixel_values']=batch['pixel_values'].half()
  with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16):out=m(**batch);labels=proc.post_process_semantic_segmentation(out,target_sizes=[(sh,sw)])[0].cpu().numpy()
  protect=(labels==63)|(labels==64);a=np.array(im.resize((sw,sh)));overlay=a.copy();overlay[protect]=(.35*overlay[protect]+.65*np.array([255,80,180])).astype(np.uint8);Image.fromarray(overlay).save(D/(sid+'_overlay.png'));Image.fromarray((protect*255).astype(np.uint8)).save(D/(sid+'_protection.png'));np.save(D/(sid+'_labels.npy'),labels.astype(np.uint8));records.append(dict(id=sid,split=r['split'],source_sha256=r['snowy_sha256'],protected_pixels=int(protect.sum()),ego_pixels=int((labels==64).sum()),mount_pixels=int((labels==63).sum()),verified=False));cached.write_text(json.dumps(records[-1],indent=2));(D/'status.json').write_text(json.dumps(dict(phase='probing',completed=j+1,total=len(ids),updated_at=time.time())))
 page='<meta charset="utf-8"><style>body{background:#142033;color:white;font:18px system-ui;margin:30px}img{width:90%}a{color:#9df}</style><h1>Source-only ego protection probe</h1><p>Pink = frozen Mapillary class63Car Mount or64Ego Vehicle. Predictions are unverified, not ground truth. No clean input, image generation, training or automatic promotion.</p><a href="../progress/">Progress</a>'
 for r in records:page+='<h2>'+r['id']+'</h2><img src="'+r['id']+'_overlay.png">'
 (D/'index.html').write_text(page);(D/'summary.json').write_text(json.dumps(dict(records=records,classes={'63':'Car Mount','64':'Ego Vehicle'},scope='Frozen source-only mask proposal; visual semantics review required. May miss hood or wrongly exclude road.'),indent=2));(D/'status.json').write_text(json.dumps(dict(phase='complete',completed=len(ids),total=len(ids),updated_at=time.time())))
except Exception as e:(D/'status.json').write_text(json.dumps(dict(phase='failed',error=repr(e),updated_at=time.time())));raise
